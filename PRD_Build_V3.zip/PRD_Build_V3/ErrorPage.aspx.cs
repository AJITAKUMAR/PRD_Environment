﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Web.Security;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using BusinessEntity;
using System.Text;
using System.DirectoryServices;
using System.Text.RegularExpressions;
using System.Data.OracleClient;
using OraAppBlock;

public partial class ErrorPage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Error"] != null && Session["UserId"] != null)
        {
            lblErrorMsg.InnerText = Session["Error"].ToString();
            new LogError.LogError(Convert.ToDateTime(System.DateTime.Now), Session["UserId"].ToString(), lblErrorMsg.InnerText.ToString());
        }
        else
        {
            Session["UserId"] = null;
            Session["UserId"] = "";
            Session.Clear();
            Session.Abandon();
            Session.RemoveAll();
            Response.Redirect("Login.aspx?r=" + CommonFunctions.GetRandomNumber(), false);
        }
    }
    protected void lnkBtn_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Session.Abandon();
        Session.RemoveAll();
        Response.Redirect("Login.aspx?r=" + CommonFunctions.GetRandomNumber(), false);
    }
}
