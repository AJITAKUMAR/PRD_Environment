﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Modules_Events_YourEvent : System.Web.UI.Page
{
    BusinessLayer.IRIS_BusinessLayer objClass1_BL = new BusinessLayer.IRIS_BusinessLayer();
    string path = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        path = HttpContext.Current.Request.Url.AbsolutePath;
        if (Session["UserId"] == null || Convert.ToString(Session["UserId"]) == "")
        {
            Response.Redirect("~/Login.aspx?r=" + CommonFunctions.GetRandomNumber(), false);
        }
        HttpContext.Current.Session["RequestPath"] = "";
        HttpContext.Current.Session["RequestPath"] = null;
    }

    public void AddDynamicDivs()
    {
        try
        {

            
            string EmpId = Session["UserId"].ToString();
            string AllEvent = "YourEvent"; //passing param for finding my events
            DataSet ds = objClass1_BL.GET_EVENT_DETAILS(EmpId, AllEvent);
            if (ds.Tables.Count > 0)
            {
                if (ds.Tables[0].Rows.Count > 0)
                {
                    HttpContext.Current.Session["RequestPath"] = path;
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        string challengeName = string.Empty;
                        string challengeImage = string.Empty;
                        string eventstatus = string.Empty;
                        string spanstatus = string.Empty;

                        challengeName = Regex.Replace(row["EVENT_TYPE"].ToString(), "<.*?>", string.Empty);
                        eventstatus = Regex.Replace(row["EVENT_STATUS"].ToString(), "<.*?>", string.Empty);
                        if (eventstatus == "602")
                        {
                            eventstatus = "Pending";
                            spanstatus = "<span class='classstatus2'>" + eventstatus + "</span>";
                        }
                        else if(eventstatus == "601")
                        {
                            eventstatus = "Rejected";
                            spanstatus = "<span class='classstatus3'>" + eventstatus + "</span>";
                        }
                        else if(eventstatus == "600")
                        {
                            eventstatus = "Approved";
                            spanstatus = "<span class='classstatus1'>" + eventstatus + "</span>";
                            
                        }
                        if (challengeName.Length < 200)
                        {                            
                            challengeName = challengeName + new string(' ', 1);
                            int i = 200 - challengeName.Length;
                            while (i > 0)
                            {
                                challengeName = challengeName + "&nbsp;";
                                i--;
                            }
                        }
                        if (!string.IsNullOrEmpty(row["EVENT_IMAGE"].ToString()))
                        {
                            challengeImage = row["EVENT_IMAGE"].ToString();
                        }
                        else
                        {
                            challengeImage = "IRIS_Innovation_1.jpg";
                        }
                        Response.Write("<div style='margin:10px 0px 0px 10px; text-align:center; width:24%; display:inline-block; vertical-align: top; overflow-wrap: break-word; word-wrap:break-word;' class='challenge-card'>");
                        Response.Write("<a href='../../modules/Events/PostEvents.aspx?ChlId=" + row["EVENT_ID"].ToString() + "'>");                        
                        Response.Write("<img style='width:230px; height:210px'  src='../../images/icons/" + challengeImage + "'/><br />");
                        Response.Write("<span>" + challengeName + "</span>");
                        //Response.Write(spanstatus);                                            
                        Response.Write("</a>");
                        Response.Write("</div>");
                    }

                }
            }
        }
        catch (Exception ex)
        {
            Session["Error"] = ex.ToString();
            Response.Redirect("~/ErrorPage.aspx");
        }
    }
}