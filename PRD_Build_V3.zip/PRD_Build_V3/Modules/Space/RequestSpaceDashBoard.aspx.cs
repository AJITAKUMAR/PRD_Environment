﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Modules_Space_RequestSpaceDashBoard : System.Web.UI.Page
{
    BusinessLayer.IRIS_BusinessLayer objClass1_BL = new BusinessLayer.IRIS_BusinessLayer();
    string activityid = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        LoadSpaceDashBoard();
    }

    public void LoadSpaceDashBoard()
    {
        try
        {
            string EmpId = "ajit.rath075@gmail.com";            
            DataSet ds = objClass1_BL.GET_SPACE_DASHBOARD_DETAILS(EmpId, activityid);
            if (ds != null )
            {
                grViewActivity.DataSource = ds;
                grViewActivity.DataBind();
            }
        }
        catch (Exception ex)
        {

        }
        finally
        {

        }
    }
    protected void grViewActivity_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grViewActivity.PageIndex = e.NewPageIndex;
        LoadSpaceDashBoard();
    }



    protected void grViewActivity_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "RequestSpace")
        {
            int rowIndexId = Convert.ToInt32(e.CommandArgument);
            HttpContext.Current.Session["RequestSpaceId"] = rowIndexId;
            Response.Redirect("~/Modules/Space/BookingSpace.aspx");

        }
    }

    

    
}