﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Modules_Space_BookingSpace : System.Web.UI.Page
{
    BusinessLayer.IRIS_BusinessLayer objClass1_BL = new BusinessLayer.IRIS_BusinessLayer();
    string activityid = "";
    string path = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        path = HttpContext.Current.Request.Url.AbsolutePath;
        lblerrmessage.Visible = false;
        try
        {
            if (Session["UserId"] == null || Convert.ToString(Session["UserId"]) == "")
            {
                Response.Redirect("~/Login.aspx?r=" + CommonFunctions.GetRandomNumber(), false);
            }
            if (!IsPostBack)
            {
                activityid = Session["RequestSpaceId"].ToString();
                LoadActivityDetails();

            }
        }
        catch (Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
                Session["Error"] = Session["Error"] + ex.ToString();
            else
                Session["Error"] = ex.ToString();
            Response.Redirect("~/ErrorPage.aspx");
        }
        finally
        {

        }

        txtactvityid.Enabled = false;
        txtactivatyname.Enabled = false;
        controldisable();
        


    }
    public void controldisable()
    {
        txtContent.Enabled = false;
        ddlspacebooking.Enabled = false;
        txtstartdate.Enabled = false;
        txtEnddate.Enabled = false;
        txtparticipants.Enabled = false;
    }
    public void LoadActivityDetails()
    {
        try
        {
            string EmpId = Session["UserId"].ToString();
            DataSet ds = new DataSet();
            if (Session["Admin"] != null || Convert.ToString(Session["Admin"]) != "")
            {
                ds = objClass1_BL.GET_SPACE_DASHBOARD_DETAILS_A(EmpId, activityid);
                
            }
            else
            {
                ds = objClass1_BL.GET_SPACE_DASHBOARD_DETAILS(EmpId, activityid);

            }  
            
            if (ds.Tables[0].Rows.Count > 0)
            {
                txtactvityid.Text = ds.Tables[0].Rows[0]["ACTIVITYID"].ToString();
                txtactivatyname.Text = ds.Tables[0].Rows[0]["ACTIVITY_NAME"].ToString();
                txtContent.Text = ds.Tables[0].Rows[0]["DESCRIPTION"].ToString();
                ddlspacebooking.SelectedItem.Text = ds.Tables[0].Rows[0]["SPACE"].ToString();
                txtstartdate.Text = ds.Tables[0].Rows[0]["START_DATE"].ToString();
                txtEnddate.Text = ds.Tables[0].Rows[0]["END_DATE"].ToString();
                txtparticipants.Text = ds.Tables[0].Rows[0]["PARTICIPANTS"].ToString();

            }
        }
        catch (Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }

        }
        finally
        {

        }
    }
   

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            DateTime dt1;
            DateTime dt2;

            Session["Admin"] = "";
            Session["Admin"] = null;

            DateTime today = DateTime.Now;
            int year = today.Year;
            int month = today.Month;
            int day = today.Day;
            string s = "/";
            string currentdate = string.Concat(day,s, month,s, year);
            string startdate = txtstartdate.Text;

            if (DateTime.TryParse(startdate, out dt1) && DateTime.TryParse(currentdate, out dt2))
            {
                if (dt1.Date >= dt2.Date)
                {
                    
                }
                else
                {
                    lblerrmessage.Text = "Enter Valied Start Date.!";
                    lblerrmessage.Visible = true;
                    return;
                }
            }



            //if (startdate < currentdate)
            //{

            //}
            //int cmp = currentdate.CompareTo(txtstartdate.Text);
            //if (cmp > 0)
            //{
            //    lblerrmessage.Text = "Enter Valied Start Date.!";
            //    lblerrmessage.Visible = true;
            //    return;
            //}



            string[] paramArray = new string[8];
            paramArray[0] = txtactvityid.Text;
            paramArray[1] = txtactivatyname.Text;
            paramArray[2] = txttypeofactivity.Text;
            paramArray[3] = txtContent.Text;
            paramArray[4] = txtstartdate.Text;
            paramArray[5] = txtEnddate.Text;
            paramArray[6] = ddlspacebooking.SelectedItem.Text;           
            paramArray[7] = txtparticipants.Text;

            int getid = objClass1_BL.INSERT_POST_BOOKING_SPACE(paramArray);
            if (getid > 0)
            {
                //ScriptManager.RegisterStartupScript(Page, GetType(), "LHS9", "alert('Space Booking Data Saved Successfully...!');", true);
                HttpContext.Current.Session["SuccessMessage"] = "Space Booking Data Saved Successfully...!";
                HttpContext.Current.Response.Redirect("~/Modules/Message/SuccessMessage.aspx", false);

            }

        }
        catch (Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }
        }
        finally
        {

        }
    }

    public void clearcontrol()
    {
        txttypeofactivity.Text = "";
        txtContent.Text = "";
        txtstartdate.Text = "";
        txtEnddate.Text = "";
        ddlspacebooking.SelectedValue = "0";
        txtparticipants.Text = "";
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Session["Admin"] = "";
        Session["Admin"] = null;
        if (Session["postbackurl"] != null || Convert.ToString(Session["postbackurl"]) != "")
        {
            HttpContext.Current.Response.Redirect(Session["postbackurl"].ToString());
        }
        HttpContext.Current.Response.Redirect("~/HomePage.aspx");
    }

    protected void txtEnddate_TextChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlspacebooking.SelectedValue == "0")
            {
                lblerrmessage.Text = "Please Select Space !";
                lblerrmessage.Visible = true;
                txtstartdate.Text = "";
                txtEnddate.Text = "";
                return;
            }
            if (txtstartdate.Text == "")
            {
                lblerrmessage.Text = "Please Select Start Date!";
                lblerrmessage.Visible = true;
                txtstartdate.Text = "";
                txtEnddate.Text = "";
                return;                
            }

            DataSet Ideads = objClass1_BL.GET_SPACE_DETAILS(ddlspacebooking.SelectedItem.Text);
            DataTable dt = Ideads.Tables[0];
            if (dt.Rows.Count > 0)
            {
                string Sdate = dt.Rows[0]["START_DATE"].ToString();
                string Edate = dt.Rows[0]["END_DATE"].ToString();

                int cmp = Edate.CompareTo(txtstartdate.Text);
                if (cmp > 0)
                {
                    lblerrmessage.Text = "Slot not availabe in same date";
                    lblerrmessage.Visible = true;
                    txtstartdate.Text = "";
                    txtEnddate.Text = "";

                }
            }




        }
        catch (Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }
        }
        finally
        {

        }
    }

    protected void btnedit_Click(object sender, EventArgs e)
    {
        controlenable();
    }
    public void controlenable()
    {
        txtContent.Enabled = true;
        ddlspacebooking.Enabled = true;
        txtstartdate.Enabled = true;
        txtEnddate.Enabled = true;
        txtparticipants.Enabled = true;
    }
}