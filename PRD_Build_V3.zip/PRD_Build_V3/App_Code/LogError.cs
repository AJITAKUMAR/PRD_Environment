﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Reflection;
using System.Data;
using System.Data.OracleClient;
using OraAppBlock;
using BusinessLayer;
namespace LogError
{
    public class LogError
    {
        //Start - 13th Nov  2017 - Bhakti
        BusinessLayer.IRIS_BusinessLayer objClass1_BL = new BusinessLayer.IRIS_BusinessLayer();
        //End - 13th Nov 2017 - Bhakti

        public LogError(DateTime P_LOG_DATE, string p_USER_ID, string P_Error_Msg)
        {
            LogErr(P_LOG_DATE, p_USER_ID, P_Error_Msg);
        }
        public void LogErr(DateTime P_LOG_DATE, string p_USER_ID, string P_Error_Msg)
        {
            //Start - 13th Nov  2017 - Bhakti
            //string strConnectionString = CommonFunctions.getConnectionString();
            //OracleConnection pConn = new OracleConnection();
            //pConn = CommonFunctions.OpenConnetion();
            //OracleParameter[] oraParamArray = null;
            //pConn.Open();
            //End - 13th Nov  2017 - Bhakti

            try
            {
                //Start - 13th Nov  2017 - Bhakti
                //oraParamArray = OracleHelperParameterCache.GetSpParameterSet(strConnectionString, "IRIS_INSERT_ERROR");
                //oraParamArray[0].Value = P_LOG_DATE;
                //oraParamArray[1].Value = p_USER_ID;
                //oraParamArray[2].Value = P_Error_Msg;

                //OracleHelper.ExecuteNonQuery(pConn, CommandType.StoredProcedure, "IRIS_INSERT_ERROR", oraParamArray);

                objClass1_BL.IRIS_INSERT_ERROR(P_LOG_DATE, p_USER_ID, P_Error_Msg);
                //End - 13th Nov  2017 - Bhakti
            }
            catch (Exception ex)
            {
                HttpContext.Current.Session["Error"] = ex.ToString();
                HttpContext.Current.Response.Redirect("~/ErrorPage.aspx");
            }
            finally
            {
                //Start - 13th Nov  2017 - Bhakti
                //pConn.Close();
                //pConn.Dispose();
                //End - 13th Nov  2017 - Bhakti
            }
        }
    }
}
