﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data;
using System.Data.SqlClient;
using System.Data.OracleClient;
using OraAppBlock;


[System.Web.Script.Services.ScriptService]
public class AutoComplete : System.Web.Services.WebService
{
    BusinessLayer.IRIS_BusinessLayer objClass1_BL = new BusinessLayer.IRIS_BusinessLayer();

    DataSet ds = new DataSet();


    public AutoComplete()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }
    //[System.Web.Services.WebMethod]
    [System.Web.Script.Services.ScriptMethod]
    [WebMethod]

    public List<string> SearchCustomers(string prefixText, int count)
    {        
        try
        {                        
            DataSet ds = objClass1_BL.getEmployeeData2(prefixText);
           
            List<string> customers = new List<string>();
            if (ds.Tables[0].Rows.Count > 0)
            {
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    customers.Add(ds.Tables[0].Rows[i]["EMAILID"].ToString());
                }
            }

            return customers;
        }
        catch (Exception ex)
        {
            HttpContext.Current.Session["Error"] = ex.ToString();
            HttpContext.Current.Response.Redirect("~/ErrorPage.aspx");
            return null;
        }
        finally
        {           
        }
    }
    [System.Web.Script.Services.ScriptMethod]
    [WebMethod(EnableSession = true)]

    public List<string> SearchCustomersUniv(string prefixText, int count)
    {
        string strSql;
        string strConnectionString = CommonFunctions.getConnectionString();
        OracleConnection pConn = new OracleConnection();
        pConn = CommonFunctions.OpenConnetion();
        List<string> customers = new List<string>();

        try
        {
            pConn.Open();
            DataSet ds0 = new DataSet();
            string Univ_ID = string.Empty;
            string Collage_ID = string.Empty;

            string str0 = "select user_univ_ID, user_collage_id from IRIS_UNIVERSITY_USERS where user_id = '" + HttpContext.Current.Session["UserId"].ToString() + "'";
            ds0 = OracleHelper.ExecuteDataset(pConn, CommandType.Text, str0);

            if (ds0.Tables.Count > 0)
            {
                if (ds0.Tables[0].Rows.Count > 0)
                {
                    Univ_ID = ds0.Tables[0].Rows[0][0].ToString();
                    Collage_ID = ds0.Tables[0].Rows[0][1].ToString();
                }
            }

            int parsedValue;
            if (int.TryParse(prefixText, out parsedValue))
            {
                strSql = "select * from IRIS_UNIVERSITY_USERS where user_id = '" + prefixText + "' and user_univ_ID = " + Univ_ID + " and user_collage_id = " + Collage_ID + "";
            }
            else if (prefixText.Contains("@"))
            {
                strSql = "select * from IRIS_UNIVERSITY_USERS where upper(user_email_id) = '" + prefixText.ToUpper() + "' and user_univ_ID = " + Univ_ID + " and user_collage_id = " + Collage_ID + "";
            }
            else
            {
                if (prefixText.Split(' ').Length > 0)
                {
                    string[] words = prefixText.Split(' ');
                    string filter = string.Empty;

                    foreach (string word in words)
                    {
                        filter = filter + "%" + word + "%";
                    }
                    strSql = "select * from IRIS_UNIVERSITY_USERS where upper(user_name || ' ' || USER_SURNAME ) like '" + filter.ToUpper() + "%' and user_univ_ID =  " + Univ_ID + " and user_collage_id = " + Collage_ID + "";
                }
                else
                {
                    strSql = "select * from IRIS_UNIVERSITY_USERS where upper(user_name || ' ' || USER_SURNAME ) like '" + prefixText.ToUpper() + "%' and user_univ_ID =  " + Univ_ID + " and user_collage_id = " + Collage_ID + "";
                }
            }

            DataSet ds = OracleHelper.ExecuteDataset(pConn, CommandType.Text, strSql);

            if (ds.Tables[0].Rows.Count > 0)
            {
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    customers.Add(ds.Tables[0].Rows[i]["USER_EMAIL_ID"].ToString());
                }
            }

            return customers;
        }
        catch (Exception ex)
        {
            HttpContext.Current.Session["Error"] = ex.ToString();
            HttpContext.Current.Response.Redirect("~/ErrorPage.aspx");
            return null;
        }
        finally
        {
            pConn.Close();
        }
    }

    [System.Web.Script.Services.ScriptMethod]
    [WebMethod(EnableSession = true)]
    public List<string> SearchAllUsersUniv(string prefixText, int count)
    {
        string strSql;
        string strConnectionString = CommonFunctions.getConnectionString();
        OracleConnection pConn = new OracleConnection();
        pConn = CommonFunctions.OpenConnetion();
        List<string> customers = new List<string>();

        try
        {
            pConn.Open();
            DataSet ds0 = new DataSet();           

            int parsedValue;
            if (int.TryParse(prefixText, out parsedValue))
            {
                strSql = "select * from IRIS_UNIVERSITY_USERS where user_id = '" + prefixText + "'";
            }
            else if (prefixText.Contains("@"))
            {
                strSql = "select * from IRIS_UNIVERSITY_USERS where upper(user_email_id) = '" + prefixText.ToUpper() + "'";
            }
            else
            {
                if (prefixText.Split(' ').Length > 0)
                {
                    string[] words = prefixText.Split(' ');
                    string filter = string.Empty;

                    foreach (string word in words)
                    {
                        filter = filter + "%" + word + "%";
                    }
                    strSql = "select * from IRIS_UNIVERSITY_USERS where upper(user_name || ' ' || USER_SURNAME ) like '" + filter.ToUpper() + "%'";
                }
                else
                {
                    strSql = "select * from IRIS_UNIVERSITY_USERS where upper(user_name || ' ' || USER_SURNAME ) like '" + prefixText.ToUpper() + "%'";
                }
            }

            DataSet ds = OracleHelper.ExecuteDataset(pConn, CommandType.Text, strSql);

            if (ds.Tables[0].Rows.Count > 0)
            {
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    customers.Add(ds.Tables[0].Rows[i]["USER_EMAIL_ID"].ToString());
                }
            }

            return customers;
        }
        catch (Exception ex)
        {
            HttpContext.Current.Session["Error"] = ex.ToString();
            HttpContext.Current.Response.Redirect("~/ErrorPage.aspx");
            return null;
        }
        finally
        {
            pConn.Close();
        }
    }

    [System.Web.Script.Services.ScriptMethod]
    [WebMethod(EnableSession = true)]
    public List<string> SearchIMUniv(string prefixText, int count)
    {
        string strSql;
        string strConnectionString = CommonFunctions.getConnectionString();
        OracleConnection pConn = new OracleConnection();
        pConn = CommonFunctions.OpenConnetion();
        List<string> customers = new List<string>();

        try
        {
            pConn.Open();
            DataSet ds0 = new DataSet();
            string Univ_ID = string.Empty;
            string Collage_ID = string.Empty;

            string str0 = "select user_univ_ID, user_collage_id from IRIS_UNIVERSITY_USERS where user_id = '" + HttpContext.Current.Session["UserId"].ToString() + "'";
            ds0 = OracleHelper.ExecuteDataset(pConn, CommandType.Text, str0);

            if (ds0.Tables.Count > 0)
            {
                if (ds0.Tables[0].Rows.Count > 0)
                {
                    Univ_ID = ds0.Tables[0].Rows[0][0].ToString();
                    Collage_ID = ds0.Tables[0].Rows[0][1].ToString();
                }
            }

            int parsedValue;
            if (int.TryParse(prefixText, out parsedValue))
            {
                //below line to get users from same subcommunity as of CO (logged in)
                //strSql = "select * from IRIS_UNIVERSITY_USERS where user_id = '" + prefixText + "' and user_univ_ID = " + Univ_ID + " and user_collage_id = " + Collage_ID + "";
                
                //getting users from same community as of CO (logged in)
                strSql = "select * from IRIS_UNIVERSITY_USERS where user_id = '" + prefixText + "' and user_univ_ID = " + Univ_ID + "";
            }
            else if (prefixText.Contains("@"))
            {
                //below line to get users from same subcommunity as of CO (logged in)
                //strSql = "select * from IRIS_UNIVERSITY_USERS where upper(user_email_id) = '" + prefixText.ToUpper() + "' and user_univ_ID = " + Univ_ID + " and user_collage_id = " + Collage_ID + "";

                //getting users from same community as of CO (logged in)
                strSql = "select * from IRIS_UNIVERSITY_USERS where upper(user_email_id) = '" + prefixText.ToUpper() + "' and user_univ_ID = " + Univ_ID + "";
            }
            else
            {
                if (prefixText.Split(' ').Length > 0)
                {
                    string[] words = prefixText.Split(' ');
                    string filter = string.Empty;

                    foreach (string word in words)
                    {
                        filter = filter + "%" + word + "%";
                    }
                    //below line to get users from same subcommunity as of CO (logged in)
                    //strSql = "select * from IRIS_UNIVERSITY_USERS where upper(user_name || ' ' || USER_SURNAME ) like '" + filter.ToUpper() + "%' and user_univ_ID =  " + Univ_ID + " and user_collage_id = " + Collage_ID + "";

                    //getting users from same community as of CO (logged in)
                    strSql = "select * from IRIS_UNIVERSITY_USERS where upper(user_name || ' ' || USER_SURNAME ) like '" + filter.ToUpper() + "%' and user_univ_ID =  " + Univ_ID + "";
                }
                else
                {
                    //below line to get users from same subcommunity as of CO (logged in)
                    //strSql = "select * from IRIS_UNIVERSITY_USERS where upper(user_name || ' ' || USER_SURNAME ) like '" + prefixText.ToUpper() + "%' and user_univ_ID =  " + Univ_ID + " and user_collage_id = " + Collage_ID + "";

                    //getting users from same community as of CO (logged in)
                    strSql = "select * from IRIS_UNIVERSITY_USERS where upper(user_name || ' ' || USER_SURNAME ) like '" + prefixText.ToUpper() + "%' and user_univ_ID =  " + Univ_ID + "";
                }
            }

            DataSet ds = OracleHelper.ExecuteDataset(pConn, CommandType.Text, strSql);

            if (ds.Tables[0].Rows.Count > 0)
            {
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    customers.Add(ds.Tables[0].Rows[i]["USER_EMAIL_ID"].ToString());
                }
            }

            return customers;
        }
        catch (Exception ex)
        {
            HttpContext.Current.Session["Error"] = ex.ToString();
            HttpContext.Current.Response.Redirect("~/ErrorPage.aspx");
            return null;
        }
        finally
        {
            pConn.Close();
        }
    }
}








