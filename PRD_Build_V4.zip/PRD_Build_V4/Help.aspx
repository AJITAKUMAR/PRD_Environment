﻿<%@ Page Language="C#" AutoEventWireup="true" MasterPageFile="~/Site.master" CodeFile="Help.aspx.cs" Inherits="Help" %>

<asp:Content ID="Content1" ContentPlaceHolderID="HeadContent" runat="Server">
    <style>
       .classdiv_office {
           position: relative;
           top: 180px;
           right: 300px;
           padding: 20px;
           background-color: #FFF;
           max-width: 42%;
           min-height: 170px;
       }
       .classdiv_phone {
           position: relative;
           top: 10px;
           left: 300px;
           padding: 20px;
           background-color: #FFF;
           max-width: 42%;
           min-height: 170px;
       }
       .classdiv_email {
           position: relative;
           top: 20px;
           padding: 20px;
           background-color: #FFF;
           max-width: 85%;
           min-height: 170px;
       }
       .classimgcenter {
           display: block;
           margin-left: auto;
           margin-right: auto;
           max-width: 90px
       }
       .classbtn_back {           
           position: relative;
           top: 70px;
           left: 1230px;
           width: 70px;
           border: 1.967px solid var(--Primary-60, #0F62FE);
           background: var(--Primary-60, #0F62FE);
           color: var(--Default-White, #FFF);           
           font-size: 13px;           
           font-weight: 500;           
       }
   </style>
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="Server">
    <div class="classdiv_office">
        <div style="text-align:center">Our Office</div>
        <asp:ImageButton ID="ImageButton1" runat="server" ImageUrl="~/images/img_ouroffice.png" class="classimgcenter" />
        <div style="text-align:center">445 King St West 3rd Floor, Toronto Ontario, M5V 1K4</div>
    </div>
    <div class="classdiv_phone">
        <div style="text-align:center">Phone Number</div>
        <asp:ImageButton ID="ImageButton2" runat="server" ImageUrl="~/images/img_Phone.png" class="classimgcenter" />
        <div style="text-align:center">416-889-0615</div>
    </div>
    <div class="classdiv_email">
        <div style="text-align:center">Email</div>
        <asp:ImageButton ID="ImageButton3" runat="server" ImageUrl="~/images/img_emailattach.png" class="classimgcenter" />
        <div style="text-align:center">denish.bhavsar@mccain.ca</div>
    </div>
    <asp:Button ID="btn_back" runat="server" Text="Back" OnClick="btn_back_Click" class="classbtn_back" />
</asp:Content>