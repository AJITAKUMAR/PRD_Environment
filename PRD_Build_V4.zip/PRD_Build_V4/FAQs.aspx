﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Site.master" AutoEventWireup="true" CodeFile="FAQs.aspx.cs" Inherits="FAQs" %>

<asp:Content ID="Content1" ContentPlaceHolderID="HeadContent" Runat="Server">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
     <link rel="icon" type="image/png" sizes="32x32" href="./FAQs_images/images/favicon-32x32.png" />
 
<link href="css/FAQs_styles.css" rel="stylesheet" />

    <style>
    .attribution {
        font-size: 11px;
        text-align: center;
    }
        .attribution a {
            color: hsl(228, 45%, 44%);
        }
        .classfaqs {
            position: relative;
            top: 90px;
            right: 295px;
            width: 500px;
            color: var(--McCain-Grey, #3B393D);
            text-align: justify;
            font-family: "Red Hat Display";
            font-size: 30px;
            font-style: normal;
            font-weight: 900;
            line-height: normal;
        }
</style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" Runat="Server">
   <%-- <div class="classfaqs">
    Frequently Asked Questions<span class="mixdot">.</span>
</div>--%>
    <div class="faqcontainer">
        <asp:Button ID="btn_previous" runat="server" Text="Previous" OnClick="btn_previous_Click" class="classbtn_previous" />
        <asp:Button ID="btn_next" runat="server" Text="Next" OnClick="btn_next_Click" class="classbtn_next" />
    
    
  <div id="faq_container1" runat="server">      
  <div class="question">
    <details>
      <summary class = "drop"><img src="images/FAQs_images/plus.png" class="plusimages" />What is MIX?</summary>
      <p>The McCain Innovation Xchange (The MIX) ignites curiosity, empowers our people to push the boundaries of what is possible by fostering intrapreneurship in a safe and inclusive space. A destination for collaboration, co-creation with each other, strategic partners, start-ups, and customers. Our goal is to inspire innovation and serve as a catalyst for new ideas that challenge the status quo.</p>
    </details>
  </div>

  <div class="question">
    <details>
      <summary class = "drop2"><img src="images/FAQs_images/plus.png" class="plusimages" />How to login to MIX portal?</summary>
      <p>The MIX platform can be logged in with User’s McCain credentials.</p>
    </details>
  </div>

  <div class="question">
    <details>
      <summary class = "drop3"><img src="images/FAQs_images/plus.png" class="plusimages">What is the use of “Post Ideas”?</summary>
      <p>Any user with an innovative idea or a suggestion to change ongoing processes/funvtions in BAU is welcome to lodge their ideas in Post Idea. Users can fill in the Idea description and submit it for Admin’s approval.</p>
    </details>
  </div>

  <div class="question">
    <details>
      <summary class = "drop4"><img src="images/FAQs_images/plus.png" class="plusimages">How to Post Idea?</summary>
      <p></p>
    </details>
  </div>
  <div class="question">
   <details>
     <summary class = "drop4"><img src="images/FAQs_images/plus.png" class="plusimages" />What happens post submission of Idea?</summary>
     <p>Once the Idea is submitted, it is sent for approval from Admin. Once Admin approves, the Idea will be either submitted as a solution for a respective Challenge hosted by Admin, Or the Idea is available for other users of McCain to participate and innovate in.</p>
   </details>
 </div>
</div>
<%------------------------%>
  <div  id="faq_container2" runat="server">      
  <div class="question">
    <details>
      <summary class = "drop"><img src="images/FAQs_images/plus.png" class="plusimages" />Why have I received a Space booking link after my Ideas was approved by Admin?</summary>
      <p>If Admin approves the submitted Idea, User receives a confirmation mail acknowledging the same with a link for space allocation request for the Idea to be held at MIX hub. The space allocation request helps User to collaborate with their fellow teammates in a space at the MIX hub.</p>
    </details>
  </div>

  <div class="question">
    <details>
      <summary class = "drop2"><img src="images/FAQs_images/plus.png" class="plusimages" />How do I request for Space allocation?</summary>
      <p>After clicking on request in the respective Idea, User will be asked to fill in details of number of associates who will be tentatively participating in the Idea, their domain specifications etc. to be filled on a form. This request is sent for approval from Admin.</p>
    </details>
  </div>

  <div class="question">
    <details>
      <summary class = "drop3"><img src="images/FAQs_images/plus.png" class="plusimages">What is an Event?</summary>
      <p>An event could be a small huddle for McCain associates to collaborate, a Client event, a Workshop, a Townhall etc.</p>
    </details>
  </div>

  <div class="question">
    <details>
      <summary class = "drop4"><img src="images/FAQs_images/plus.png" class="plusimages">How do I raise request for an Event?</summary>
      <p>Go to Events and workshops – and click on Raise Request. Fill in the details regarding the type of events, tentative number of participants, date and click on submit. A submitted event will be reviewed by the Admin and then once the Admin approve you will be redirected to request for the space with available dates for your requisite.</p>
    </details>
  </div>
  <div class="question">
   <details>
     <summary class = "drop4"><img src="images/FAQs_images/plus.png" class="plusimages" />Whom can I reach out in case of a query/feedback?</summary>
     <p>&nbsp;You can reach out to the McCain team via following ways –<br />
         · Email - denish.bhavsar@mccain.ca<br />
         · Phone - 416-889-0615<br />
         · Or write to us on - Location: 445 King St West 3rd Floor, Toronto Ontario, M5V 1K4</p>
   </details>
 </div>
       <div class="question">
  <details>
    <summary class = "drop4"><img src="images/FAQs_images/plus.png" class="plusimages" />Why use MIX portal?</summary>
    <p>Our vision is to be a thriving ecosystem of tenacious innovation with customer at the core. We aspire to create an inclusive and dynamic environment that fosters interdisciplinary collaboration, experimentation, and drives digital engagement with our customers, partners and community. By harnessing the power of creativity,
       embedding human centric design, and executing through rapid sprints, we envision a future where innovation drives positive change, enriched experience and sustainable growth.</p>
  </details>
</div>
</div>
</div>

</asp:Content>

