﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Site.master" AutoEventWireup="true" CodeFile="RequestSpaceDashBoard.aspx.cs" Inherits="Modules_Space_RequestSpaceDashBoard" %>

<asp:Content ID="Content1" ContentPlaceHolderID="HeadContent" Runat="Server">
    <script src="../../js/jquery.js"></script>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" Runat="Server">
  

   <style>
    .NoDisplay
    {
        display: none;
    }
    </style>

<div class="view_tab view-ideas">    
    <div class="tab-content">
        <div class="tab-pane active all_ideas" id="all_ideas">
            <div>
                <div class="col-lg-6 col-md-6 col-sm-6 nopadding">
                    <div class="form-group ">
                        <div class="nopadding">
                            
                            <h4 runat="server" id="lblNodata" visible="false">
                                No data exist</h4>
                        </div>
                    </div>
                </div>
               
                <div class="clearfix">
                </div>
            </div>
            <div class="table-responsive">     
                <asp:GridView ID="grViewActivity" runat="server" AutoGenerateColumns="False" OnPageIndexChanging="grViewActivity_PageIndexChanging"
                    EmptyDataText="No Data Exist" CssClass="table table-bordered tbldashboard" AllowPaging="True" OnRowCommand="grViewActivity_RowCommand" >
                    <Columns>
                        <asp:TemplateField HeaderText="ACTIVITY ID">
                            <ItemTemplate>
                                <asp:Label ID="lblIdeaId" runat="server" Text='<%# Bind("ACTIVITYID") %>'></asp:Label>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="ACTIVITY">
                            <ItemTemplate>
                                <asp:Label ID="lblIdeaId2" runat="server" Text='<%# Bind("ACTIVITY") %>'></asp:Label>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="ACTIVITY NAME">
                            <ItemTemplate>
                                <asp:Label ID="lblIdeaName" runat="server" Text='<%# Bind("ACTIVITY_NAME") %>'></asp:Label>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="SUBMISSION DATE">
                            <ItemTemplate>
                                <asp:Label ID="lblIdeaDescription" runat="server" Text='<%# Bind("SUBDATE") %>'></asp:Label>
                            </ItemTemplate>
                        </asp:TemplateField>       
                        <asp:TemplateField HeaderText="Status">
                            <ItemTemplate>
                                <asp:LinkButton ID="lnkspaceid" runat="server" CommandName="RequestSpace" CommandArgument='<%# Bind("ACTIVITYID") %>' Font-Underline="true">Request</asp:LinkButton> 
                            </ItemTemplate>
                        </asp:TemplateField>
       
                    </Columns>
                </asp:GridView>


            </div>
        </div>
    </div>
</div>
<!-- script references -->
<link href="../../css/jquery.mCustomScrollbar.css" rel="stylesheet">
<script src="../../js/bootstrap.min.js"></script>
<script src="../../js/scripts.js"></script>
<script src="../../js/scroll/jquery.nicescroll.min.js"></script>
<script src="../../js/scroll/custom.js"></script>


</asp:Content>

