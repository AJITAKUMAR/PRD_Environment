﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Site.master" AutoEventWireup="true" CodeFile="ViewIdea_Spacebooking.aspx.cs" Inherits="Modules_Space_ViewIdea_Spacebooking" %>

<asp:Content ID="Content1" ContentPlaceHolderID="HeadContent" Runat="Server">
    <script src="../../js/jquery.js"></script>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" Runat="Server">
     <style>
     .NoDisplay
     {
         display: none;
     }
 </style>

 <div class="view_tab view-ideas">    
     <div class="tab-content">
         <div class="tab-pane active all_ideas" id="all_ideas">
             <div>
                 <div class="col-lg-6 col-md-6 col-sm-6 nopadding">
                     <div class="form-group ">
                         <div class="nopadding">
                             
                             <h4 runat="server" id="lblNodata" visible="false">
                                 No data exist</h4>
                         </div>
                     </div>
                 </div>
                
                 <div class="clearfix">
                 </div>
             </div>
             <div class="table-responsive">
                 <asp:GridView ID="grViewIdea" runat="server" AutoGenerateColumns="False" OnRowDataBound="grViewIdea_RowDataBound"
                     EmptyDataText="No Data Exist" CssClass="table table-bordered" AllowPaging="True"
                     OnPageIndexChanging="grViewIdea_PageIndexChanging">
                     <Columns>
                         <asp:TemplateField HeaderText="Idea Id" ItemStyle-Width="100px" ItemStyle-HorizontalAlign="Center">
                             <ItemTemplate>
                                 <asp:LinkButton ID="lblIdeaId" runat="server" Text='<%# Bind("IDEA_ID") %>'></asp:LinkButton>
                             </ItemTemplate>
                         </asp:TemplateField>
                         <asp:TemplateField HeaderText="Idea Name" ItemStyle-HorizontalAlign="Center">
                             <ItemTemplate>
                                 <asp:Label ID="lblIdeaName" runat="server" Text='<%# Bind("IDEA_NAME") %>'></asp:Label>
                             </ItemTemplate>
                         </asp:TemplateField>
                         <asp:TemplateField HeaderText="Review Status" ItemStyle-HorizontalAlign="Center">
                             <ItemTemplate>
                                 <asp:Label ID="lblStatus" runat="server" Text='<%# Bind("IRIS_STATUS_DESCRIPTION") %>'></asp:Label>
                             </ItemTemplate>
                         </asp:TemplateField> 
                         <asp:TemplateField HeaderText="SpaceBooking" ItemStyle-Width="100px" ItemStyle-HorizontalAlign="Center">
                            <ItemTemplate>
                                <asp:Label ID="lblbookingspace" runat="server" Text='Click'></asp:Label>
                            </ItemTemplate>
                        </asp:TemplateField>
                     </Columns>
                     <FooterStyle BackColor="#507CD1" Font-Bold="True" ForeColor="White" />
                     <HeaderStyle BackColor="#507CD1" Font-Bold="True" ForeColor="White" HorizontalAlign="Center" />
                     <RowStyle BackColor="#EFF3FB" />
                 </asp:GridView>
             </div>
         </div>
     </div>
 </div>
 <!-- script references -->
 <link href="../../css/jquery.mCustomScrollbar.css" rel="stylesheet">
 <script src="../../js/bootstrap.min.js"></script>
 <script src="../../js/scripts.js"></script>
 <script src="../../js/scroll/jquery.nicescroll.min.js"></script>
	<script src="../../js/scroll/custom.js"></script>
</asp:Content>

