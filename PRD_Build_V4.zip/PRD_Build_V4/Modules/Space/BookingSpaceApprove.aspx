﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Site.master" AutoEventWireup="true" CodeFile="BookingSpaceApprove.aspx.cs" Inherits="Modules_Space_BookingSpaceApprove" %>

<asp:Content ID="Content1" ContentPlaceHolderID="HeadContent" Runat="Server">
    <script src="../../js/jquery.js" type="text/javascript"></script>
<link href="../../css/jquery.feedBackBox.css" rel="stylesheet" />

<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
<script>
    $(function () {
        $("#<%= txtstartdate.ClientID %>").datepicker({
            dateFormat: 'dd/mm/yy',
            onClose: function (selectedDate) {
                // Set the minDate of endDatePicker to the selected date of startDatePicker
                $("#<%= txtEnddate.ClientID %>").datepicker("option", "minDate", selectedDate);
        }
    });
    $("#<%= txtEnddate.ClientID %>").datepicker({
        dateFormat: 'dd/mm/yy',
        onClose: function(selectedDate) {
            // Set the maxDate of startDatePicker to the selected date of endDatePicker
            $("#<%= txtstartdate.ClientID %>").datepicker("option", "maxDate", selectedDate);
        }
    });
    });
</script>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" Runat="Server">
            <style>
    .NoDisplay
    {
        display: none;
    }
</style>
<script type="text/javascript" language="javascript">
    function limitlength(obj, length) {
        var maxlength = length
        if (obj.value.length > maxlength)
            obj.value = obj.value.substring(0, maxlength)
    }

    function LimtCharacters(txtMsg, CharLength, indicator) {
        chars = txtMsg.value.length;
        document.getElementById(indicator).innerHTML = CharLength - chars;
        if (chars > CharLength) {
            txtMsg.value = txtMsg.value.substring(0, CharLength);
        }
    }
    <%--//Start - Bhakti - Post idea fields removal CR
    function ValidateModuleList(source, args) {
        var chkListModules = document.getElementById('<%= chklIndustry.ClientID %>');
        var chkListinputs = chkListModules.getElementsByTagName("input");
        for (var i = 0; i < chkListinputs.length; i++) {
            if (chkListinputs[i].checked) {
                args.IsValid = true;
                return;
            }
        }
        args.IsValid = false;
    }
    //end - Bhakti - Post idea fields removal CR--%>

    function NameAlreadyExist(NameInTextBox, NameFromSelection) {
        var textBox = NameInTextBox;
        if (textBox.indexOf(NameFromSelection) >= 0) {
            return true;
        }
        else {
            return false;
        }
    }

    <%--function ClientItemSelected(sender, e) {
        $get("<%=txtCoIdeators.ClientID %>").value = "";
        if ($get("<%=hfCustomerId.ClientID %>").value == "") {
            $get("<%=hfCustomerId.ClientID %>").value = e.get_value();
        }
        else {
            if (NameAlreadyExist($get("<%=hfCustomerId.ClientID %>").value, e.get_value())) {
                alert("Name already exist...!");
            }
            else
                $get("<%=hfCustomerId.ClientID %>").value = $get("<%=hfCustomerId.ClientID %>").value + ";" + e.get_value();
        }
    }

    function ClientItemSelectedUniv(sender, e) {
        $get("<%=txtCoIdeatorsUniv.ClientID %>").value = "";
        if ($get("<%=hfCustomerIdUniv.ClientID %>").value == "") {
            $get("<%=hfCustomerIdUniv.ClientID %>").value = e.get_value();
        }
        else {
            if (NameAlreadyExist($get("<%=hfCustomerIdUniv.ClientID %>").value, e.get_value())) {
                alert("Name already exist...!");
            }
            else
                $get("<%=hfCustomerIdUniv.ClientID %>").value = $get("<%=hfCustomerIdUniv.ClientID %>").value + ";" + e.get_value();
        }
    }--%>
</script>
    

     <div class="challenge_detail">
     <div class="clearfix">
     </div>
    <asp:HiddenField ID="HiddenField1" runat="server" />
     <div class="form-horizontal">
          <div class="form-group" id="spacestatus" runat="server">                           
            <div class="col-sm-10 nopadding">
                <asp:Label ID="lblstatusresult" runat="server" Text="" style="margin-left: 200px; font-size:16px" ></asp:Label>
            </div>
        </div>
         <div class="form-group">
             
            <label class="control-label col-sm-2 nopadding" for="name">
                <meta charset="utf-8" />
             <span style="white-space:pre-wrap;">Activity</span> Id <span style="color: #ff0000">*</span></label>
            <div class="col-sm-10 nopadding">
                <asp:TextBox ID="txtactvityid" runat="server" CssClass="form-control" ValidationGroup="Entry" 
                    MaxLength="200" 
                    placeholder="xxxxxxxxxxx"></asp:TextBox>
                <asp:RequiredFieldValidator ForeColor="Red" ID="RequiredFieldValidator1" ValidationGroup="Entry"
                    runat="server" ErrorMessage="Please Enter Activity" Display="Dynamic"
                    ControlToValidate="txtactvityid"></asp:RequiredFieldValidator>
                <%--<asp:RegularExpressionValidator ID="RegularExpressionValidator1" ValidationExpression="\b^[\w\d\s\- .,:;@!?€¥£¢$%()‘’”“&/#*+{}?^~•–=']{3,200}$"
                    runat="server" ErrorMessage="Idea Name : Only Characters, Digits and special characters [.,:;@!?€¥£¢$%()‘’”“&/#*+{}?^~•–='] (min - 3, Max - 200)"
                    ControlToValidate="txt_ideaid" Display="Dynamic" ForeColor="Red" ValidationGroup="Entry"></asp:RegularExpressionValidator>--%>
            </div>
        </div>
         <div class="form-group">
             <label class="control-label col-sm-2 nopadding" for="name">
                 <meta charset="utf-8" />
             <span style="white-space:pre-wrap;">Activity Name</span> <span style="color: #ff0000">*</span></label>
             <div class="col-sm-10 nopadding">
                 <asp:TextBox ID="txtactivatyname" runat="server" CssClass="form-control" ValidationGroup="Entry" 
                     MaxLength="200" ToolTip="Only Characters, Digits and special characters [.,:;@!?€¥£¢$%()‘’”“&/#*+{}?^~•–='] (min - 3, Max - 200)"
                     placeholder="xxxxxxxxxxx"></asp:TextBox>
                 <asp:RequiredFieldValidator ForeColor="Red" ID="RequiredFieldValidator12" ValidationGroup="Entry"
                     runat="server" ErrorMessage="Please Enter Activity Name" Display="Dynamic"
                     ControlToValidate="txtactivatyname"></asp:RequiredFieldValidator>
                 
             </div>
         </div>
        
         <div class="form-group">
             <label class="control-label col-sm-2 nopadding" for="name">
                 <meta charset="utf-8" />
             <span style="white-space:pre-wrap;">Type of Activity</span><span style="color: #ff0000">*</span></label>
             <div class="col-sm-10 nopadding">
                 <asp:TextBox ID="txttypeofactivity" runat="server" CssClass="form-control" ValidationGroup="Entry" 
                    MaxLength="200" ToolTip="Only Characters, Digits and special characters [.,:;@!?€¥£¢$%()‘’”“&/#*+{}?^~•–='] (min - 3, Max - 200)"
                    placeholder="Enter Ideators Name"></asp:TextBox>    
                  <asp:RequiredFieldValidator ForeColor="Red" ID="RequiredFieldValidator3" ValidationGroup="Entry"
                     runat="server" ErrorMessage="Please Enter Type of Activity" Display="Dynamic"
                     ControlToValidate="txttypeofactivity"></asp:RequiredFieldValidator>
             </div>
         </div>
        
         <div class="form-group">
             <label class="control-label col-sm-2 nopadding" for="description">
                 Description<span style="color: #ff0000">*</span></label>
             <div class="col-sm-10 nopadding">
                 <asp:TextBox ID="txtContent" CssClass="form-control" Width="100%" Height="100px" TextMode="MultiLine"
                     runat="server" onkeyup="LimtCharacters(this,2000,'lblcount');" onpaste="return limitlength(this, 2000);"
                     onkeypress="return limitlength(this, 2000);" ToolTip="Only Characters, Digits and special characters [.,:;@!?€¥£¢$%()‘’”“&/#*+{}?^~•–='] (min - 3, Max - 2000)"
                     placeholder=""></asp:TextBox>
                 <asp:RequiredFieldValidator ForeColor="Red" ID="RequiredFieldValidator2" ValidationGroup="Entry"
                     runat="server" ErrorMessage="Please Enter Description" Display="Dynamic" ControlToValidate="txtContent"></asp:RequiredFieldValidator>
                 
                 <%--<span class="highlight">Number of Characters Left:</span>
                 <label id="lblcount" style="background-color: #E2EEF1; color: Red;">
                     2000</label>--%>
             </div>
         </div>
          <div class="form-group">
                <label class="control-label col-sm-2 nopadding" for="name">
                    <meta charset="utf-8" />
                <span style="white-space:pre-wrap;">Select Space</span><span style="color: #ff0000">*</span></label>
                <div class="col-sm-10 nopadding">                
                    <asp:DropDownList ID="ddlspacebooking" runat="server" CssClass="form-control">
                        <asp:ListItem Value="0">--Select Type--</asp:ListItem>                    
                        <asp:ListItem Value="1">Working POD 1 (6 person capacity)</asp:ListItem>
                        <asp:ListItem Value="2">Working POD 2 (6 person capacity)</asp:ListItem>
                        <asp:ListItem Value="3">Working POD 3 (6 person capacity)</asp:ListItem>
                        <asp:ListItem Value="4">Creativity Lounge (16 person capacity)</asp:ListItem>
                        <asp:ListItem Value="5">Event Space (6-10 person capacity)</asp:ListItem>
                        <asp:ListItem Value="6">Meeting Room </asp:ListItem>
                    </asp:DropDownList>
                </div>
            </div>
                                              
         <div class="col-lg-8 col-md-9 col-sm-8 nopadding">
            <div class="form-group">
            <label class="control-label col-sm-3 nopadding">
            Duration <span style="color: #ff0000">*</span></label>
            <div class="col-sm-9 nopadding">
            <div class="date col-md-5 col-sm-5 nopadding ">
                <div class="date_txt pull-left col-sm-3 nopadding ">
                    Start
                </div>
                <div class="date_input pull-left input-group col-sm-9 nopadding" id='startdate'>
                    <asp:TextBox ID="txtstartdate" autocomplete="off" AutoCompleteType="None" runat="server"
                        placeholder="dd-mmm-yyyy"></asp:TextBox>
                     <asp:RequiredFieldValidator ForeColor="Red" ID="RequiredFieldValidator4" ValidationGroup="Entry"
                            runat="server" ErrorMessage="Please Enter Start Date" Display="Dynamic" 
                         ControlToValidate="txtstartdate"></asp:RequiredFieldValidator>
                    
                </div>
            </div>
            <div class="date col-md-5 col-sm-5 nopadding ">
                <div class="date_txt pull-left col-sm-3 nopadding ">
                    End
                </div>
                <div class="date_input pull-left input-group col-sm-9 nopadding" id='enddate'>
                    <asp:TextBox ID="txtEnddate" autocomplete="off" AutoCompleteType="None" runat="server"
                        placeholder="dd-mmm-yyyy" ></asp:TextBox>
                    <asp:RequiredFieldValidator ForeColor="Red" ID="RequiredFieldValidator5" ValidationGroup="Entry"
                           runat="server" ErrorMessage="Please Enter End Date" Display="Dynamic" 
                        ControlToValidate="txtEnddate"></asp:RequiredFieldValidator>
                    
                </div>
            </div>
        </div>
            </div>
   
        </div>
        
         <div class="clearfix">
         </div>
         

          <div class="form-group">
            <label class="control-label col-sm-2 nopadding" for="name">
                <meta charset="utf-8" />
            <span style="white-space:pre-wrap;">No. Of Participants:</span><span style="color: #ff0000">*</span></label>
            <div class="col-sm-10 nopadding">                
                 <asp:TextBox ID="txtparticipants" runat="server" CssClass="form-control" ValidationGroup="Entry" 
                    MaxLength="200" 
                    placeholder="0-50"></asp:TextBox>
                <asp:RequiredFieldValidator ForeColor="Red" ID="RequiredFieldValidator6" ValidationGroup="Entry"
                       runat="server" ErrorMessage="No. Of Participants" Display="Dynamic" 
                    ControlToValidate="txtparticipants"></asp:RequiredFieldValidator>
            </div>
        </div>

         <div class="col-lg-6 col-md-6 col-sm-6 nopadding ">
             <%--<asp:Button ID="btnSubmit" runat="server" Text="Submit" ValidationGroup="Entry" CssClass="save"
                 CausesValidation="true" OnClick="btnSubmit_Click"  />--%>
             <asp:Button ID="btnCancel" runat="server" Text="Back" CssClass="submit" OnClick="btnCancel_Click"  />
             <asp:Button ID="btnapprove" runat="server" Text="Approve" CssClass="submit" OnClick="btnapprove_Click" />
            <asp:Button ID="btnreject" runat="server" Text="Reject" CssClass="submit" OnClick="btnreject_Click" />
             <asp:Label ID="lblerrmessage" ForeColor="Red" runat="server" Text=""></asp:Label>
         </div>
         <asp:ValidationSummary ID="ValidationSummary1" runat="server" ShowMessageBox="True"
             ShowSummary="False" ValidationGroup="Entry" />
     </div>
     <div class="clearfix">
     </div>
 </div>
 <!-- script references -->
 <link href="../../css/jquery.mCustomScrollbar.css" rel="stylesheet">
 <script src="../../js/bootstrap.min.js"></script>
 <script src="../../js/scripts.js"></script>
 <script src="../../js/scroll/jquery.nicescroll.min.js"></script>
 <script src="../../js/scroll/custom.js"></script>
</asp:Content>

