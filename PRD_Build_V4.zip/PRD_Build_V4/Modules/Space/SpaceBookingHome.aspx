﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Site.master" AutoEventWireup="true" CodeFile="SpaceBookingHome.aspx.cs" Inherits="Modules_Space_SpaceBookingHome" %>

<asp:Content ID="Content1" ContentPlaceHolderID="HeadContent" Runat="Server">
         <style>
            .classtable{
                 width: 65%;
                 height: 576px;
                 margin-left: 110px;
                 margin-top: 45px;
            }
            .classrow{
                 width: 410px;
                 font-size: 25px;
                 height: 528px;
            }
            .classrowdiv{
                width: 280px;
                height: 450px;
                margin-left: 180px;
                margin-top: 38px;
                background-color: white;
                border: 3px solid orangered;
                border-radius: 30px;
            }
            .classrowimg1{
                margin-left: 69px;
                margin-top: 16%;
                Height:136px;
                Width:144px;
            }
            .classdividea{
                width: 167px;
                height: 49px;
                margin-left: 65px;
                font-size: 12px;
                margin-top: 15px;
                background-color: white;
                text-align:center;
            }
            .classdivideaimg2{
                margin-left: 120px;
                margin-top: 60px;
                Width:37px;
            }
            .classpostidea{
                line-height: 1.1;
                margin-left: 100px;
                font-weight: 900;
                font-size:23px;
            }
</style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" Runat="Server">
    <table class="classtable">
    <tr>
        <td class="classrow">
            <div onclick="window.location='RequestSpaceDashBoard.aspx';" class="classrowdiv">
                <asp:Image ID="Image3" runat="server" ImageUrl="~/images/mccain_events1.png" class="classrowimg1" /><br /><br />
                 
                <div class="classpostidea">
                    <meta charset="utf-8" />
                    <span style="white-space:pre-wrap;">Request<br /><span style="left:10px;position:relative;">Space</span> </span></div>
                <div class="classdividea">  
                    Post ideas for challenges posted by other users and websites
                </div>
                    <asp:ImageButton ID="ImageButton1" runat="server" class="classdivideaimg2" ImageUrl="~/images/mccain_Group.png" />
                </div>            
        </td>
        <td class="classrow">
             <div onclick="window.location='SpaceAllocationDashBoard.aspx';" class="classrowdiv">
             <asp:Image ID="Image1" runat="server" ImageUrl="~/images/mccain_events2.png" class="classrowimg1" /><br /><br />
      
             <div class="classpostidea">
                 <meta charset="utf-8" />
                 <span style="white-space:pre-wrap;">View <br /><span style="right:20px;position:relative;">Dashboard</span> </span></div>
             <div class="classdividea">                    
                 View approved ideas posted by other users of the website
             </div>
                 <asp:ImageButton ID="ImageButton2" runat="server" class="classdivideaimg2" ImageUrl="~/images/mccain_Group.png" />
             </div>          
        </td>
        
    </tr>
</table>
</asp:Content>

