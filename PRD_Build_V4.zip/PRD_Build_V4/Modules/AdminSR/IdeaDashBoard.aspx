﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Site.master" AutoEventWireup="true" CodeFile="IdeaDashBoard.aspx.cs" Inherits="Modules_AdminSR_IdeaDashBoard" %>

<asp:Content ID="Content1" ContentPlaceHolderID="HeadContent" Runat="Server">
    <script src="../../js/jquery.js"></script>
     <style>
        .NoDisplay
        {
            display: none;
        }
         .footerhome {
             position: fixed;
             height: 10px;
             background-color: #FEE000;
             bottom:0px;
             width: 100%;
         }
    </style>

</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" Runat="Server">

 
        <div class="challenge_detail">
        <div class="clearfix">
        </div>
        <br />
        <div class="user-dashboard">
            <div class="btn-group">
                <a class="btn btn-default bradius active" href="IdeaDashBoard.aspx" style="color: #FFFF;width: 25%;">
                    Ideas Dashboard</a> <a class="btn btn-default bradius1 " href="EventDashboard.aspx" style="width: 25%;">
                        Event Dashboard</a> <a class="btn btn-default bradius1 " href="ChallengeDashboard.aspx" style="width: 25%;">
                            Challenge Dashboard</a> <a class="btn btn-default bradius1 " href="SpaceallocationDashboard.aspx" style="width: 25%;">
                                Space Allocation Dashboard</a>
                
            </div>

                   <asp:GridView ID="grViewIdea" runat="server" AutoGenerateColumns="False" 
                        EmptyDataText="No Data Exist" CssClass="table table-bordered" AllowPaging="True"
                         OnRowCommand="grViewIdea_RowCommand" OnRowDataBound="grViewIdea_RowDataBound" OnPageIndexChanging="grViewIdea_PageIndexChanging" >
                        <Columns>
                            <asp:TemplateField HeaderText="Idea Id" ItemStyle-Width="80px">
                                <ItemTemplate>
                                    <asp:LinkButton ID="lblIdeaId" ForeColor="Red" runat="server" CommandName="Select" CommandArgument='<%# Bind("IDEA_ID") %>' Text='<%# Bind("IDEA_ID") %>'></asp:LinkButton>
                                    <%--<asp:Label ID="lblIdeaId" runat="server" Text='<%# Bind("IDEA_ID") %>'></asp:Label>--%>
                                </ItemTemplate>
                            </asp:TemplateField>
                            <asp:TemplateField HeaderText="Idea Name">
                                <ItemTemplate>
                                    <asp:Label ID="lblIdeaName" runat="server" Text='<%# Bind("IDEA_NAME") %>'></asp:Label>
                                </ItemTemplate>
                            </asp:TemplateField>
                            <asp:TemplateField HeaderText="Emp Email" >
                                <ItemTemplate>
                                    <asp:Label ID="lblempemail" runat="server" Text='<%# Bind("IDEA_EMPID") %>'></asp:Label>
                                </ItemTemplate>
                            </asp:TemplateField>
                            <asp:TemplateField HeaderText="Entry Date" ItemStyle-Width="150px" >
                                <ItemTemplate>
                                    <asp:Label ID="lblentrydate" runat="server" Text='<%# Bind("CREATED_ON") %>'></asp:Label>
                                </ItemTemplate>
                            </asp:TemplateField>

                            <%--<asp:TemplateField HeaderText="Duration Start Date" ItemStyle-HorizontalAlign="Center">
                                <ItemTemplate>
                                    <asp:Label ID="lblstartdate" runat="server" Text='<%# Bind("START_DATE") %>'></asp:Label>
                                </ItemTemplate>
                            </asp:TemplateField>
                            <asp:TemplateField HeaderText="Duration End Date" ItemStyle-HorizontalAlign="Center">
                                <ItemTemplate>
                                    <asp:Label ID="lblenddate" runat="server" Text='<%# Bind("END_DATE") %>'></asp:Label>
                                </ItemTemplate>
                            </asp:TemplateField>  --%>
                            
                            <asp:TemplateField HeaderText="Review Status" ItemStyle-Width="150px">
                                <ItemTemplate>
                                    <asp:Label ID="lblStatus" runat="server" Text='<%# Bind("IRIS_STATUS_DESCRIPTION") %>'></asp:Label>
                                </ItemTemplate>
                                <ItemStyle HorizontalAlign="Center"></ItemStyle>
                            </asp:TemplateField>  
                                                    
                        </Columns>
                        <FooterStyle BackColor="White" ForeColor="#000066" />
                        <HeaderStyle BackColor="#006699" Font-Bold="True" ForeColor="White" HorizontalAlign="Center" />
                        <PagerStyle BackColor="White" ForeColor="#000066" HorizontalAlign="Left" />
                        <RowStyle ForeColor="#000066" />
                        <SelectedRowStyle BackColor="#669999" Font-Bold="True" ForeColor="White" />
                        <SortedAscendingCellStyle BackColor="#F1F1F1" />
                        <SortedAscendingHeaderStyle BackColor="#007DBB" />
                        <SortedDescendingCellStyle BackColor="#CAC9C9" />
                        <SortedDescendingHeaderStyle BackColor="#00547E" />
                    </asp:GridView>

             
        </div>
    </div>

    <div class="footerhome" style="text-align: center">
</div>



<!-- script references -->
<link href="../../css/jquery.mCustomScrollbar.css" rel="stylesheet">
<script src="../../js/bootstrap.min.js"></script>
<script src="../../js/scripts.js"></script>
<script src="../../js/scroll/jquery.nicescroll.min.js"></script>
<script src="../../js/scroll/custom.js"></script>
</asp:Content>

