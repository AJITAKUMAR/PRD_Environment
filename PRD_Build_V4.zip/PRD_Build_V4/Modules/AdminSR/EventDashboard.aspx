﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Site.master" AutoEventWireup="true" CodeFile="EventDashboard.aspx.cs" Inherits="Modules_AdminSR_EventDashboard" %>

<asp:Content ID="Content1" ContentPlaceHolderID="HeadContent" Runat="Server">
    <script src="../../js/jquery.js"></script>
     <style>
    .NoDisplay
    {
        display: none;
    }
         .footerhome {
             position: fixed;
             height: 10px;
             background-color: #FEE000;
             bottom:0px;
             width: 100%;
         }
</style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" Runat="Server">
    


        <div class="challenge_detail">
    <div class="clearfix">
    </div>
    <br />
    <div class="user-dashboard">
        <%--<div class="btn-group">
            <a class="btn btn-default bradius" href="IdeaDashBoard.aspx" style="color: black">
                Ideas Dashboard</a> <a class="btn btn-default bradius active" href="EventDashboard.aspx">
                    Event Dashboard</a> <a class="btn btn-default bradius1 " href="ChallengeDashboard.aspx">
                        Challenge Dashboard</a> <a class="btn btn-default bradius1 " href="SpaceallocationDashboard.aspx">
                            Space Allocation Dashboard</a>
           
        </div>--%>
        <div class="btn-group">
    <a class="btn btn-default bradius" href="IdeaDashBoard.aspx" style="width: 25%;">
        Ideas Dashboard</a> <a class="btn btn-default bradius1 active " href="EventDashboard.aspx" style="width: 25%;">
            Event Dashboard</a> <a class="btn btn-default bradius1 " href="ChallengeDashboard.aspx" style="width: 25%;">
                Challenge Dashboard</a> <a class="btn btn-default bradius1 " href="SpaceallocationDashboard.aspx" style="width: 25%;">
                    Space Allocation Dashboard</a>
    
</div>
         

        <asp:GridView ID="grViewIdea" runat="server" AutoGenerateColumns="False" 
            EmptyDataText="No Data Exist" CssClass="table table-bordered" AllowPaging="True"
              OnRowCommand="grViewIdea_RowCommand" OnRowDataBound="grViewIdea_RowDataBound" OnPageIndexChanging="grViewIdea_PageIndexChanging">
            <Columns>
                <asp:TemplateField HeaderText="Event Id" ItemStyle-Width="80px">
                    <ItemTemplate>
                        <asp:LinkButton ID="lbleventid" ForeColor="Red" runat="server" CommandName="Select" CommandArgument='<%# Bind("EVENT_ID") %>' Text='<%# Bind("EVENT_ID") %>'></asp:LinkButton>
                        <%--<asp:Label ID="lblIdeaId" runat="server" Text='<%# Bind("IDEA_ID") %>'></asp:Label>--%>
                    </ItemTemplate>
                </asp:TemplateField>
                <asp:TemplateField HeaderText="Event Name">
                    <ItemTemplate>
                        <asp:Label ID="lbleventname" runat="server" Text='<%# Bind("EVENT_TYPE") %>'></asp:Label>
                    </ItemTemplate>
                </asp:TemplateField>
                <asp:TemplateField HeaderText="Emp Email">
                    <ItemTemplate>
                        <asp:Label ID="lblempid" runat="server" Text='<%# Bind("EMP_ID") %>'></asp:Label>
                    </ItemTemplate>
                </asp:TemplateField>
                <asp:TemplateField HeaderText="Date" ItemStyle-Width="150px">
                    <ItemTemplate>
                        <asp:Label ID="lblcreatedate" runat="server" Text='<%# Bind("CREATED_ON") %>'></asp:Label>
                    </ItemTemplate>
                </asp:TemplateField>

                <%--<asp:TemplateField HeaderText="Duration Start Date">
                    <ItemTemplate>
                        <asp:Label ID="lbleventstartdate" runat="server" Text='<%# Bind("EVENT_START_DATE") %>'></asp:Label>
                    </ItemTemplate>
                </asp:TemplateField>
                <asp:TemplateField HeaderText="Duration End Date">
                    <ItemTemplate>
                        <asp:Label ID="lbleventenddate" runat="server" Text='<%# Bind("EVENT_END_DATE") %>'></asp:Label>
                    </ItemTemplate>
                </asp:TemplateField>--%>
                <asp:TemplateField HeaderText="Review Status" ItemStyle-Width="200px">
                    <ItemTemplate>
                        <asp:Label ID="lbleventstatus" runat="server" Text='<%# Bind("EVENT_STATUS") %>'></asp:Label>
                    </ItemTemplate>
                    <ItemStyle HorizontalAlign="Center"></ItemStyle>
                </asp:TemplateField>  
                <asp:TemplateField HeaderText="Space Allocation Request" Visible="false">
                    <ItemTemplate>
                        <asp:LinkButton ID="lnkspacerequestid" runat="server" CommandName="SpaceRequest" CommandArgument='<%# Bind("EVENT_ID") %>' Text="Request For Space" />
                    </ItemTemplate>
                   <ItemStyle HorizontalAlign="Center"></ItemStyle>
                </asp:TemplateField>                             
            </Columns>
            <FooterStyle BackColor="White" ForeColor="#000066" />
            <HeaderStyle BackColor="#006699" Font-Bold="True" ForeColor="White" HorizontalAlign="Center" />
            <PagerStyle BackColor="White" ForeColor="#000066" HorizontalAlign="Left" />
            <RowStyle ForeColor="#000066" />
            <SelectedRowStyle BackColor="#669999" Font-Bold="True" ForeColor="White" />
            <SortedAscendingCellStyle BackColor="#F1F1F1" />
            <SortedAscendingHeaderStyle BackColor="#007DBB" />
            <SortedDescendingCellStyle BackColor="#CAC9C9" />
            <SortedDescendingHeaderStyle BackColor="#00547E" />
        </asp:GridView>



    </div>
</div>
 <div class="footerhome" style="text-align: center">
</div>



<!-- script references -->
<link href="../../css/jquery.mCustomScrollbar.css" rel="stylesheet">
<script src="../../js/bootstrap.min.js"></script>
<script src="../../js/scripts.js"></script>
<script src="../../js/scroll/jquery.nicescroll.min.js"></script>
<script src="../../js/scroll/custom.js"></script>
</asp:Content>

