﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Site.master" AutoEventWireup="true" CodeFile="SpaceallocationDashboard.aspx.cs" Inherits="Modules_AdminSR_SpaceallocationDashboard" %>

<asp:Content ID="Content1" ContentPlaceHolderID="HeadContent" Runat="Server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" Runat="Server">
     <style>
         .NoDisplay {
             display: none;
         }
         .footerhome {
             position: fixed;
             height: 10px;
             background-color: #FEE000;
             bottom:0px;
             width: 100%;
         }
</style>

<div class="challenge_detail">
   
    <div class="clearfix">
    </div>
    <br />
    <div class="user-dashboard">
           <div class="btn-group">
                <a class="btn btn-default bradius" href="IdeaDashBoard.aspx" style="width: 25%;">
                    Ideas Dashboard</a> <a class="btn btn-default bradius1" href="EventDashboard.aspx" style="width: 25%;">
                        Event Dashboard</a> <a class="btn btn-default bradius1 " href="ChallengeDashboard.aspx" style="width: 25%;">
                            Challenge Dashboard</a> <a class="btn btn-default bradius1 active " href="SpaceallocationDashboard.aspx" style="width: 25%;">
                                Space Allocation Dashboard</a>
    
            </div>       


        
        <asp:GridView ID="grViewIdea" runat="server" AutoGenerateColumns="False" 
    EmptyDataText="No Data Exist" CssClass="table table-bordered" AllowPaging="True"  OnPageIndexChanging="grViewIdea_PageIndexChanging" OnRowDataBound="grViewIdea_RowDataBound" OnRowCommand="grViewIdea_RowCommand">
    <Columns>
        <asp:TemplateField HeaderText="Space BookingID" ItemStyle-Width="100px" ItemStyle-HorizontalAlign="Center">
            <ItemTemplate>
                <asp:LinkButton ID="lblSB_ID" ForeColor="Red" runat="server" CommandName="Select" CommandArgument='<%# Bind("SB_ID") %>' Text='<%# Bind("SB_ID") %>'></asp:LinkButton>
                <%--<asp:LinkButton ID="lblSB_ID" runat="server" Text='<%# Bind("SB_ID") %>'></asp:LinkButton>--%>
            </ItemTemplate>
        </asp:TemplateField>
        <asp:TemplateField HeaderText="ACTIVITY ID">
            <ItemTemplate>
                <asp:Label ID="lblACTIVITYID" runat="server" Text='<%# Bind("ACTIVITY_ID") %>'></asp:Label>
            </ItemTemplate>
        </asp:TemplateField>
        <asp:TemplateField HeaderText="ACTIVITY NAME">
            <ItemTemplate>
                <asp:Label ID="lblACTIVITYNAME" runat="server" Text='<%# Bind("ACTIVITY_NAME") %>'></asp:Label>
            </ItemTemplate>
        </asp:TemplateField> 
        <asp:TemplateField HeaderText="ACTIVITY TYPE">
            <ItemTemplate>
                <asp:Label ID="lblACTIVITYTYPE" runat="server" Text='<%# Bind("ACTIVITY_TYPE") %>'></asp:Label>
            </ItemTemplate>
        </asp:TemplateField> 
        <asp:TemplateField HeaderText="START DATE" ItemStyle-Width="100px">
           <ItemTemplate>
               <asp:Label ID="lblSTARTDATE" runat="server" Text='<%# Bind("START_DATE") %>'></asp:Label>
           </ItemTemplate>
       </asp:TemplateField>
         <asp:TemplateField HeaderText="END DATE" ItemStyle-Width="100px">
            <ItemTemplate>
                <asp:Label ID="lblENDDATE" runat="server" Text='<%# Bind("END_DATE") %>'></asp:Label>
            </ItemTemplate>
        </asp:TemplateField>
         <asp:TemplateField HeaderText="TYPE OF SPACE" ItemStyle-Width="200px">
            <ItemTemplate>
                <asp:Label ID="lblSPACE" runat="server" Text='<%# Bind("SPACE") %>'></asp:Label>
            </ItemTemplate>
        </asp:TemplateField>
         <asp:TemplateField HeaderText="STATUS" ItemStyle-Width="100px">
            <ItemTemplate>
                <%--<asp:Label ID="lblSTSTUS" runat="server" Text='<%# Bind("STATUS") %>'></asp:Label>--%>
                <asp:LinkButton ID="lnkSTSTUS" Enabled="false" runat="server" CommandName="SpaceRequest" CommandArgument='<%# Bind("ACTIVITY_ID") %>' Text='<%# Bind("STATUS") %>'></asp:LinkButton>
            </ItemTemplate>
        </asp:TemplateField>
        <%--<asp:TemplateField HeaderText="Space BookingID" ItemStyle-Width="100px" ItemStyle-HorizontalAlign="Center">
        <ItemTemplate>
            <asp:LinkButton ID="lblSB_ID" ForeColor="Red" runat="server" CommandName="SpaceRequest" CommandArgument='<%# Bind("ACTIVITY_ID") %>' Text='<%# Bind("ACTIVITY_ID") %>'></asp:LinkButton>
           
        </ItemTemplate>
    </asp:TemplateField>--%>
       
    </Columns>
    <FooterStyle BackColor="#507CD1" Font-Bold="True" ForeColor="White" />
    <HeaderStyle BackColor="#507CD1" Font-Bold="True" ForeColor="White" HorizontalAlign="Center" />
    <RowStyle BackColor="#EFF3FB" />
</asp:GridView>
     

                           

    </div>
</div>
<div class="footerhome" style="text-align: center">
</div>

<!-- script references -->
<link href="../../css/jquery.mCustomScrollbar.css" rel="stylesheet">
<script src="../../js/bootstrap.min.js"></script>
<script src="../../js/scripts.js"></script>
<script src="../../js/scroll/jquery.nicescroll.min.js"></script>
<script src="../../js/scroll/custom.js"></script>
</asp:Content>

