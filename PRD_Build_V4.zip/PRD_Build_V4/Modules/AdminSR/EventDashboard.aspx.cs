﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Modules_AdminSR_EventDashboard : System.Web.UI.Page
{
    BusinessLayer.IRIS_BusinessLayer objClass1_BL = new BusinessLayer.IRIS_BusinessLayer();
    string path = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            path = HttpContext.Current.Request.Url.AbsolutePath;
            if (!IsPostBack)
            {
                if (Session["UserId"] == null || Convert.ToString(Session["UserId"]) == "")
                {
                    Response.Redirect("~/Login.aspx?r=" + CommonFunctions.GetRandomNumber(), false);
                }
                grViewIdea.PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["ViewMyIdea_grViewIdea"].ToString());
                BindGrid();
                Session["EarlierPage"] = null;
                Session["PreviousPage"] = null;
            }
        }
        catch (Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }
        }
       
    }

    public void BindGrid()
    {

        try
        {            
            string EmpId = "";
            string AllEvent = "";
            DataSet ds = objClass1_BL.GET_EVENT_DETAILS(EmpId, AllEvent);
            if (ds.Tables.Count > 0)
            {
                grViewIdea.DataSource = ds;
                grViewIdea.DataBind();


            }
        }
        catch (Exception ex)
        {
            Session["Error"] = ex.ToString();
            Response.Redirect("~/ErrorPage.aspx");
        }
    }

    protected void grViewIdea_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grViewIdea.PageIndex = e.NewPageIndex;
        BindGrid();
    }


    protected void grViewIdea_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        Session["selectedideaid"] = "";
        Session["RequestSpaceId"] = "";
        Session["selectedideaid"] = null;
        Session["RequestSpaceId"] = null;
        Session["postbackurl"] = "";
        Session["postbackurl"] = null;
        int rowIndexId = Convert.ToInt32(e.CommandArgument);
        if (e.CommandName == "Select")
        {
            Session["postbackurl"] = path;
            HttpContext.Current.Session["selectedideaid"] = rowIndexId;
            Response.Redirect("~/Modules/Events/PostEvents.aspx");
        }
        else if (e.CommandName == "SpaceRequest")
        {
            HttpContext.Current.Session["RequestSpaceId"] = rowIndexId;
            Response.Redirect("~/Modules/Space/BookingSpace.aspx");
        }

    }
    protected void grViewIdea_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                Label lblstr = (Label)e.Row.FindControl("lbleventstatus");
                string statustext = ((Label)(e.Row.Cells[5].FindControl("lbleventstatus"))).Text;

                LinkButton lnkspacerequestid = (LinkButton)e.Row.FindControl("lnkspacerequestid");


                if (statustext == "600")
                {
                    lblstr.Text = "Approved";
                    e.Row.Cells[4].BackColor = Color.Green;
                    e.Row.Cells[4].ForeColor = Color.White;
                    //lnkspacerequestid.Visible = true;
                }
                else if (statustext == "601")
                {
                    lblstr.Text = "Rejected";
                    e.Row.Cells[4].BackColor = Color.Red;
                    e.Row.Cells[4].ForeColor = Color.White;
                    //lnkspacerequestid.Enabled = false;
                    //lnkspacerequestid.Text = "NA";
                }
                else if (statustext == "602")
                {
                    lblstr.Text = "Pending";
                    e.Row.Cells[4].BackColor = Color.Orange;
                    e.Row.Cells[4].ForeColor = Color.White;
                    //lnkspacerequestid.Enabled = false;
                    //lnkspacerequestid.Text = "NA";
                }
                else
                {
                    e.Row.Cells[5].BackColor = Color.Orange;
                    e.Row.Cells[5].ForeColor = Color.White;
                    lnkspacerequestid.Visible = false;
                    lnkspacerequestid.Text = "NA";
                }


            }
        }
        catch (Exception ex)
        {
            Session["Error"] = ex.ToString();
            Response.Redirect("~/ErrorPage.aspx");
        }
    }
}