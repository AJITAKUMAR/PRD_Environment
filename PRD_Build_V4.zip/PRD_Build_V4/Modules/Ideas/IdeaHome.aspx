﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Site.master" AutoEventWireup="true" CodeFile="IdeaHome.aspx.cs" Inherits="Modules_Ideas_IdeaHome" %>

<asp:Content ID="Content1" ContentPlaceHolderID="HeadContent" Runat="Server">
    <style>
        .classtable {
            width: 85%;
            height: 615px;
            margin-left: 110px;
            margin-top: 45px;
        }
        /*.classrow {
            width: 410px;
            font-size: 25px;
            height: 528px;
        }*/
        /*.classrowdiv {
            width: 280px;
            height: 450px;
            margin-left: 50px;
            margin-top: 70px;
            background-color: white;
            border: 3px solid orangered;
            border-radius: 10px;
        }*/
        .classrowimg1 {
            margin-left: 69px;
            margin-top: 16%;
            Height: 136px;
            Width: 144px;
        }
        .classdividea {
            width: 167px;
            height: 49px;
            margin-left: 65px;
            font-size: 12px;
            margin-top: 15px;
            background-color: white;
            text-align: center;
        }
        .classdivideaimg2 {
            margin-left: 50px;
            margin-top: 60px;
            Width: 300px;
        }
        .classdivideaimg3 {
            margin-left: 50px;
            margin-top: 60px;
            Width: 290px;
        }
        .classpostidea {
            line-height: 1.1;
            margin-left: 110px;
            color: #000;
            font-family: "Red Hat Display";
            font-size: 25px;
            font-style: normal;
            font-weight: 900;
        }
        
        .footerhome {
            position: fixed;
            height: 10px;
            background-color: #FEE000;
            bottom:0px;
            width: 100%;
        }
</style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" Runat="Server">
       <table class="classtable">
    <tr>
        <td class="classrow">
            <div onclick="window.location='PostIdea.aspx';" class="classrowdiv">
                <asp:ImageButton ID="ImageButton1" runat="server" class="classdivideaimg2" ImageUrl="~/images/ideahome_postdea.png" PostBackUrl="~/Modules/Ideas/PostIdea.aspx" />
                <%--<asp:Image ID="Image3" runat="server" ImageUrl="~/images/mccain_ellipse.png" class="classrowimg1" /><br /><br />
                 
                <div class="classpostidea"><span>Post<br /> Ideas</span></div>
                <div class="classdividea">                    
                    Post Ideas for Active Challenges
                </div>--%>
                    
            </div>            
        </td>
        <td class="classrow">
          <div onclick="window.location='ViewMyIdea.aspx';" class="classrowdiv">
             <%--<asp:Image ID="Image1" runat="server" ImageUrl="~/images/mccain_ellipse53.png" class="classrowimg1" /><br /><br />
      
             <div class="classpostidea"><span>View<br />
                 Ideas</span></div>
             <div class="classdividea">                    
                 View Ideas Posted by Others </div>--%>
                 <asp:ImageButton ID="ImageButton2" runat="server" class="classdivideaimg3" ImageUrl="~/images/ideahome_viewidea.png" PostBackUrl="~/Modules/Ideas/ViewMyIdea.aspx" />
          </div>
         
        </td>
        <td class="classrow">
         <div onclick="window.location='ViewMyIdeas.aspx';" class="classrowdiv">
            <%--<asp:Image ID="Image2" runat="server" ImageUrl="~/images/mccain_ellipse55.png" class="classrowimg1" /><br /><br />
     
            <div class="classpostidea">My<span><br /> Ideas</span></div>
            <div class="classdividea">                    
                View Ideas Posted by You
            </div>--%>
                <asp:ImageButton ID="ImageButton3" runat="server" class="classdivideaimg2" ImageUrl="~/images/Ideahome_youridea.png" PostBackUrl="~/Modules/Ideas/ViewMyIdeas.aspx" />
         </div>  
            
        </td>
    </tr>
</table>
    <div class="footerhome" style="text-align: center">

    </div>
</asp:Content>

