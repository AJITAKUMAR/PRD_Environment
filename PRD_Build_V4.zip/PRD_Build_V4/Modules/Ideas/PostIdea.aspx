﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Site.master" AutoEventWireup="true"
    CodeFile="PostIdea.aspx.cs" Inherits="Modules_Ideas_PostIdea" %>

<asp:Content ID="Content1" ContentPlaceHolderID="HeadContent" runat="Server">
    <script src="../../js/jquery.js" type="text/javascript"></script>
    <link href="../../css/jquery.feedBackBox.css" rel="stylesheet" />
   <%-- --------------------------use this for calender------------------------------------%>      
    <link href="../../css/jquery-ui.css" rel="stylesheet" />
    <script src="../../js/jquery-3.6.0.min.js"></script>
    <script src="../../js/jquery-ui.min.js"></script>
     <%-- --------------------------use this for calender------------------------------------%>

    <script type="text/javascript">
        $(function () {
            $("#<%= txtstartdate.ClientID %>").datepicker({
                dateFormat: 'dd/mm/yy',
                onClose: function (selectedDate) {
                    // Set the minDate of endDatePicker to the selected date of startDatePicker
                    $("#<%= txtEnddate.ClientID %>").datepicker("option", "minDate", selectedDate);
            }
        });
        $("#<%= txtEnddate.ClientID %>").datepicker({
            dateFormat: 'dd/mm/yy',
            onClose: function(selectedDate) {
                // Set the maxDate of startDatePicker to the selected date of endDatePicker
                $("#<%= txtstartdate.ClientID %>").datepicker("option", "maxDate", selectedDate);
            }
        });
        });
    </script>
    <style>
        .NoDisplay {
            display: none;
        }
        .classfromcontrollbl {
            border-radius: 0px;
            padding: 12px 12px;
            height: auto;
            position: relative;
            top: -57px;
            left: 626px;
            width: 230px;
        }
        .classpostidea {
            line-height: 1.1;
            margin-left: 211px;
            font-weight: 900;
            font-size: 18px;
            margin-bottom: 25px;
        }
        .footerhome {
            position: fixed;
            height: 10px;
            background-color: #FEE000;
            bottom:0px;
            width: 100%;
        }

    
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="Server">
    <style>
        
    </style>
    <script type="text/javascript" language="javascript">
        function limitlength(obj, length) {
            var maxlength = length
            if (obj.value.length > maxlength)
                obj.value = obj.value.substring(0, maxlength)
        }

        function LimtCharacters(txtMsg, CharLength, indicator) {
            chars = txtMsg.value.length;
            document.getElementById(indicator).innerHTML = CharLength - chars;
            if (chars > CharLength) {
                txtMsg.value = txtMsg.value.substring(0, CharLength);
            }
        }
       

        function NameAlreadyExist(NameInTextBox, NameFromSelection) {
            var textBox = NameInTextBox;
            if (textBox.indexOf(NameFromSelection) >= 0) {
                return true;
            }
            else {
                return false;
            }
        }

       
    </script>
    
    <div class="challenge_detail">
        <div class="clearfix">
        </div>
        <div class="form-horizontal">    
            <div class="classpostidea" id="divrequestid" runat="server">
                Request Id:- <asp:Label ID="idea_id" runat="server" Text=""></asp:Label><asp:Label ID="lbl_status" Style="left: 20px;position: relative;" runat="server" Text=""></asp:Label> <asp:HiddenField ID="HiddenField1" runat="server" />
            </div>
            <div class="form-group">                
                <label class="control-label col-sm-2 nopadding" for="name">
                    Idea Name <span style="color: #ff0000"> *</span></label>
                <div class="col-sm-10 nopadding">
                    <asp:TextBox ID="txtIdeaName" runat="server" CssClass="form-control" ValidationGroup="Entry"
                        MaxLength="200" ToolTip="Only Characters, Digits and special characters [.,:;@!?€¥£¢$%()‘’”“&/#*+{}?^~•–='] (min - 3, Max - 200)"
                        placeholder="Enter Idea Name"></asp:TextBox>
                    <asp:RequiredFieldValidator ForeColor="Red" ID="RequiredFieldValidator12" ValidationGroup="Entry"
                        runat="server" ErrorMessage="Please Enter Idea Name" Display="Dynamic"
                        ControlToValidate="txtIdeaName"></asp:RequiredFieldValidator>                   
                </div>
            </div>
           
            <div class="form-group">
                <label class="control-label col-sm-2 nopadding" for="description">
                    Description<span style="color: #ff0000"> *</span></label>
                <div class="col-sm-10 nopadding">
                    <asp:TextBox ID="txtContent" CssClass="form-control" Width="100%" Height="100px" TextMode="MultiLine"
                        runat="server" 
                        onkeypress="return limitlength(this, 2000);" ToolTip=""
                        placeholder="Enter Description"></asp:TextBox>
                    <asp:RequiredFieldValidator ForeColor="Red" ID="RequiredFieldValidator2" ValidationGroup="Entry"
                        runat="server" ErrorMessage="Please Enter Description" Display="Dynamic" 
                        ControlToValidate="txtContent"></asp:RequiredFieldValidator>                    
                </div>
            </div>
            <%-- ---------------------------------------start----------------------------------------------------------------%>
            <div class="form-group">
                <label class="control-label col-sm-2 nopadding" for="name">
                    Region <span style="color: #ff0000"> *</span> </label>                
                <div class="col-sm-10 nopadding">
                    <asp:DropDownList ID="ddllocation" runat="server" CssClass="form-control">
                        <asp:ListItem Value="0">-- Select --</asp:ListItem>
                        <asp:ListItem Value="ANZ">ANZ</asp:ListItem>
                        <asp:ListItem Value="APACSA">APACSA</asp:ListItem>
                        <asp:ListItem Value="GB">GB</asp:ListItem>
                        <asp:ListItem Value="LATM">LATM</asp:ListItem>
                        <asp:ListItem Value="NA">NA</asp:ListItem>
                        <asp:ListItem Value="Global">Global</asp:ListItem>
                    </asp:DropDownList>
                    <asp:RequiredFieldValidator ForeColor="Red" ID="RequiredFieldValidator8" ValidationGroup="Entry"
                        runat="server" ErrorMessage="Please Select Region" Display="Dynamic" InitialValue="0" 
                        ControlToValidate="ddllocation"></asp:RequiredFieldValidator>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-2 nopadding" for="name">
                    Business Unit <span style="color: #ff0000"> *</span></label>                
                <div class="col-sm-10 nopadding">
                    <asp:DropDownList ID="ddlbusinessunit" runat="server" CssClass="form-control">
                        <asp:ListItem Value="0">-- Select --</asp:ListItem>
                        <asp:ListItem Value="Agriculture">Agriculture</asp:ListItem>
                        <asp:ListItem Value="Commercial/Sales">Commercial/Sales</asp:ListItem>
                        <asp:ListItem Value="Marketing">Marketing</asp:ListItem>
                        <asp:ListItem Value="Manufacturing">Manufacturing</asp:ListItem>
                        <asp:ListItem Value="Supply Chain">Supply Chain</asp:ListItem>
                        <asp:ListItem Value="Finance">Finance</asp:ListItem>
                        <asp:ListItem Value="HR">HR</asp:ListItem>                        
                    </asp:DropDownList>  
                    <asp:RequiredFieldValidator ForeColor="Red" ID="RequiredFieldValidator9" ValidationGroup="Entry"
                        runat="server" ErrorMessage="Please Select Business Unit" Display="Dynamic" InitialValue="0" ControlToValidate="ddlbusinessunit"></asp:RequiredFieldValidator>
                </div>
            </div>
           <div class="form-group">
                <label class="control-label col-sm-2 nopadding" for="name">
                    Project Sponsor <span style="color: #ff0000"> *</span></label>
                <div class="col-sm-10 nopadding">
                    <asp:TextBox ID="txtprojectsponser" runat="server" CssClass="form-control" ValidationGroup="Entry"
                        MaxLength="200" ToolTip="Only Characters, Digits and special characters [.,:;@!?€¥£¢$%()‘’”“&/#*+{}?^~•–='] (min - 3, Max - 200)"
                        placeholder=""></asp:TextBox>
                    <asp:RequiredFieldValidator ForeColor="Red" ID="RequiredFieldValidator7" ValidationGroup="Entry"
                        runat="server" ErrorMessage="Please Enter Project Sponsor" Display="Dynamic"
                        ControlToValidate="txtprojectsponser"></asp:RequiredFieldValidator>
                    
                </div>
            </div>    

            <%--<div class="form-group">
                <label class="control-label col-sm-2 nopadding" for="name">
                    Add Team Members </label>
                <div class="col-sm-10 nopadding">
                    <asp:TextBox ID="txtteammember" runat="server" CssClass="form-control" ValidationGroup="Entry"
                        MaxLength="200" ToolTip="Only Characters, Digits and special characters [.,:;@!?€¥£¢$%()‘’”“&/#*+{}?^~•–='] (min - 3, Max - 200)"
                        placeholder="Optional"></asp:TextBox>
                  
                   
                </div>
            </div>--%>

            <div class="form-group">
                <label class="control-label col-sm-2 nopadding" for="name">
                    2030 Strategy Elements <span style="color: #ff0000"> *</span></label>
                <div class="col-sm-10 nopadding">
                    <asp:DropDownList ID="ddlpurpose" runat="server" CssClass="form-control">
                    <asp:ListItem Value="0">-- Select --</asp:ListItem>
                    <asp:ListItem Value="Project">Undisputed Potato Leadership</asp:ListItem>
                    <asp:ListItem Value="Team Meeting">More of the Menu</asp:ListItem>
                    <asp:ListItem Value="Workshop/Training">From Good to Exceptional</asp:ListItem>                                         
                </asp:DropDownList>  
                <asp:RequiredFieldValidator ForeColor="Red" ID="RequiredFieldValidator4" ValidationGroup="Entry"
                    runat="server" ErrorMessage="Please Select 2030 Strategy Elements" Display="Dynamic" InitialValue="0" ControlToValidate="ddlpurpose"></asp:RequiredFieldValidator>




                    <%--<asp:TextBox ID="txtpurpose" runat="server" CssClass="form-control" ValidationGroup="Entry"
                        MaxLength="200" ToolTip="Only Characters, Digits and special characters [.,:;@!?€¥£¢$%()‘’”“&/#*+{}?^~•–='] (min - 3, Max - 200)"
                        placeholder=""></asp:TextBox>
                    <asp:RequiredFieldValidator ForeColor="Red" ID="RequiredFieldValidator5" ValidationGroup="Entry"
                        runat="server" ErrorMessage="Please Enter Purpose" Display="Dynamic"
                        ControlToValidate="txtpurpose"></asp:RequiredFieldValidator>--%>
                  
                </div>
            </div>
            <br />

            <div class="col-lg-8 col-md-9 col-sm-8 nopadding">
                <div class="form-group">
                    <label class="control-label col-sm-3 nopadding">
                       Duration <span style="color: #ff0000"> *</span></label>
                    <div class="col-sm-9 nopadding">
                        <div class="date col-md-5 col-sm-5 nopadding ">
                            <div class="date_txt pull-left col-sm-3 nopadding ">
                                Start
                            </div>
                            <div class="date_input pull-left input-group col-sm-9 nopadding" id='startdate'>
                                <asp:TextBox ID="txtstartdate" autocomplete="off" AutoCompleteType="None" runat="server"
                                    placeholder="dd-mm-yyyy"></asp:TextBox>
                                <asp:RequiredFieldValidator ForeColor="Red" ID="RequiredFieldValidator10" ValidationGroup="Entry"
                                    runat="server" ErrorMessage="Please Enter Start Date" Display="Dynamic"
                                    ControlToValidate="txtstartdate"></asp:RequiredFieldValidator>
                    
                            </div>
                        </div>
                        <div class="date col-md-5 col-sm-5 nopadding ">
                            <div class="date_txt pull-left col-sm-3 nopadding ">
                                End
                            </div>
                            <div class="date_input pull-left input-group col-sm-9 nopadding" id='enddate'>
                                <asp:TextBox ID="txtEnddate" autocomplete="off" AutoCompleteType="None" runat="server"
                                    placeholder="dd-mm-yyyy" ></asp:TextBox>
                               <asp:RequiredFieldValidator ForeColor="Red" ID="RequiredFieldValidator11" ValidationGroup="Entry"
                                    runat="server" ErrorMessage="Please Enter End Date" Display="Dynamic"
                                    ControlToValidate="txtEnddate"></asp:RequiredFieldValidator>
                    
                            </div>
                        </div>
                    </div>
                </div>
    
            </div>
             <div class="clearfix">
             </div>
             <div class="clearfix">
             </div>
           

             <div class="form-group">
                 <label class="control-label col-sm-2 nopadding" for="name">
         
            No. of Participants<span style="color: #ff0000"> *</span></label>
                 <div class="col-sm-10 nopadding">
                     <asp:TextBox ID="noofpeople" runat="server" CssClass="form-control" ValidationGroup="Entry"
                         MaxLength="200" placeholder="" onkeydown = "return (!(event.keyCode>=65) && event.keyCode!=32);"></asp:TextBox>
                     <asp:RequiredFieldValidator ForeColor="Red" ID="RequiredFieldValidator1" ValidationGroup="Entry"
                         runat="server" ErrorMessage="Please Enter How many people do you expect to join you" Display="Dynamic"
                         ControlToValidate="noofpeople"></asp:RequiredFieldValidator>
                     <%--<asp:RegularExpressionValidator ID="RegularExpressionValidator1" ValidationExpression="\b^[\w\d\s\- .,:;@!?€¥£¢$%()‘’”“&/#*+{}?^~•–=']{3,200}$"
                         runat="server" ErrorMessage="Idea Name : Only Characters, Digits and special characters [.,:;@!?€¥£¢$%()‘’”“&/#*+{}?^~•–='] (min - 3, Max - 200)"
                         ControlToValidate="txtIdeaName" Display="Dynamic" ForeColor="Red" ValidationGroup="Entry"></asp:RegularExpressionValidator>--%>
                 </div>
             </div>


             <div class="form-group">
                 <label class="control-label col-sm-2 nopadding" for="name">         
           Participant Emails <span style="color: #ff0000"> *</span></label>
                 <div class="col-sm-10 nopadding">
                     <asp:TextBox ID="nameofthepeople" runat="server" CssClass="form-control" ValidationGroup="Entry"
                         MaxLength="200" ToolTip=""
                         placeholder="Comma Separated"></asp:TextBox>
                     <asp:RequiredFieldValidator ForeColor="Red" ID="RequiredFieldValidator3" ValidationGroup="Entry"
                         runat="server" ErrorMessage="Please Enter Names of these people" Display="Dynamic"
                         ControlToValidate="nameofthepeople"></asp:RequiredFieldValidator>
                     <%--<asp:RegularExpressionValidator ID="RegularExpressionValidator2" ValidationExpression="\b^[\w\d\s\- .,:;@!?€¥£¢$%()‘’”“&/#*+{}?^~•–=']{3,200}$"
                         runat="server" ErrorMessage="Idea Name : Only Characters, Digits and special characters [.,:;@!?€¥£¢$%()‘’”“&/#*+{}?^~•–='] (min - 3, Max - 200)"
                         ControlToValidate="txtIdeaName" Display="Dynamic" ForeColor="Red" ValidationGroup="Entry"></asp:RegularExpressionValidator>--%>
                 </div>
             </div>

              <div class="form-group">
      <label class="control-label col-sm-2 nopadding" for="name">         
No. of External People <span style="color: #ff0000"> *</span></label>
      <div class="col-sm-10 nopadding">
          <asp:TextBox ID="noofexternalpeople" runat="server" CssClass="form-control" ValidationGroup="Entry"
              MaxLength="200" ToolTip="" placeholder="" onkeydown = "return (!(event.keyCode>=65) && event.keyCode!=32);"></asp:TextBox>
          <asp:RequiredFieldValidator ForeColor="Red" ID="RequiredFieldValidator6" ValidationGroup="Entry"
              runat="server" ErrorMessage="Please Enter No. of external people" Display="Dynamic"
              ControlToValidate="noofexternalpeople"></asp:RequiredFieldValidator>
          <%--<asp:RegularExpressionValidator ID="RegularExpressionValidator6" ValidationExpression="\b^[\w\d\s\- .,:;@!?€¥£¢$%()‘’”“&/#*+{}?^~•–=']{3,200}$"
              runat="server" ErrorMessage="Idea Name : Only Characters, Digits and special characters [.,:;@!?€¥£¢$%()‘’”“&/#*+{}?^~•–='] (min - 3, Max - 200)"
              ControlToValidate="txtIdeaName" Display="Dynamic" ForeColor="Red" ValidationGroup="Entry"></asp:RegularExpressionValidator>--%>
      </div>
  </div>

            <div class="form-group" id="selectchallenge" runat="server">
                <label class="control-label col-sm-2 nopadding" for="name">
                    Select Challenge </label>
                <div class="col-sm-10 nopadding">
                    <asp:DropDownList ID="ddlChallenge" runat="server" CssClass="form-control">
                    </asp:DropDownList>                   
                </div>
            </div>

            <div class="form-group ">                              
                <label id="lblIntAudience" runat="server" class="control-label col-sm-2 nopadding" for="keywords">
   
                   Any Data Source<br /> Required <span style="color: #ff0000"> *</span></label>
                <div class="col-sm-10" style="overflow: auto;">
                    <asp:RadioButtonList runat="server" CssClass="css-checkbox" ID="rdldatasource"
                        RepeatDirection="Horizontal">
                        <asp:ListItem Value="1">Yes</asp:ListItem>
                        <asp:ListItem Value="2">No</asp:ListItem>                               
                    </asp:RadioButtonList>
                    <asp:RequiredFieldValidator ID="RequiredFieldValidator5" runat="server" ValidationGroup="Entry"
                       ForeColor="Red" ControlToValidate="rdldatasource" ErrorMessage="Select One"
                       Display="None"></asp:RequiredFieldValidator> 
        
                </div>
            </div>     
 
             <div class="clearfix">
             </div>
             <div class="clearfix">
             </div>
                        <div class="form-group">
                        <label class="control-label col-sm-2 nopadding" for="name">
                            Leadership Principle<span style="color: #ff0000"> *</span> </label>
                        <div class="col-sm-10 nopadding">
                            <asp:DropDownList ID="ddlleadership" runat="server" CssClass="form-control" AutoPostBack="true" OnSelectedIndexChanged="ddlleadership_SelectedIndexChanged">
                                <asp:ListItem Value="0">-- Select --</asp:ListItem>                                
                            </asp:DropDownList>  
                            <asp:RequiredFieldValidator ForeColor="Red" ID="RequiredFieldValidator13" ValidationGroup="Entry"
                            runat="server" ErrorMessage="Please Select Leadership Principle" Display="Dynamic" InitialValue="0" ControlToValidate="ddlleadership"></asp:RequiredFieldValidator>
                        </div>
                    </div>
                                    <div class="form-group">
                                        <label class="control-label col-sm-2 nopadding" for="name">
                                            Sub-Leadership Principle<span style="color: #ff0000"> *</span> </label>
                                        <div class="col-sm-10 nopadding">
                                            <asp:DropDownList ID="ddlsubleadership" runat="server" CssClass="form-control">
                                                <asp:ListItem Value="0">-- Select --</asp:ListItem>                                                
                                            </asp:DropDownList>
                                            <asp:RequiredFieldValidator ForeColor="Red" ID="RequiredFieldValidator14" ValidationGroup="Entry"
                                                runat="server" ErrorMessage="Please Select Sub-Leadership Principle" Display="Dynamic" InitialValue="0" ControlToValidate="ddlleadership"></asp:RequiredFieldValidator>
                                        </div>
                                    </div>
           <%-- -------------------------------------------------------------------------------------------------------%>
            
         
            <div class="clearfix">
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 nopadding" style="left: 200px;">
                <asp:Button ID="btnSubmit" runat="server" Text="Submit" ValidationGroup="Entry" CssClass="save"
    CausesValidation="true" OnClick="btnSubmit_Click" />
                <asp:Button ID="btnCancel" runat="server" Text="Back" CssClass="submit" OnClick="btnCancel_Click" />
                <asp:Button ID="btnapprove" runat="server" Text="Approve" CssClass="submit" OnClick="btnapprove_Click" />
                <asp:Button ID="btnreject" runat="server" Text="Reject" CssClass="submit" OnClick="btnreject_Click" />
            </div>
            <asp:ValidationSummary ID="ValidationSummary1" runat="server" ShowMessageBox="True"
                ShowSummary="False" ValidationGroup="Entry" />
        </div>
        <div class="clearfix">
        </div>
    </div>
       <div class="footerhome" style="text-align: center">

        </div>
</asp:Content>
