﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Site.master" AutoEventWireup="true" CodeFile="SuccessMessage.aspx.cs" Inherits="Modules_Message_SuccessMessage" %>

<asp:Content ID="Content1" ContentPlaceHolderID="HeadContent" Runat="Server">
    <style>        
    .div-background {
        border-radius: 10px;
        background: #FFF;
        backdrop-filter: blur(2px);            
        text-align: center;
        height: 300px;
        top: 170px;
        width: 800px;
        position: relative;               
        border: 3px solid #000;
        padding: 10px;
        margin-left: auto;
        margin-right: auto;
        flex-shrink: 0;
    }
    .classimgThanku {
        height: 30px;
        top: 30px;
        position: relative;
    }
    .lblmessage {
        color: #000;
        text-align: center;            
        font-family: Montserrat;
        font-size: 24px;
        font-style: normal;
        font-weight: 400;
        line-height: normal;
    }
    .btn-class {
        font-size: 18px;
        font-weight: 500;
        width: 195px;
        height: 55px;
        letter-spacing: 1.0px;
        flex-shrink: 0;
        /*border-radius: 40px;*/
        /*background: var(--Orange, #EA7603);*/
        border: 1.967px solid var(--Primary-60, #FFF);
        background: var(--Primary-60, #0F62FE);
        color:#FFF;

    }
    .thankyou {
        color: #000;
        font-family: "Red Hat Display";
        font-size: 32px;
        font-style: normal;
        font-weight: 900;
        line-height: normal;
    }
</style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" Runat="Server">
    <div class="div-background">
    <br />
    <%--<img runat="server" src="~/images/mccainThankyouforsubmitting.png" class="classimgThanku" alt="irs" />--%>
    <div class="thankyou">
        Thank You
    </div>
    <br />
    <br />
    <asp:Label ID="lbldisplaymessage" runat="server" class="lblmessage" Text=""></asp:Label>
    <br />
    <br />
    <br />
    <asp:Button ID="btn_home" class="btn-class" runat="server" Text="Home" OnClick="btn_home_Click" />            
</div>
</asp:Content>

