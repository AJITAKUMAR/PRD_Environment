﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Site.master" AutoEventWireup="true" CodeFile="EventHome.aspx.cs" Inherits="Modules_Events_EventHome" %>

<asp:Content ID="Content1" ContentPlaceHolderID="HeadContent" Runat="Server">
     <style>
            .classtable{
                 width: 85%;
                 height: 615px;
                 margin-left: 110px;
                 margin-top: 45px;
            }
            /*.classrow{
                 width: 410px;
                 font-size: 25px;
                 height: 528px;
            }*/
         /*.classrowdiv {
             width: 280px;
             height: 450px;
             margin-left: 50px;
             margin-top: 70px;
             background-color: white;
             border: 3px solid orangered;
             border-radius: 10px;
         }*/
            .classrowimg1{
                margin-left: 69px;
                margin-top: 16%;
                Height:136px;
                Width:144px;
            }
            .classdividea{
                width: 167px;
                height: 49px;
                margin-left: 65px;
                font-size: 12px;
                margin-top: 15px;
                background-color: white;
                text-align:center;
            }
            .classdivideaimg2{
                margin-left: 60px;
                margin-top: 60px;
                Width:300px;
            }
            .classpostidea{
                line-height: 1.1;
                margin-left: 115px;
                font-weight: 900;
                font-size:23px;
            }
         .classpostidea1 {
             line-height: 1.1;
             margin-left: 100px;
             font-weight: 900;
             font-size: 23px;
         }
         .footerhome {
             position: fixed;
             height: 10px;
             background-color: #FEE000;
             bottom:0px;
             width: 100%;
         }
</style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" Runat="Server">
           <table class="classtable">
    <tr>
        <td class="classrow">
            <div onclick="window.location='PostEvents.aspx';" class="classrowdiv">
                <%--<asp:Image ID="Image3" runat="server" ImageUrl="~/images/mccain_events1.png" class="classrowimg1" /><br /><br />
                 
                <div class="classpostidea1"><span>Request<br /> Events</span></div>
                <div class="classdividea">  
                    Post Request to Host an Event
                    
                </div>--%>
                    <asp:ImageButton ID="ImageButton1" runat="server" class="classdivideaimg2" ImageUrl="~/images/event_postevent.png" PostBackUrl="~/Modules/Events/PostEvents.aspx" />
             </div>            
        </td>
        <td class="classrow">
           <div onclick="window.location='viewevent.aspx';" class="classrowdiv">
             <%--<asp:Image ID="Image1" runat="server" ImageUrl="~/images/mccain_events2.png" class="classrowimg1" /><br /><br />
      
             <div class="classpostidea"><span>View<br /> Events</span></div>
             <div class="classdividea">                    
                 View Events Posted by Others
             </div>--%>
                 <asp:ImageButton ID="ImageButton2" runat="server" class="classdivideaimg2" ImageUrl="~/images/event_viewevent.png" PostBackUrl="~/Modules/Events/viewevent.aspx" />
           </div>          
        </td>
        <td class="classrow">
            <div onclick="window.location='YourEvent.aspx';" class="classrowdiv">
            <%--<asp:Image ID="Image2" runat="server" ImageUrl="~/images/mccain_events3.png" class="classrowimg1" /><br /><br />
     
            <div class="classpostidea"><span>My<br /> Events</span></div>
            <div class="classdividea">                    
                View Events Posted by You
            </div>--%>
                <asp:ImageButton ID="ImageButton3" runat="server" class="classdivideaimg2" ImageUrl="~/images/event_yourevent.png" PostBackUrl="~/Modules/Events/YourEvent.aspx" />
            </div>             
        </td>
    </tr>
</table>
    <div class="footerhome" style="text-align: center">
    </div>
</asp:Content>

