﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Site.master" AutoEventWireup="true" CodeFile="viewevent.aspx.cs" Inherits="Modules_Events_viewevent" %>

<asp:Content ID="Content1" ContentPlaceHolderID="HeadContent" Runat="Server">
    <script src="../../js/jquery.js"></script>
    

</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" Runat="Server">
    <style>
        .NoDisplay {
            display: none;
        }
        .footerhome {
            position: fixed;
            height: 10px;
            background-color: #FEE000;
            bottom:0px;
            width: 100%;
        }
 </style>
 <style>
    .classdynamicdiv {
        /*position: relative;
        left: 115px;
        bottom: 85px;*/
        color: var(--McCain-Grey, #3B393D);
        text-align: justify;
        font-family: "Red Hat Display";
        font-size: 20px;
        font-style: normal;
        font-weight: 900;
        line-height: normal;
    }
     .classdivbtn {
         color: white;
         position: relative;
         left: 1275px;
         top: 25px;
         width: 90px;
         border: 1.967px solid var(--Primary-60, #0F62FE);
         background: var(--Primary-60, #0F62FE);
     }
     
</style>
    <div class="view_tab_view_event view-ideas">
    
    <div class="tab-content">
        <div class="tab-pane active all_ideas" id="all_ideas">
            <div>                   
                <div class="col-lg-6 col-md-6 col-sm-6 nopadding">
                    <div class="form-group ">
                        <div class="nopadding">                              
                            <h4 runat="server" id="H1" visible="false">
                                No data exist</h4>
                        </div>
                    </div>
                </div>
                <div class="clearfix">
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 nopadding" runat="server" id="divPblcPrivate"
                    visible="false">
                    <div class="form-group ">
                        <div class="nopadding">
                            <span>Public Idea(s): </span><span style="color: Red" runat="server" id="lblPblcCount">
                            </span><span style="padding-left: 40px">Private Idea(s): </span><span style="color: Red"
                                runat="server" id="lblPrvtCount"></span>
                        </div>
                    </div>
                </div>
                <div class="clearfix">
                </div>
            </div>
            <div class="table-responsive" style="background-color: #FFF;">
                
                   <asp:GridView ID="grViewIdea" runat="server" AutoGenerateColumns="False" 
                    EmptyDataText="No Data Exist" CssClass="table table-bordered" AllowPaging="True"
                      OnRowCommand="grViewIdea_RowCommand" OnRowDataBound="grViewIdea_RowDataBound" OnPageIndexChanging="grViewIdea_PageIndexChanging">
                    <Columns>
                        <asp:TemplateField HeaderText="Event Id" ItemStyle-Width="80px">
                            <ItemTemplate>
                                <asp:LinkButton ID="lblIdeaId" ForeColor="Red" runat="server" CommandName="Select" CommandArgument='<%# Bind("EVENT_ID") %>' Text='<%# Bind("EVENT_ID") %>'></asp:LinkButton>
                                <%--<asp:Label ID="lblIdeaId" runat="server" Text='<%# Bind("IDEA_ID") %>'></asp:Label>--%>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="Event Name">
                            <ItemTemplate>
                                <asp:Label ID="lblIdeaName" runat="server" Text='<%# Bind("EVENT_TYPE") %>'></asp:Label>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="Event Description" ItemStyle-Width="900px">
                            <ItemTemplate>
                                <asp:Label ID="lblempemail" runat="server" Text='<%# Bind("EVENT_DESCRIPTION") %>'></asp:Label>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="View Event" ItemStyle-Width="90px" >
                            <ItemTemplate>
                                <asp:LinkButton ID="lbleventdetails" runat="server" CommandName="vieweventdetails" CommandArgument='<%# Bind("EVENT_ID") %>' Text='View'></asp:LinkButton>                                
                            </ItemTemplate>
                        </asp:TemplateField>
                        <%--<asp:TemplateField HeaderText="Region" >
                            <ItemTemplate>
                                <asp:Label ID="lblregion" runat="server" Text='<%# Bind("LOCATION") %>'></asp:Label>
                            </ItemTemplate>
                        </asp:TemplateField>
                        <asp:TemplateField HeaderText="Business Unit" >
                            <ItemTemplate>
                                <asp:Label ID="lblbusinessunit" runat="server" Text='<%# Bind("BUSINESS_UNIT") %>'></asp:Label>
                            </ItemTemplate>
                        </asp:TemplateField>

                        <asp:TemplateField HeaderText="Submission Date" >
                            <ItemTemplate>
                                <asp:Label ID="lblentrydate" runat="server" Text='<%# Bind("CREATED_ON") %>'></asp:Label>
                            </ItemTemplate>
                            <ItemStyle Width="150px" />
                        </asp:TemplateField>                            
                        <asp:TemplateField HeaderText="Review Status" ItemStyle-Width="150px">
                            <ItemTemplate>
                                <asp:Label ID="lblStatus" runat="server" Text='<%# Bind("IRIS_STATUS_DESCRIPTION") %>'></asp:Label>
                            </ItemTemplate>
                            <ItemStyle HorizontalAlign="Center"></ItemStyle>
                        </asp:TemplateField> --%> 
                        <%--<asp:TemplateField HeaderText="View Idea" ItemStyle-HorizontalAlign="Center">
                            <ItemTemplate>
                                <asp:LinkButton ID="lnkbtnideaid" runat="server" CommandName="view" CommandArgument='<%# Bind("IDEA_ID") %>' Text="view" />
                            </ItemTemplate>
                            <ItemStyle HorizontalAlign="Center"></ItemStyle>
                        </asp:TemplateField>  --%>                           
                    </Columns>
                    <FooterStyle BackColor="White" ForeColor="#000066" />
                    <HeaderStyle BackColor="#006699" Font-Bold="True" ForeColor="White" />
                    <PagerStyle BackColor="White" ForeColor="#000066" HorizontalAlign="Left" />
                    <RowStyle ForeColor="#000066" />
                    <SelectedRowStyle BackColor="#669999" Font-Bold="True" ForeColor="White" />
                    <SortedAscendingCellStyle BackColor="#F1F1F1" />
                    <SortedAscendingHeaderStyle BackColor="#007DBB" />
                    <SortedDescendingCellStyle BackColor="#CAC9C9" />
                    <SortedDescendingHeaderStyle BackColor="#00547E" />
                </asp:GridView>



            </div>
        </div>
    </div>        
</div>

     <div>
        <asp:Button ID="btn_back" runat="server" Text="Back" OnClick="btn_back_Click" class="classdivbtn"  />
    </div>

 <%--<div class="challenge_detail">
    <br />
     <br />
     
     <div class="user-dashboard">
        
          <div class="challenge_list" style="text-align: center;">
              
                         <% AddDynamicDivs(); %>
              
          </div>

      
     </div>
 </div>--%>
<div class="footerhome" style="text-align: center">
</div>
 <!-- script references -->
 <link href="../../css/jquery.mCustomScrollbar.css" rel="stylesheet">
 <script src="../../js/bootstrap.min.js"></script>
 <script src="../../js/scripts.js"></script>
 <script src="../../js/scroll/jquery.nicescroll.min.js"></script>
	<script src="../../js/scroll/custom.js"></script>
</asp:Content>

