﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Site.master" AutoEventWireup="true" CodeFile="YourEvent.aspx.cs" Inherits="Modules_Events_YourEvent" %>

<asp:Content ID="Content1" ContentPlaceHolderID="HeadContent" Runat="Server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" Runat="Server">
       <style>
           .NoDisplay {
               display: none;
           }
           .classstatus1 {
               position: relative;
               background-color: Green;
               color: #fff;
               padding: 2px;
               bottom: 30px;
               display: block;
               width: 165px;
               border-radius: 20px;
           }
           .classstatus2 {
               position: relative;
               background-color: Orange;
               color: #fff;
               padding: 2px;
               bottom: 30px;
               display: block;
               width: 165px;
               border-radius: 20px;
           }
           .classstatus3 {
               position: relative;
               background-color: Red;
               color: #fff;
               padding: 2px;
               bottom: 30px;
               display: block;
               width: 165px;
               border-radius: 20px;
           }
           .footerhome {
               position: fixed;
               height: 10px;
               background-color: #FEE000;
               bottom: 0px;
               width: 100%;
           }
           .classviewapprovedevent {
               display: flex;
               position:relative;
               right:45px;
               width: 90px;
               font-size:8px;
               height: 25px;
               padding: 2px;
               justify-content: center;
               align-items: center;               
               color:#FFF;
               flex-shrink: 0;
               border: 1.567px solid var(--Primary-60, #0F62FE);
               background: #0F62FE;
           }
           .classapprovedbyadmin {
               position: relative;
               left: 50px;
               bottom: 25px;
               display: flex;
               width: 90px;
               height: 25px;
               padding: 2px;
               font-size: 8px;
               color: #FFF;
               justify-content: center;
               align-items: center;
               border: 1.567px #009863;
               background: #009863;
           }
           .classyourevent {
               color: var(--McCain-Grey, #3B393D);
               text-align: justify;
               font-family: "Red Hat Display";
               font-size: 20px;
               font-style: normal;
               font-weight: 900;
               line-height: normal;
           }
           .classactionpending {
               /*position: relative;
               left: 50px;
               bottom: 25px;*/
               display: flex;
               width: 90px;
               height: 25px;
               padding: 2px;
               font-size: 8px;
               color: #FFF;
               justify-content: center;
               align-items: center;
               border: 1.567px #FEE000;
               background: #FEE000;
           }
           .classactionrejected {
               /*position: relative;
               left: 50px;
               bottom: 25px;*/
               display: flex;
               width: 90px;
               height: 25px;
               padding: 2px;
               font-size: 8px;
               color: #FFF;
               justify-content: center;
               align-items: center;
               border: 1.567px #EC3400;
               background: #EC3400;
           }
</style>

<div class="challenge_detail">
    
    <div class="clearfix">
    </div>
    <div class="user-dashboard">
       
         <div class="challenge_list" style="text-align: center;">
             
                        <% AddDynamicDivs(); %>
             
         </div>

    
    </div>
</div>

<div class="footerhome" style="text-align: center">

</div>


<!-- script references -->
<link href="../../css/jquery.mCustomScrollbar.css" rel="stylesheet">
<script src="../../js/bootstrap.min.js"></script>
<script src="../../js/scripts.js"></script>
<script src="../../js/scroll/jquery.nicescroll.min.js"></script>
<script src="../../js/scroll/custom.js"></script>
</asp:Content>

