﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Site.master" AutoEventWireup="true" CodeFile="PostEvents.aspx.cs" Inherits="Modules_Events_PostEvents" %>

<asp:Content ID="Content1" ContentPlaceHolderID="HeadContent" runat="Server">
    <script src="../../js/jquery.js" type="text/javascript"></script>
    <link href="../../css/jquery.feedBackBox.css" rel="stylesheet" />
     <%-- --------------------------use this for calender------------------------------------%>      
      <link href="../../css/jquery-ui.css" rel="stylesheet" />
      <script src="../../js/jquery-3.6.0.min.js"></script>
      <script src="../../js/jquery-ui.min.js"></script>
   <%-- --------------------------use this for calender------------------------------------%>   
        <script src="../../css/jquery.sumoselect.min.js"></script>    
        <link href="../../css/sumoselect.css" rel="stylesheet" />
    
    <script type="text/javascript">
        $(document).ready(function () {
            $(<%=lstBoxTest.ClientID%>).SumoSelect();
        });
    </script>
    <style type="text/css">
        body {
            font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
            color: #444;
            font-size: 13px;
        }

        p, div, ul, li {
            padding: 0px;
            margin: 0px;
        }
    </style>




</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="Server">
    <style>
        .NoDisplay {
            display: none;
        }
        .footerhome {
            position: fixed;
            height: 10px;
            background-color: #FEE000;
            bottom:0px;
            width: 100%;
            left: 128px;
        }
        .classpostidea {
            line-height: normal;
            margin-left: 5px;
            font-weight: 900;
            font-size: 15px;            
        }
        .modal {
            position: fixed;
            top: 35%;
            left: 48%;
            right: 297px;
            bottom: 231px;
            transform: translate(-50%, -50%);
            background: #FEE000;
            padding: 45px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
            z-index: 100;
            display: none; /* Initially hidden */
            text-align: center;
        }
        .modal h2 {
            margin: 0 0 10px;
        }
        /*.classpostidea {
            line-height: 1.1;            
            font-weight: 900;
            font-size: 18px;
            margin-bottom: 25px;
        }*/
        /*.footer {
            background-color: #FEE000 !important;
            top: 7px !important;
            height: 20px !important;
            position: relative !important;
        }      */
    </style>
    <script type="text/javascript" language="javascript">
        function showModal() {
            document.getElementById('blur-background').style.display = 'block';
            document.getElementById('modal').style.display = 'block';
        }

        function closeModal() {
            document.getElementById('blur-background').style.display = 'none';
            document.getElementById('modal').style.display = 'none';
        }

        $(function () {
            $("#<%= txtStartDate.ClientID %>").datepicker({
                dateFormat: 'dd/mm/yy',
                onClose: function (selectedDate) {
                    // Set the minDate of endDatePicker to the selected date of startDatePicker
                    $("#<%= txtEndDate.ClientID %>").datepicker("option", "minDate", selectedDate);
                }
            });
           $("#<%= txtEndDate.ClientID %>").datepicker({
                dateFormat: 'dd/mm/yy',
                onClose: function (selectedDate) {
                    // Set the maxDate of startDatePicker to the selected date of endDatePicker
                    $("#<%= txtStartDate.ClientID %>").datepicker("option", "maxDate", selectedDate);
                }
           });
        });
    </script>
    <%--<img runat="server" src="~/images/ideas_1.png" alt="banner" class="contact-img img-responsive" />--%>

    <div class="challenge_detail">
        <div class="clearfix">
        </div>
        
        <div class="form-horizontal">
            <div class="classpostidea" id="divrequestid" runat="server">
                Request Id:- <asp:Label ID="idea_id" runat="server" Text=""></asp:Label><asp:Label ID="lbl_status" Style="left: 20px;position: relative;" runat="server" Text=""></asp:Label> <asp:HiddenField ID="HiddenField1" runat="server" />
            </div>
            <br />                
           
                <div class="form-group">                   
                <label class="control-label col-sm-2 nopadding" for="name">
                    Types of Events <span style="color: #ff0000">*</span></label>
                <div class="col-sm-10 nopadding">
                    <asp:DropDownList ID="ddleventtype" runat="server" CssClass="form-control">
                      <asp:ListItem Value="0">-- Select --</asp:ListItem>
                      <asp:ListItem Value="1">Project</asp:ListItem>
                      <asp:ListItem Value="2">Team Meeting</asp:ListItem>
                      <asp:ListItem Value="3">Workshop/Event</asp:ListItem>
                      <asp:ListItem Value="4">Partner Event</asp:ListItem>
                      <asp:ListItem Value="5">Customer Event</asp:ListItem>                      
                  </asp:DropDownList>                   
                    <asp:RequiredFieldValidator ForeColor="Red" ID="RequiredFieldValidator8" ValidationGroup="Entry"
                        runat="server" ErrorMessage="Please Select Types Of Events" Display="Dynamic" InitialValue="0" ControlToValidate="ddleventtype"></asp:RequiredFieldValidator>                
                </div>
            </div>
           
            <div class="form-group">
                <label class="control-label col-sm-2 nopadding" for="description">
                    Description<span style="color: #ff0000"> *</span></label>
                <div class="col-sm-10 nopadding">
                    <asp:TextBox ID="txtContent" CssClass="form-control" TextMode="MultiLine"
                        runat="server" 
                        onkeypress="return limitlength(this, 2000);" ToolTip=""
                        placeholder="Enter Description"></asp:TextBox>
                    <asp:RequiredFieldValidator ForeColor="Red" ID="RequiredFieldValidator2" ValidationGroup="Entry"
                        runat="server" ErrorMessage="Please Enter Description" Display="Dynamic" ControlToValidate="txtContent"></asp:RequiredFieldValidator>
                    <%--<asp:RegularExpressionValidator ID="RegularExpressionValidator1" ValidationExpression="\b^[\w\d\s\- .,:;@!?€¥£¢$%()‘’”“&/#*+{}?^~•–=']{3,2000}$"
                     runat="server" ErrorMessage="Description : Only Characters, Digits and special characters [.,:;@!?€¥£¢$%()‘’”“&/#*+{}?^~•–='] (min - 3, Max - 2000)"
                     ControlToValidate="txtContent" Display="Dynamic" ForeColor="Red" ValidationGroup="Entry"></asp:RegularExpressionValidator>--%>
                   <%-- <span class="highlight">Number of Characters Left:</span>
                    <label id="lblcount" style="background-color: #E2EEF1; color: Red;">
                        2000</label>--%>
                </div>
            </div>
            <div class="form-group ">
                <label class="control-label col-sm-2 nopadding" for="keywords">
                    Select Space <span style="color: #ff0000">*</span></label>
                <div class="col-sm-10 nopadding">
                    <asp:DropDownList ID="ddlspace" runat="server" CssClass="form-control">
                        <asp:ListItem Value="0">--Select--</asp:ListItem>
                        <asp:ListItem Value="1">Working POD 1 (6 person capacity)</asp:ListItem>
                        <asp:ListItem Value="2">Working POD 2 (6 person capacity)</asp:ListItem>
                        <asp:ListItem Value="3">Working POD 3 (6 person capacity)</asp:ListItem>
                        <asp:ListItem Value="4">Creativity Lounge (16 person capacity)</asp:ListItem>
                        <asp:ListItem Value="5">Event Space (6-10 person capacity)</asp:ListItem>
                        <asp:ListItem Value="6"> Meeting Room </asp:ListItem>
                    </asp:DropDownList>
                    <asp:RequiredFieldValidator ForeColor="Red" ID="RequiredFieldValidator3" ValidationGroup="Entry"
                    runat="server" ErrorMessage="Please Select Space" Display="Dynamic" InitialValue="0"
                    ControlToValidate="ddleventtype"></asp:RequiredFieldValidator>   
                </div>
            </div>
            
           


            <div class="clearfix">
            </div>   
            <div class="clearfix">
            </div>   
            <div class="clearfix">
            </div>   

            <div class="col-lg-8 col-md-9 col-sm-8 nopadding">
                <div class="form-group">
                    <label class="control-label col-sm-3 nopadding">
                        Event Duration <span style="color: #ff0000">*</span></label>
                    <div class="col-sm-9 nopadding">
                        <div class="date col-md-5 col-sm-5 nopadding ">
                            <div class="date_txt pull-left col-sm-3 nopadding ">
                                Start
                            </div>
                            <div class="date_input pull-left input-group col-sm-9 nopadding" id='startdate'>
                                <asp:TextBox ID="txtStartDate" autocomplete="off" AutoCompleteType="None" runat="server" CssClass="form-control"
                                    placeholder="dd-mm-yyyy"></asp:TextBox>     
                                <asp:RequiredFieldValidator ForeColor="Red" ID="RequiredFieldValidator10" ValidationGroup="Entry"
                                runat="server" ErrorMessage="Please Enter Start Date" Display="Dynamic"
                                ControlToValidate="txtStartDate"></asp:RequiredFieldValidator>

                            </div>
                        </div>
                        <div class="date col-md-5 col-sm-5 nopadding ">
                            <div class="date_txt pull-left col-sm-3 nopadding ">
                                End
                            </div>
                            <div class="date_input pull-left input-group col-sm-9 nopadding" id='enddate'>
                                <asp:TextBox ID="txtEndDate" autocomplete="off" AutoCompleteType="None" runat="server" CssClass="form-control"
                                    placeholder="dd-mm-yyyy" ></asp:TextBox>
                                <asp:RequiredFieldValidator ForeColor="Red" ID="RequiredFieldValidator11" ValidationGroup="Entry"
                                 runat="server" ErrorMessage="Please Enter End Date" Display="Dynamic"
                                 ControlToValidate="txtEnddate"></asp:RequiredFieldValidator>
                            </div>
                        </div>
                    </div>
                </div>

            </div>


            <div class="clearfix">
            </div>   
            <div class="clearfix">
            </div>   
            <div class="clearfix">
            </div>  

            <div class="form-group ">
                <label class="control-label col-sm-2 nopadding" for="keywords">
                    No. of Participants <span style="color: #ff0000">*</span></label>
                <div class="col-sm-10 nopadding">
                    <asp:TextBox ID="txtparticipants" runat="server" CssClass="form-control" placeholder=""
                        onkeydown = "return (!(event.keyCode>=65) && event.keyCode!=32);"></asp:TextBox>
                    <asp:RequiredFieldValidator ForeColor="Red" ID="RequiredFieldValidator4" ValidationGroup="Entry"
                     runat="server" ErrorMessage="Please Enter No. Of Participants" Display="Dynamic"
                     ControlToValidate="txtparticipants"></asp:RequiredFieldValidator>
                </div>
            </div>
            <%--<div class="form-group">
                <label class="control-label col-sm-2 nopadding" for="name">
                    Accessory Items <span style="color: #ff0000">*</span></label>
                <div class="col-sm-10 nopadding">
                    <asp:DropDownList ID="ddlaccessory" runat="server" Height="43px" Width="1028px">
                        <asp:ListItem Value="0">-- Select --</asp:ListItem>
                        <asp:ListItem Value="Whiteboard">Whiteboard</asp:ListItem>
                        <asp:ListItem Value="TV">TV</asp:ListItem>
                        <asp:ListItem Value="Extra Mic">Extra Mic</asp:ListItem>
                        <asp:ListItem Value="Stand">Stand</asp:ListItem>
                  </asp:DropDownList>     
                </div>
            </div>--%>
            <div class="form-group">
                <label class="control-label col-sm-2 nopadding" for="name">
                    Accessory Items <span style="color: #ff0000">*</span></label>
                <div class="col-sm-10 nopadding">
                       <asp:ListBox runat="server" ID="lstBoxTest" SelectionMode="Multiple" CssClass="form-control">
                            <asp:ListItem Text="Whiteboard" Value="0"></asp:ListItem>
                            <asp:ListItem Text="TV" Value="1"></asp:ListItem>
                            <asp:ListItem Text="Extra Mic" Value="2"></asp:ListItem>
                            <asp:ListItem Text="Stand" Value="3"></asp:ListItem>
                        </asp:ListBox>
                    <asp:TextBox ID="txtaccessoryitem" runat="server" CssClass="form-control"></asp:TextBox>
                </div>
            </div>

           
            <div class="clearfix">
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 nopadding" style="left: 210px;width: 80% !important">                
                <asp:Button ID="btnCancel" runat="server" Text="Back" CssClass="submit" OnClick="btnCancel_Click" />
                <asp:Button ID="btnSubmit" runat="server" Text="Submit" CssClass="save" OnClick="btnSubmit_Click" />
                <asp:Button ID="btnspacerequest" runat="server" Text="Space Allocation Request" CssClass="submit" OnClick="btnspacerequest_Click"/>
                <asp:Button ID="btnapprove" runat="server" Text="Approve" CssClass="submit" OnClick="btnapprove_Click" />
                <asp:Button ID="btnreject" runat="server" Text="Reject" CssClass="submit" OnClick="btnreject_Click" />
            
            </div>            
            <asp:ValidationSummary ID="ValidationSummary2" runat="server" ShowMessageBox="True"
                ShowSummary="False" ValidationGroup="Entry" />
        </div>
            
        <div class="clearfix">
        </div>
    </div>
        
        


<div class="footerhome">
</div>
    
    
     
    <!-- script references -->
    <link href="../../css/jquery.mCustomScrollbar.css" rel="stylesheet">
    <script src="../../js/bootstrap.min.js"></script>
    <script src="../../js/scripts.js"></script>
    <script src="../../js/scroll/jquery.nicescroll.min.js"></script>
    <script src="../../js/scroll/custom.js"></script>
    </div>
</asp:Content>

