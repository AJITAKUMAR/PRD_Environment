﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Site.master" AutoEventWireup="true" CodeFile="PostChallengeNew.aspx.cs" Inherits="Modules_Challenges_PostChallengeNew" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="Ajax" %>
<asp:Content ID="Content1" ContentPlaceHolderID="HeadContent" Runat="Server"> 
     
    <%-- --------------------------use this for calender------------------------------------%>      
     <link href="../../css/jquery-ui.css" rel="stylesheet" />
     <script src="../../js/jquery-3.6.0.min.js"></script>
     <script src="../../js/jquery-ui.min.js"></script>
  <%-- --------------------------use this for calender------------------------------------%>
    
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" Runat="Server">
     <style type="text/css">
         .footerhome {
             position: fixed;
             height: 10px;
             background-color: #FEE000;
             bottom:0px;
             width: 100%;
             left: 126px;
         }
      
 </style>
 <script type="text/javascript">
     $(function () {
         $("#<%= txtstartdate.ClientID %>").datepicker({
              dateFormat: 'dd/mm/yy',
              onClose: function (selectedDate) {
                  // Set the minDate of endDatePicker to the selected date of startDatePicker
                  $("#<%= txtEnddate.ClientID %>").datepicker("option", "minDate", selectedDate);
     }
 });
 $("#<%= txtEnddate.ClientID %>").datepicker({
     dateFormat: 'dd/mm/yy',
     onClose: function(selectedDate) {
         // Set the maxDate of startDatePicker to the selected date of endDatePicker
         $("#<%= txtstartdate.ClientID %>").datepicker("option", "maxDate", selectedDate);
     }
 });
      });
     //function CurrentDateShowing(e) {
     //    if (!e.get_selectedDate() || !e.get_element().value) {
     //        e._selectedDate = (new Date()).getDateOnly();
     //    }
     //}

     //function validateConfirm() {
     //    var con = confirm("Are you sure want to delete?");
     //    if (con == true)
     //        return true;
     //    else
     //        return false;
     //}
     //function limitlength(obj, length) {
     //    var maxlength = length
     //    if (obj.value.length > maxlength)
     //        obj.value = obj.value.substring(0, maxlength)
     //}

     //function LimtCharacters(txtMsg, CharLength, indicator) {
     //    chars = txtMsg.value.length;
     //    document.getElementById(indicator).innerHTML = CharLength - chars;
     //    if (chars > CharLength) {
     //        txtMsg.value = txtMsg.value.substring(0, CharLength);
     //    }
     //}

    
 </script>

 
 <div class="challenge_detail" style="padding: 30px !important">
    
     <div class="clearfix">
     </div>
     <div class="view_tab post-challenge" style="position: relative;top: 80px;">
        
         <div class="tab-content">
             <div class="tab-pane active all_ideas" id="add_challenge">
                
                 <div class="form-horizontal">                      

                     <div class="form-group">
                         <label class="control-label col-sm-2  nopadding">
                             Challenge Title <span style="color: #ff0000"> *</span></label>
                         <div class="col-sm-10  nopadding">
                             <asp:TextBox ID="txtchallengetitle" CssClass="form-control" runat="server" MaxLength="100"></asp:TextBox>
                             <asp:RequiredFieldValidator ID="rfvChlname" runat="server" ValidationGroup="submit"
                                 ForeColor="Red" ControlToValidate="txtchallengetitle" ErrorMessage="Enter Challenge Title"
                                 Display="None"></asp:RequiredFieldValidator>
                             
                         </div>
                     </div>
                     <div class="form-group">
                        <label class="control-label col-sm-2  nopadding">
                            2030 Strategy Elements <span style="color: #ff0000"> *</span></label>
                        <div class="col-sm-10  nopadding">
                                <asp:DropDownList ID="ddlpurpose" runat="server" CssClass="form-control">
                                    <asp:ListItem Value="0">-- Select --</asp:ListItem>
                                    <asp:ListItem Value="Project">Undisputed Potato Leadership</asp:ListItem>
                                    <asp:ListItem Value="Team Meeting">More of the Menu</asp:ListItem>
                                    <asp:ListItem Value="Workshop/Training">From Good to Exceptional</asp:ListItem>                                         
                                </asp:DropDownList>
                            <asp:RequiredFieldValidator ForeColor="Red" ID="RequiredFieldValidator1" ValidationGroup="Entry"
                                 runat="server" ErrorMessage="Please Select 2030 Strategy Elements" Display="Dynamic" InitialValue="0" ControlToValidate="ddlpurpose"></asp:RequiredFieldValidator>
                            <%--<asp:TextBox ID="txtdomain" CssClass="form-control" runat="server" MaxLength="100"></asp:TextBox>
                            <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" ValidationGroup="submit"
                                ForeColor="Red" ControlToValidate="txtdomain" ErrorMessage="Enter Domain"
                                Display="None"></asp:RequiredFieldValidator>--%>
                            
                        </div>
                    </div>
                     <div class="form-group ">
                         <label class="control-label col-sm-2 nopadding" for="description">
                             Description <span style="color: #ff0000"> *</span></label>                          
                          <div class="col-sm-10 nopadding">
                             <asp:TextBox ID="txtDescrptn" CssClass="form-control" runat="server" TextMode="MultiLine"
                                 onkeyup="LimtCharacters(this,2000,'lblcount');" onpaste="return limitlength(this, 2000);"
                                  onkeypress="return limitlength(this, 2000);"
                                 MaxLength="2000"></asp:TextBox>
                             <asp:RequiredFieldValidator ID="rfvTxtDescr" runat="server" ValidationGroup="submit"
                                 ForeColor="Red" ControlToValidate="txtDescrptn" ErrorMessage="Enter Description"
                                 Display="None"></asp:RequiredFieldValidator>                                                                                        
                                                          
                         </div>
                     </div>
                    <div class="clearfix">
                     </div>
                                          
                     <div class="form-group ">
                                                   
                         <label id="lblIntAudience" runat="server" class="control-label col-sm-2 nopadding" for="keywords">
                        
                            Target Audience <span style="color: #ff0000"> *</span></label>
                         <div class="col-sm-10" style="overflow: auto;">
                             <asp:RadioButtonList runat="server" CssClass="css-checkbox" ID="chkAudience"
                                 RepeatDirection="Horizontal">
                                 <asp:ListItem Value="Internal">Internal</asp:ListItem>
                                 <asp:ListItem Value="External">External</asp:ListItem>
                                 <asp:ListItem Value="Both">Both</asp:ListItem>                                    
                             </asp:RadioButtonList>
                             <asp:RequiredFieldValidator ID="RequiredFieldValidator2" runat="server" ValidationGroup="submit"
                                ForeColor="Red" ControlToValidate="chkAudience" ErrorMessage="Select One"
                                Display="None"></asp:RequiredFieldValidator> 
                             
                         </div>
                     </div>
                    <%--                  
                     <div class="bottom40">
                     </div>
                     
                    --%>
                     <div class="clearfix">
                     </div>
                     <br />
                     <div class="col-lg-8 col-md-9 col-sm-8 nopadding">
                         <div class="form-group">
                             <label class="control-label col-sm-3 nopadding">
                                 Challenge Duration <span style="color: #ff0000">*</span></label>
                             <div class="col-sm-9 nopadding">
                                 <div class="date col-md-5 col-sm-5 nopadding ">
                                     <div class="date_txt pull-left col-sm-3 nopadding ">
                                         Start
                                     </div>
                                     <div class="date_input pull-left input-group col-sm-9 nopadding" id='startdate'>
                                         <asp:TextBox ID="txtstartdate" autocomplete="off" AutoCompleteType="None" runat="server"
                                             placeholder="dd-mmm-yyyy"></asp:TextBox>
                                         <asp:RequiredFieldValidator ID="RequiredFieldValidator3" runat="server" ValidationGroup="submit"
   ForeColor="Red" ControlToValidate="txtstartdate" ErrorMessage="Select Start Date"
   Display="None"></asp:RequiredFieldValidator> 
                                        
                                     </div>
                                 </div>
                                 <div class="date col-md-5 col-sm-5 nopadding ">
                                     <div class="date_txt pull-left col-sm-3 nopadding ">
                                         End
                                     </div>
                                     <div class="date_input pull-left input-group col-sm-9 nopadding" id='enddate'>
                                         <asp:TextBox ID="txtEnddate" autocomplete="off" AutoCompleteType="None" runat="server"
                                             placeholder="dd-mmm-yyyy"></asp:TextBox>
                                                                              <asp:RequiredFieldValidator ID="RequiredFieldValidator4" runat="server" ValidationGroup="submit"
ForeColor="Red" ControlToValidate="txtEnddate" ErrorMessage="Select End Date"
Display="None"></asp:RequiredFieldValidator> 
                                         
                                     </div>
                                 </div>
                             </div>
                         </div>
                        
                     </div>
                     <div class="clearfix">
                     </div>
                   <%--  <div class="bottom40">
                     </div>--%>
                     
                     <div class="col-lg-8 col-md-10 col-sm-8 nopadding" style="left:220px;">
                       
                         <asp:ValidationSummary ID="ValidationSummary1" runat="server" ShowMessageBox="True"
                             ShowSummary="False" ValidationGroup="submit" />
                         <%--<asp:Button CssClass="save" ID="btnSave" runat="server" Text="Save" 
                             CausesValidation="true" ValidationGroup="submit" Visible="false" />--%>
                        <%-- <asp:Button CssClass="save" ID="btnsubmit" runat="server" Text="Save and Exit" 
                             CausesValidation="true" ValidationGroup="submit" />--%>                         
                         <asp:Button CssClass="submit" ID="btn_cancel" runat="server" Text="Back" OnClick="btn_cancel_Click" />
                         <asp:Button CssClass="save" ID="btn_submit" runat="server" Text="Submit" OnClick="btn_submit_Click" />
                     </div>
                   

                     <div class="clearfix">
                     </div>
                     <div class="col-lg-6 col-md-6 col-sm-6 nopadding ">
                     </div>
                    
                 </div>
                 <div class="clearfix">
                 </div>
             </div>
         </div>
     </div>
     <div id="Confirm" class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog">
         <div class="modal-dialog modal-lg-small">
             <div class="modal-content">
                 <div class="modal-header">
                     <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                         ×</button>
                     <h4 class="modal-title">
                         Confirm !</h4>
                 </div>
                 <div class="modal-body">
                     <div class="dashboard">
                         <div class="table-responsive">
                             <h4 runat="server" id="lblConfirmMsg">
                             </h4>
                         </div>
                     </div>
                 </div>
                 <div class="modal-footer">
                     <asp:Button ID="btnOK" runat="server" CssClass="btn ok" Text="OK"  />
                     <asp:Button ID="btnCancel" runat="server" CssClass="btn ok" Text="Cancel"  />
                 </div>
             </div>
         </div>
     </div>
     <div>
     </div>
 <div id="challengeIcon" class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog">
     <div class="modal-dialog modal-lg">
         <div class="modal-content">
             <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                     ×</button>
                 <h4 class="modal-title" runat="server" id="ModalTitle">
                     Select an icon for a challenge...</h4>
             </div>
             <div class="modal-body">
                 <div class="dashboard2">
                     <div class="table-responsive">

                         <%-- <asp:Label ID="lblNote" runat="server"  Font-Bold="true" Style="margin-top:20px; margin-left:15px;" Font-Size="medium" Text="Select an icon for a challenge..."></asp:Label>--%>

                             <asp:RadioButtonList ID="rdbImages" CssClass="rbl"
                             runat="server"
                             border-spacing="15px"
                             BorderStyle="none"
                             BorderWidth="5px"
                             RepeatColumns="3"                               
                             RepeatLayout="Table">
                         </asp:RadioButtonList> 
                                                     
                     </div>
                 </div>
             </div>
             <div class="modal-footer">
                 <button type="button" class="btn cancel" data-dismiss="modal">
                     Back</button>
                 <asp:Button ID="btnSelect" runat="server" CssClass="btn ok" Text="Select"
                      />                    
             </div>
         </div>
     </div>
 </div>
<div class="footerhome" style="text-align: center">
</div>






     <script type="text/javascript" language="javascript">
         function validatesubmit() {
             //if gridview is visible show alert
             <%--var status = document.getElementById("<%# <%--grdSavedchallenges.ClientID--%>%>").visibility = 'visible';--%>
             if (status)
                 alert("please submit the saved challenges ");
             return false;
         }
         function checkMaxLen(txt, maxLen) {
             try {
                 if (txt.value.length > (maxLen - 1)) {
                     alert("You have exceeded the maximum number of characters");
                     var cont = txt.value;
                     txt.value = cont.substring(0, (maxLen - 1));
                     return false;
                 }
             }
             catch (e) {
             }
         }
         ///added function by np00365439 on 20 Aug 2015
         function enable(chk) {
             if (chk.checked) {
                 $(chk).parent().parent().parent().find('input[type=text]').removeAttr("disabled");
             }
             else {
                 $(chk).parent().parent().parent().find('input[type=text]').attr("disabled", "disabled");
                 $(chk).parent().parent().parent().find('input[type=text]').val("");
             }
         }
     </script>
     
 </div>

</asp:Content>

