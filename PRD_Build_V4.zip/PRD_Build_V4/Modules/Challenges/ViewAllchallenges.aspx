﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Site.master" AutoEventWireup="true"
    CodeFile="ViewAllchallenges.aspx.cs" Inherits="ViewPastchallenge" %>

<asp:Content ID="Content1" ContentPlaceHolderID="HeadContent" runat="Server">
    <script src="../../js/jquery.js"></script>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="Server">
    <style>
        .NoDisplay
        {
            display: none;
        }
        .footerhome {
            position: fixed;
            height: 10px;
            background-color: #FEE000;
            bottom:0px;
            width: 100%;
        }
    </style>
    
    <div class="challenge_detail">
       
        <div class="clearfix">
        </div>
        <br />
        <div class="user-dashboardAll">
            <div class="btn-group">            
                  <a class="btn btn-default bradius" id="btn_active" runat="server" href="ChallengeHomeNew.aspx" style="width:25%;background-color: #0F62FE; color:#FFF;">
                      Active Challenges</a> <a class="btn btn-default bradius1 " id="btn_upcomming" runat="server" href="ViewUpcomingchallenge.aspx" style="width:25%;background-color: #FEE000; color:#FFF;">
                          Upcoming Challenges</a> <a class="btn btn-default bradius1" id="btn_past" runat="server" href="ViewPastchallenge.aspx" style="width:25%;background-color: #009863; color:#FFF;">
                              Completed Challenges</a> <a class="btn btn-default bradius1 active " id="btn_all" runat="server" href="ViewAllchallenges.aspx" style="width:25%;background-color: #3B393D; color:#FFF;">
                                  All Challenges</a>
                  <%--<a class="btn btn-default bradius1" id="btn_post" runat="server" href="PostChallengeNew.aspx" style="width:20%">Post Challenges</a>--%>
              </div>
            
             <div class="clearfix">
                </div>
             <div class="challenge_list" style="text-align: center;" >
              <% AddDynamicDivs(); %>
             </div>          

         
        </div>
    </div>
    <div class="footerhome" style="text-align: center">
    </div>

   
    <!-- script references -->
    <link href="../../css/jquery.mCustomScrollbar.css" rel="stylesheet">
    <script src="../../js/bootstrap.min.js"></script>
    <script src="../../js/scripts.js"></script>
    <script src="../../js/scroll/jquery.nicescroll.min.js"></script>
	<script src="../../js/scroll/custom.js"></script>
</asp:Content>
