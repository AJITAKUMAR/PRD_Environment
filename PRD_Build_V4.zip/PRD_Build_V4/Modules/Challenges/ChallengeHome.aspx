﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Site.master" AutoEventWireup="true" CodeFile="ChallengeHome.aspx.cs" Inherits="Modules_Challenges_ChallengeHome" %>

<asp:Content ID="Content1" ContentPlaceHolderID="HeadContent" Runat="Server">
   <style>
       .classtable {
           width: 50%;
           height: 615px;
           margin-left: 200px;
           margin-top: 45px;
       }

       .classrowdiv {
           width: 280px;
           height: 450px;
           margin-left: 150px;
           margin-top: 70px;
           background-color: white;
           border: 3px solid orangered;
           border-radius: 10px;
       }
       .classrowimg1 {
           margin-left: 69px;
           margin-top: 16%;
           Height: 136px;
           Width: 144px;
       }
       .classdividea {
           width: 167px;
           height: 49px;
           margin-left: 65px;
           font-size: 12px;
           margin-top: 15px;
           background-color: white;
           text-align: center;
       }
       .classdivideaimg2 {
           margin-left: 115px;
           margin-top: 60px;
           Width: 320px;
       }
       .classpostidea {
           line-height: 1.1;
           margin-left: 110px;
           color: #000;
           font-family: "Red Hat Display";
           font-size: 25px;
           font-style: normal;
           font-weight: 900;
       }

       .footerhome {
           position: fixed;
           height: 10px;
           background-color: #FEE000;
           bottom: 0px;
           width: 100%;
       }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" Runat="Server">
           <table class="classtable">
    <tr>
        <td id="post_challenge" runat="server" >            
             <asp:ImageButton ID="ImageButton1" runat="server" class="classdivideaimg2"  ImageUrl="~/images/challengehome1.png" PostBackUrl="~/Modules/Challenges/PostChallengeNew.aspx" />
                         
        </td>
        <td id="view_challenge" runat="server" >             
                 <asp:ImageButton ID="ImageButton2" runat="server" class="classdivideaimg2" ImageUrl="~/images/challengehome2.png" PostBackUrl="~/Modules/Challenges/ChallengeHomeNew.aspx" />
                  
        </td>
        
    </tr>
</table>
    <div class="footerhome" style="text-align: center">
    </div>
</asp:Content>

