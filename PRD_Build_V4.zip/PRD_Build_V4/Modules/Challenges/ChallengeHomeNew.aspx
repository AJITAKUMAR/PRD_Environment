﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Site.master" AutoEventWireup="true" CodeFile="ChallengeHomeNew.aspx.cs" Inherits="Modules_Challenges_ChallengeHomeNew" %>

<asp:Content ID="Content1" ContentPlaceHolderID="HeadContent" Runat="Server">
    <script src="../../js/jquery.js"></script>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" Runat="Server">
    <style>
        .NoDisplay {
            display: none;
        }
        .footerhome {
            position: fixed;
            height: 10px;
            background-color: #FEE000;
            bottom:0px;
            width: 100%;
        }
        .classbtn_back {
            position: relative;
            bottom: 25px;
            left: 1300px;
            width: 70px;
            border: 1.967px solid var(--Primary-60, #0F62FE);
            background: var(--Primary-60, #0F62FE);
            color: var(--Default-White, #FFF);
            font-size: 13px;
            font-weight: 500;
        }
</style>

<div class="challenge_detail">
   
    <div class="clearfix">
    </div>
    <div class="user-dashboard"><br />
          <div class="btn-group">            
                   <a class="btn btn-default bradius active " id="btn_active" runat="server" href="ChallengeHomeNew.aspx" style="width:25%;background-color: #0F62FE; color:#FFF;">
                       Active Challenges</a> <a class="btn btn-default bradius1" id="btn_upcomming" runat="server" href="ViewUpcomingchallenge.aspx" style="width:25%;background-color: #FEE000; color:#FFF;">
                           Upcoming Challenges</a> <a class="btn btn-default bradius1" id="btn_past" runat="server" href="ViewPastchallenge.aspx" style="width:25%;background-color: #009863; color:#FFF;">
                               Completed Challenges</a> <a class="btn btn-default bradius1 " id="btn_all" runat="server" href="ViewAllchallenges.aspx" style="width:25%;background-color: #3B393D; color:#FFF;">
                                   All Challenges</a>
                   <%--<a class="btn btn-default bradius1" id="btn_post" runat="server" href="PostChallengeNew.aspx" style="width:20%">Post Challenges</a>--%>
               </div>
         <div class="challenge_list" style="text-align: center;">
             
                        <% AddDynamicDivs(); %>
             
         </div>
        
     
    </div>
</div>
    <div>
        <asp:Button ID="btn_back" runat="server" Text="Back" OnClick="btn_back_Click" class="classbtn_back" />
    </div>
    <div class="footerhome" style="text-align: center">
    </div>

<!-- script references -->
<link href="../../css/jquery.mCustomScrollbar.css" rel="stylesheet">
<script src="../../js/bootstrap.min.js"></script>
<script src="../../js/scripts.js"></script>
<script src="../../js/scroll/jquery.nicescroll.min.js"></script>
<script src="../../js/scroll/custom.js"></script>
</asp:Content>

