﻿<%@ Page Title="McCain - Home" Language="C#" MasterPageFile="~/Site.master" AutoEventWireup="true"
    CodeFile="HomePage.aspx.cs" Inherits="HomePage" %>

<asp:Content ID="Content1" ContentPlaceHolderID="HeadContent" runat="Server">
    <meta name="viewport" content="width=device-width, initial-scale=1">
   
<style>

    .carousel_items {
        display: flex;
        wrap: nowrap;
        overflow: hidden;
        
    }
.carousel_item {
  position: relative;
  min-width: 100%;
  height: 75vh;
  transition: all 0.5s linear;
  background-repeat: no-repeat;
  background-size: cover;
  background-attachment: fixed;
  top: 2vh;
}
.carousel_text {
  position: absolute;
  bottom: 35%;
  left: 25vh;
  transform: translate(-50%);
  padding: 0.5rem 1rem;
  border-radius: 3px;  
  color: white;
  text-shadow: 1px 1px black;
  font-size: calc(1.5rem + 0.3vw);
  font-weight: bolder;
  line-height: 1.3;
}
.slide-button {    
    /*font-family: 'Red Hat Display';*/    
    background-color: black;
    color: white;
    font-size: 24px;
    padding: 10px 15px;
    border: 1px solid;
    border: 1px solid;
    cursor: pointer;
    border-radius: 20px; 
    width: 250px;
    overflow: hidden;
}


.item1 {
  background-image: url("images/mccain_slider1.png");
}
.item2 {
  background-image: url("images/mccain_slider2.png");
}
.item3 {
  background-image: url("images/mccain_slider3.jpg");
}
</style>

</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="Server">
      

    <div <%--style="position: relative;left: 0;top: 135px;"--%>>

        <img runat="server" src="images/McCain_Home_Image.png" style="position: relative;height: 450px;top: 130px;left: 1008px;width: 400px;" alt="irs"> 
        <img runat="server" src="images/McCain_Home_Image1.png" style="position: relative;height: 80px;bottom: 42px;left:592px;" alt="irs">
        <img runat="server" src="images/McCain_Home_Image2.png" style="position: relative;height: 450px;top: 115px;left: 515px;width: 385px;" alt="irs">
    </div>

    <div style="position: relative;bottom: 230px;right: 220px;width: 900px;color: rgba(59, 57, 61, 0.89);font-family: 'Red Hat Display';font-size: 50px;font-style: normal;font-weight: 900;line-height: 107.586%;">
        Where Innovation<br /> Meets Excellence
    </div>
    <p style="color: #3B393D;left: 35px;/*font-family: 'Red Hat Display';*/font-size: 15px;font-weight: 400;width: 1000px;font-style: normal;line-height: 107.586%;position: relative; bottom: 210px; ">
        At McCain Innovation Xchange, we are committed to driving the future of food through cutting-edge innovation and <br />collaborative partnerships. Our mission is to revolutionize the way the world thinks about food by fostering creativity, <br />sustainability, and technological advancement
    </p>
    <div>
        <asp:Button runat="server" ID="btn_getstarted" Text="Get Started" style="color:white;position:relative;left:35px;bottom: 150px;width: 150px; border: 1.967px solid var(--Primary-60, #0F62FE);background: var(--Primary-60, #0F62FE);" OnClick="btn_getstarted_Click"  />
    </div>
    <div>
    <asp:Button runat="server" ID="btn_dashboard" Text="view dashboard" style="color:white;position:relative;left:200px;bottom: 170px;width: 150px; border: 1.967px solid var(--Primary-60, #0F62FE);background: var(--Primary-60, #0F62FE);" OnClick="btn_dashboard_Click"  />
    </div>


     <%-- <div class="carousel-container">
      <div class="carousel_items" style="left: 2vh;right: 2vh;position: absolute;">
        <div class="carousel_item item1">
            <div class="carousel_text">
                <div>Create, Participate and view<br />unique opportunities to innovate</div><br />
                <asp:Button CssClass="slide-button" ID="btn_idea" runat="server" Text="Ideas" OnClick="btn_idea_Click" />
            </div>
          
        </div>
       <div class="carousel_item item2">
           <div class="carousel_text">
               <div>Create, Participate and view<br />unique Events</div><br />
                <asp:Button CssClass="slide-button" ID="btn_events" runat="server" Text="Events" OnClick="btn_events_Click" />
           </div>
                      
        </div>
         <div class="carousel_item item3">
             <div class="carousel_text">
                 <div>Create, Participate and view<br />unique Challenges</div><br />
                <asp:Button CssClass="slide-button" ID="btn_challenges" runat="server" Text="Challenges" OnClick="btn_challenges_Click" />          
             </div>
            
        </div>       
      </div>
    </div>

    <script>
        const carouselItems = document.querySelectorAll(".carousel_item");
        let i = 1;

        setInterval(() => {
            // Accessing All the carousel Items
            Array.from(carouselItems).forEach((item, index) => {

                if (i < carouselItems.length) {
                    item.style.transform = `translateX(-${i * 100}%)`
                }
            })


            if (i < carouselItems.length) {
                i++;
            }
            else {
                i = 0;
            }
        }, 5000)
    </script>
--%>















    

</asp:Content>
