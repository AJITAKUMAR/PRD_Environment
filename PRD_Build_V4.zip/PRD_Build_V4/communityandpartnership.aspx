﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Site.master" AutoEventWireup="true" CodeFile="communityandpartnership.aspx.cs" Inherits="communityandpartnership" %>

<asp:Content ID="Content1" ContentPlaceHolderID="HeadContent" Runat="Server">
    <style>
        .img1 {            
            Width: 230px;
            
        }
        
        .classdiv {
            position: relative;
            top: 260px;
            
            
        }
        .classdivbtn {
            color: white;
            position: relative;
            left: 1115px;
            top: 370px;
            width: 90px;
            border: 1.967px solid var(--Primary-60, #0F62FE);
            background: var(--Primary-60, #0F62FE);
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" Runat="Server">
    <div class="classdiv">
        <asp:ImageButton ID="ImageButton1" runat="server" CssClass="img1" style="margin-left: 120px;" ImageUrl="~/images/img_communityandpartnership.png" /> 
        <asp:ImageButton ID="ImageButton2" runat="server" CssClass="img1" style="margin-left: 70px;" ImageUrl="~/images/img_communityandpartnership.png"/> 
        <asp:ImageButton ID="ImageButton3" runat="server" CssClass="img1" style="margin-left: 70px;" ImageUrl="~/images/img_communityandpartnership.png"/> 
        <asp:ImageButton ID="ImageButton4" runat="server" CssClass="img1" style="margin-left: 70px;" ImageUrl="~/images/img_communityandpartnership.png" /> 

    </div>
    <div>
        <asp:Button ID="btn_back" runat="server" Text="Back" OnClick="btn_back_Click" class="classdivbtn"  />
    </div>
   
</asp:Content>

