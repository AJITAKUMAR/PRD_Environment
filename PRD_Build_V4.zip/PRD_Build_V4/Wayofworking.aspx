﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Site.master" AutoEventWireup="true" CodeFile="Wayofworking.aspx.cs" Inherits="Wayofworking" %>

<asp:Content ID="Content1" ContentPlaceHolderID="HeadContent" Runat="Server">
        <style>
            .classtable {                
                position: relative;
                top: 120px;                
                left: 240px;
                width: 50%;
            }
            .classrow {
                border-top: 1px solid #82CFC8 !important;
            }
            .classrowdiv {
                /*width: 280px;
            height: 450px;
            margin-left: 50px;
            margin-top: 70px;
            background-color: white;
            border: 3px solid orangered;
            border-radius: 10px;*/
            }
            .classrowimg1 {
                /*Height: 150px;*/
                Width: 200px;
                position: relative;
                top: 150px;
                left: 100px;
            }
            .classrowimg2 {
                /*Height: 150px;*/
                Width: 200px;
                position: relative;
                top: 150px;
                right: 80px;
            }
            .classrowimg3 {
                /*Height: 150px;*/
                Width: 200px;
                position: relative;
                top: 150px;
                right: 250px;
            }
            .classpostidea1 {
                line-height: 1.1;
                position: relative;
                top: 155px;
                left: 150px;
                color: #000;
                font-family: "Red Hat Display";
                font-size: 16px;
                font-style: normal;
                font-weight: 900;
            }
            .classpostidea2 {
                line-height: 1.1;
                position: relative;
                top: 155px;
                right: 5px;
                color: #000;
                font-family: "Red Hat Display";
                font-size: 16px;
                font-style: normal;
                font-weight: 900;
            }
            .classpostidea3 {
                line-height: 1.1;
                position: relative;
                top: 155px;
                right: 160px;
                color: #000;
                font-family: "Red Hat Display";
                font-size: 16px;
                font-style: normal;
                font-weight: 900;
            }
            .classdivideaimg2 {
                margin-left: 120px;
                margin-top: 60px;
                Width: 37px;
            }
            .Spanclass {
                position: relative;
                left: 15px;
            }
            .footerhome {
                position: fixed;
                height: 10px;
                background-color: #FEE000;
                bottom: 0px;
                width: 100%;
            }
       
</style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" Runat="Server">
    <table class="table" style="margin-bottom: -410px;">
    <tr>
        <td>
            <div>                
                <asp:ImageButton ID="ImageButton1" runat="server" CssClass="classrowimg1" ImageUrl="~/images/wayofworking1.png" PostBackUrl="~/AboutMix.aspx" /><br /><br />               
              </div>            
        </td>
        <td>
             <div>                 
                 <asp:ImageButton ID="ImageButton2" runat="server" CssClass="classrowimg2" ImageUrl="~/images/wayofworking2.png" PostBackUrl="~/Modules/Ideas/IdeaHome.aspx" /><br /><br />
             </div>
         
        </td>
        <td>
            <div>
            <asp:ImageButton ID="ImageButton3" runat="server" CssClass="classrowimg3" ImageUrl="~/images/wayofworking3.png" PostBackUrl="~/Modules/Challenges/ChallengeHome.aspx" /><br /><br />
            </div>              
        </td>
    </tr>
     <tr>
    <td>
        <div>
            <asp:ImageButton ID="ImageButton4" runat="server" CssClass="classrowimg1" ImageUrl="~/images/wayofworking4.png" PostBackUrl="~/Modules/Events/EventHome.aspx" /><br /><br />
            
        </div>
    </td>
    <td>
            <div>
             <asp:ImageButton ID="ImageButton5" runat="server" CssClass="classrowimg2" ImageUrl="~/images/wayofworking5.png" PostBackUrl="~/communityandpartnership.aspx" /><br /><br />
            
         </div>
     
    </td>
    <td>
        <div>
            <asp:ImageButton ID="ImageButton6" runat="server" CssClass="classrowimg3" ImageUrl="~/images/wayofworking6.png" PostBackUrl="~/newsandlearning.aspx" /><br /><br />            
        </div>
        
    </td>
</tr>
</table>

    <div>
    <img runat="server" src="images/McCain_Home_Image.png" style="position: relative;height: 450px;top: 60px;left: 1008px;width: 400px;" alt="irs"> 
    <img runat="server" src="images/McCain_Home_Image1.png" style="position: relative;height: 80px;bottom: 110px;left:592px;" alt="irs">
    <img runat="server" src="images/McCain_Home_Image2.png" style="position: relative;height: 450px;top: 45px;left: 515px;width: 385px;" alt="irs">
</div>
</asp:Content>

