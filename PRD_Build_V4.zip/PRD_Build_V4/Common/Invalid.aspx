﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<%@ Page Language="VB" AutoEventWireup="false" CodeFile="Invalid.aspx.vb" Inherits="Common_Invalid" %>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>IRIS</title>
<link href="../css/global.css" type="text/css" rel="stylesheet" media="screen" />
<link href="../css/thickbox.css" type="text/css" rel="stylesheet" media="screen" />

<style type="text/css">
img { behavior: url(js/iepngfix.htc) }
</style>

<style type="text/css">

#mydiv {
	position:absolute;
	top: 65%;
	left: 50%;
	width:30em;
	height:18em;
	margin-top: -9em; /*set to a negative number 1/2 of your height*/
	margin-left: -15em; /*set to a negative number 1/2 of your width*/
	
}

P
{
    font-size: 13px;
	font-family: arial, helvetica, sans-serif;
	color: blue;
}

</style>

</head>
<body>
<!-- wrapper start -->
<div id="wrapper" class="clearfix">
	<!-- header start -->
	<div id="header" class="clearfix">
    	<div class="logos">
    		<img src="../images/logo_p2p.png" alt="IRIS" title="IRIS" class="floatleft" />
        	<img src="../images/logo_techm.png" alt="Tech Mahindra" title="Tech Mahindra" class="floatright" />
        </div>
        <div class="clear"></div>
        <div class="other-info">
        	<p class="date"></p>
            
        </div>
    </div>
    <!-- header end -->
    
    <!-- maincontent start -->
    <div id="maincontent" class="clearfix">
    	<!-- content-wrapper start -->
        <div class="content-wrapper clearfix">
        	<div class="topcurve"></div>
            <!-- midcontent start -->
            <div class="midcontent clearfix" style="height:360px">
                
                <div class="clear"></div>
                <!-- LHS start -->
               
                <!-- LHS end -->
                <!-- RHS start -->
               <div id="mydiv">
                    <p>You have been logged out! Please re-login.</p>
                    <br />
                    <p><a target="" title="Click here to login" href="../Default.aspx">Click Here To Login</a></p>
                    
               </div>
               
                <!-- RHS end -->
            </div>
            <!-- midcontent end -->
            <div class="btmcurve"></div>
        </div>
        <!-- content-wrapper end -->
    </div>
    <!-- maincontent end -->
</div>
<!-- wrapper end -->
<div class="clear"></div>
<!-- footer start -->
<div id="footer" class="clearfix">
    <p class="floatleft">Best viewed in IE 7.0 and above</p>
    <p class="floatright">&copy; Copyright. 2010. Tech Mahindra Ltd.</p>
</div>
<!-- footer end -->
</body>
</html>

