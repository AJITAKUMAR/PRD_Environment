﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Site.master" AutoEventWireup="true" CodeFile="newsandlearning.aspx.cs" Inherits="newsandlearning" %>

<asp:Content ID="Content1" ContentPlaceHolderID="HeadContent" Runat="Server">
      <style>
          .img1 {
              Width: 220px;
          }

          .classdiv {
              position: relative;
              top: 135px;
          }
          
          .classdivbtn {
              color: white;
              position: relative;
              left: 1100px;
              top: 150px;
              width: 90px;
              border: 1.967px solid var(--Primary-60, #0F62FE);
              background: var(--Primary-60, #0F62FE);
          }
 </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" Runat="Server">
    <div class="classdiv">
    <asp:ImageButton ID="ImageButton1" runat="server" CssClass="img1" style="margin-left: 140px;" ImageUrl="~/images/img_newsandlearning.png" PostBackUrl="~/newslearningdetails.aspx" /> 
    <asp:ImageButton ID="ImageButton2" runat="server" CssClass="img1" style="margin-left: 70px;" ImageUrl="~/images/img_newsandlearning.png" PostBackUrl="~/newslearningdetails.aspx" /> 
    <asp:ImageButton ID="ImageButton3" runat="server" CssClass="img1" style="margin-left: 70px;" ImageUrl="~/images/img_newsandlearning.png" PostBackUrl="~/newslearningdetails.aspx" /> 
    <asp:ImageButton ID="ImageButton4" runat="server" CssClass="img1" style="margin-left: 70px;" ImageUrl="~/images/img_newsandlearning.png" PostBackUrl="~/newslearningdetails.aspx" /> 
    </div>
    <br />
    <div class="classdiv">
    <asp:ImageButton ID="ImageButton5" runat="server" CssClass="img1" style="margin-left: 140px;" ImageUrl="~/images/img_newsandlearning.png" PostBackUrl="~/newslearningdetails.aspx" /> 
    <asp:ImageButton ID="ImageButton6" runat="server" CssClass="img1" style="margin-left: 70px;" ImageUrl="~/images/img_newsandlearning.png" PostBackUrl="~/newslearningdetails.aspx" /> 
    <asp:ImageButton ID="ImageButton7" runat="server" CssClass="img1" style="margin-left: 70px;" ImageUrl="~/images/img_newsandlearning.png" PostBackUrl="~/newslearningdetails.aspx" /> 
    <asp:ImageButton ID="ImageButton8" runat="server" CssClass="img1" style="margin-left: 70px;" ImageUrl="~/images/img_newsandlearning.png" PostBackUrl="~/newslearningdetails.aspx" /> 

    </div>
    <br />
<div>
    <asp:Button ID="btn_back" runat="server" Text="Back" OnClick="btn_back_Click" class="classdivbtn" />
</div>
</asp:Content>

