﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Site.master" AutoEventWireup="true" CodeFile="AboutMix.aspx.cs" Inherits="AboutMix" %>

<asp:Content ID="Content1" ContentPlaceHolderID="HeadContent" Runat="Server">
	<style>
	    .classrowimg1 {
	        Height: 160px;
	        Width: 180px;
	        position: relative;
	        /*top: 200px;
	        left: 120px;*/
	    }
	    .classthemix {
	        color: var(--McCain-White, #FFF);
	        text-align: center;
	        font-family: "Red Hat Display";
	        font-size: 30px;
	        font-style: normal;
	        font-weight: 900;
	        line-height: 107.586%;
	        position: relative;
	        font-stretch: expanded;
	    }
	    .classthetext {
	        color: var(--McCain-Grey, #3B393D);
	        /* font-family: "Red Hat Display"; */
	        font-size: 18px;
	        font-style: normal;
	        font-weight: 500;
	        line-height: normal;
	    }
	</style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" Runat="Server">
    <table class="table" style="border:2px solid #82CFC8;margin-top: 100px;">
        <tr>
            <td></td>
            <td>
                <asp:ImageButton ID="ImageButton1" runat="server" class="classrowimg1" ImageUrl="~/images/aboutmix1.png"  />
            </td>
            <td>
                <span class="classthemix">What is the MIX?</span><br />
                <span class="classthetext">The McCain Innovation Xchange (The MIX) ignites curiosity, empowers our people to push the boundaries of what is possible by<br /> fostering intrapreneurship in a safe and inclusive space. A destination for collaboration, co-creation with each other, strategic<br /> partners, start-ups, and customers. Our goal is to inspire innovation and serve as a catalyst for new ideas that challenge the<br /> status quo.</span>
            </td>
            <td></td>
        </tr>
        <tr >
            <td></td>
            <td>
                <asp:ImageButton ID="ImageButton2" runat="server" class="classrowimg1" ImageUrl="~/images/aboutmix2.png" />
            </td>
            <td>
                <span class="classthemix">The Ambition</span><br />
                <span class="classthetext">Our vision is to be a thriving ecosystem of tenacious innovation with customer at the core. We aspire to create an inclusive and dynamic environment that fosters interdisciplinary collaboration, experimentation, and drives digital engagement with our customers, partners and community. By harnessing the power of creativity, embedding human centric design, and executing through rapid sprints, we envision a future where innovation drives positive change, enriched experience and sustainable growth</span>
            </td>
            <td></td>
        </tr>
        <tr>
            <td></td>
            <td>
                <asp:ImageButton ID="ImageButton3" runat="server" class="classrowimg1" ImageUrl="~/images/aboutmix3.png" />
            </td>
            <td>
                <span class="classthetext">To be a thriving ecosystem of tenacious innovation and co-creation that advances McCain’s global success. We aspire to this by providing:</span><br />
                <span class="classthetext">1. A welcoming environment that inspires research and experimentation to drive digital engagement with our customers,<br /><span style="position:relative;left:20px;">partners and community.</span> </span><br />
                <span class="classthetext">2. A network of physical and digital space that brings ideas to life through rapid sprint execution in a controlled environment.</span><br />
                <span class="classthetext">3. Opportunities to collaborate with start-ups, academic organizations, and NGOs to develop digital solutions.</span><br />
                <span class="classthetext">4. An enriched employee experience that builds the leaders of tomorrow through events that support continuous learning such<br /><span style="position:relative;left:20px;"> as workshops, seminars, hackathons.</span></span>
            </td>
            <td></td>
        </tr>

    </table>

</asp:Content>

