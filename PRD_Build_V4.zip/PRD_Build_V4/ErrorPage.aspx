﻿<%@ Page Title="Error Page" Language="C#" AutoEventWireup="true" CodeFile="ErrorPage.aspx.cs"
    Inherits="ErrorPage" %>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Tech Mahindra</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link href="css/bootstrap.css" rel="stylesheet">
    <!--[if lt IE 9]>
			<script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
    <link rel="icon" type="image/png" href="images/techmfavicon.ico">
    <link href="css/styles.css" rel="stylesheet">
</head>
<body>
    <form id="Form1" runat="server">
    <div class="container-fluid errorpage">
        <div class="col-lg-4 col-lg-offset-4 col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1 errorpagesection text-center">
            <%--<div class="col-lg-10 col-lg-offset-1 col-md-10 col-md-offset-1 col-sm-12 col-xs-12 errorpagelogo">
                <div class="col-md-6 col-sm-10 text-right border-right">
                    <img src="images/irs.png" alt="error image" class="img-responsive" style="margin-top: 0px;" />
                </div>
                <div class="col-md-6 col-sm-10">
                    <img src="images/logo.png" alt="error image" class="img-responsive" style="margin-top: 0px;" />
                </div>
            </div>--%>
            <div class="clearfix">
            </div>
            <div class="errorimg">
                <img runat="server" src="~/images/alert.png" alt="error image" class="img-responsive"
                    style="margin-top: 0px;" />
            </div>
            <div class="errortitle">
                <h1>
                    log in again</h1>
            </div>
            <div class="errormsg text-center">
                <p>
                    Your session is expired. OR There may be some technical error in the system. Please
                    raise a call in remedy if problem persist.</p>
                <h5 style="display: none">
                    Error Details:</h5>
                <p runat="server" id="lblErrorMsg" style="display: none">
                </p>
                <asp:Button ID="lnkBtn" runat="server" CssClass="save" OnClick="lnkBtn_Click" Text="Login Again" />
            </div>
        </div>
    </div>
    <div class="container-fluid errorpagefooter">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="col-md-6">
                <%--<p style="text-align:center;">
                    Best viewed in IE 9 and above, Chrome, Firefox</p>--%>
            </div>
            <div class="col-md-6 text-right">
                <p></p>
            </div>
        </div>
    </div>
    </form>
</body>
</html>
