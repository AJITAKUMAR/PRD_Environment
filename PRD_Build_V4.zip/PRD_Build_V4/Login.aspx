﻿<%@ Page Title="Universal IRIS - Login" Language="C#" AutoEventWireup="true" CodeFile="Login.aspx.cs"
    Inherits="Login" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
    <!-- Mimic Internet Explorer 9 -->
    <meta http-equiv="X-UA-Compatible" content="IE=8, IE=9" />
    <meta charset="utf-8" />
    <title>McCain</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link href="css/bootstrap.css" rel="stylesheet">
    <!--[if lt IE 9]>
			<script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
    <link rel="icon" type="image/png" href="images/techmfavicon.ico">
    <link href="css/styles.css" rel="stylesheet">
    <style>
        ::placeholder {
            color: antiquewhite;
            opacity: 1; /* Firefox */
        }
        .username {
            margin-left: 30px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 600;
            line-height: normal;
        }
        * {
            padding: 0;
            margin: 0 auto;
        }
        .footerhome {
            position: fixed;
            height: 10px;
            background-color: #FEE000;
            bottom: 0px;
            width: 100%;
        }
</style>
</head>
<body id="logincontainer">
    <div>
        <div class="loginarea">
            <%--<header>
                <h1>
                    iris</h1>
                <a href="#">
                    <img src="images/tm_logo.png" alt="logo">
                </a>
            </header>--%>
            <section>
                <form id="Form1" runat="server" class="loginform">
                
                <p style="text-align:center;">
                    Login
                </p>
                <div class="inputbox">                   
                    <div class="username">Username</div>
                    <asp:TextBox ID="off" autocomplete="off" runat="server" Width="85%" ViewStateMode="Disabled" ToolTip="user name" placeholder="Enter your Username"
                        EnableViewState="false"></asp:TextBox>
                </div>
                <div class="inputbox">
                    <div class="username">Password</div>                  
                    <asp:TextBox ID="onn" autocomplete="off" runat="server" TextMode="Password" ViewStateMode="Disabled" ToolTip="password" placeholder="Enter Your Password"
                        EnableViewState="false" Width="85%"></asp:TextBox>
                </div>
                  <span style="color: #fff;" runat="server" id="lnkReg_University" visible="false">External User? 
                         <div class="clearfix">
                        </div>
                         <span style="color: #fff;">Click <a style="color: #00CCFF" href="Register_UNIV_User.aspx">here</a> to Register.</span>
                        <div class="clearfix">
                        </div>
                        <span style="color: #fff;" id="Span1">Forgot Password? Click <a  style="color: #00CCFF" href="ForgotPassword.aspx">here</a> to Reset.</span>
                  </span>
                
                <asp:Button ID="went" runat="server" CssClass="loginbtn" OnClick="went_for" Text="Login" />
                
                    <div class="clearfix">
                    </div>
                    <asp:Label ID="Errr" runat="server" class="errorMsg" Font-Bold="true" ForeColor="Red"></asp:Label>
                </form>
            </section>
        </div>
    </div>
    <div class="footerhome" style="text-align: center">

    </div>
</body>
</html>