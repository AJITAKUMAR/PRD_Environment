﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Site.master" AutoEventWireup="true" CodeFile="newslearningdetails.aspx.cs" Inherits="newslearningdetails" %>

<asp:Content ID="Content1" ContentPlaceHolderID="HeadContent" Runat="Server">
    <style>
        .classimgcenter {
            display: block;
            margin-left: auto;
            margin-right: auto;
            max-width: 90px
        }
        .classdiv_email {
            position: relative;
            top: 100px;
            padding: 10px;
            background-color: #FFF;
            max-width: 95%;
            min-height: 540px;
        }
        .classbtn_back {
            position: relative;
            top: 110px;
            left: 1300px;
            width: 70px;
            border: 1.967px solid var(--Primary-60, #0F62FE);
            background: var(--Primary-60, #0F62FE);
            color: var(--Default-White, #FFF);
            font-size: 13px;
            font-weight: 500;
        }
        .heading {
            color: var(--McCain-Grey, #3B393D);
            font-family: Montserrat;
            font-size: 50px;
            font-style: normal;
            font-weight: 600;
            line-height: normal;
        }
        .subheading {
            color: var(--McCain-Grey, #3B393D);
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 600;
            line-height: normal;
        }
        .classdivimage {
            border: 1px #000;
            background: #D9DAE4;
            min-height: 200px;
            text-align:center;
        }
        .classspan {
            color: rgba(59, 57, 61, 0.37);
            font-family: Montserrat;
            font-size: 69.466px;
            font-style: normal;
            font-weight: 600;
            line-height: normal;
            position:relative;
            top:60px;
        }
        .divtext {
            color: var(--McCain-Grey, #3B393D);
            font-family: Montserrat;
            font-size: 14px;
            font-style: normal;
            font-weight: 600;
            line-height: normal;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" Runat="Server">
    <div class="classdiv_email">
    <div class="heading">Heading</div>
    <div class="subheading">Sub Heading</div><br />
    <div class="classdivimage"><span class="classspan">Image/IIIustration</span></div><br />
    <div class="divtext">
        Body content Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla nisi metus, vulputate et arcu ut, sollicitudin convallis dui. Integer malesuada, massa at posuere vestibulum, nisl orci auctor eros, viverra ullamcorper quam magna bibendum eros. Fusce tempus sollicitudin sapien id feugiat. Morbi ut lacus nulla. Pellentesque maximus posuere consequat. In iaculis vel neque eget viverra. Nunc sit amet congue tellus. Curabitur at nisi lobortis, vehicula ante imperdiet, bibendum lacus. Vivamus a suscipit diam, ut sollicitudin leo. 
    </div>
    </div>
    <asp:Button ID="btn_back" runat="server" Text="Back" OnClick="btn_back_Click" class="classbtn_back" />
</asp:Content>

