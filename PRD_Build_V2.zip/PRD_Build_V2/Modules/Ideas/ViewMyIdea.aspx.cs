﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OracleClient;
using System.Data;
using OraAppBlock;
using System.Collections;
using System.Configuration;
using System.Drawing;

public partial class Modules_Ideas_ViewMyIdea : System.Web.UI.Page
{    
    BusinessLayer.IRIS_BusinessLayer objClass1_BL = new BusinessLayer.IRIS_BusinessLayer(); 
    string IdeaId = "";
    string path = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        path = HttpContext.Current.Request.Url.AbsolutePath;
        try
        {
            if (!IsPostBack)
            {
                if (Session["UserId"] == null || Convert.ToString(Session["UserId"]) == "")
                {
                    Response.Redirect("~/Login.aspx?r=" + CommonFunctions.GetRandomNumber(), false);
                }
                grViewIdea.PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["ViewMyIdea_grViewIdea"].ToString());
                BindGrid();
                Session["EarlierPage"] = null;
                Session["PreviousPage"] = null;

            }


        }
        catch (Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }
        }
        finally
        {
        }

    }

    //protected void ddlChallenge_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    BindGrid();
    //}
    private void BindGrid()
    {
        try
        {
            
            string Empid = ""; // Empid null for get all record
            DataSet ds = new DataSet();
            ds = objClass1_BL.IRIS_GET_IDEAS_BY_FILTER_21(Empid);
            grViewIdea.DataSource = ds.Tables[0];
            grViewIdea.DataBind();

            //if (ddlChallenge.SelectedItem.Value != "0")
            //{
            //    Session["ChallengeID4Back"] = HttpUtility.HtmlEncode(ddlChallenge.SelectedValue);
            //}
        }
        catch (Exception ex)
        {
            Session["Error"] = ex.ToString();
            Response.Redirect("~/ErrorPage.aspx");
        }
        finally
        {
        }

    }



    protected void grViewIdea_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grViewIdea.PageIndex = e.NewPageIndex;
        BindGrid();
    }


    protected void grViewIdea_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Select")
        {
            Session["selectedideaid"] = "";
            Session["selectedideaid"] = null;
            Session["postbackurl"] = "";
            Session["postbackurl"] = null;
            int rowIndexId = Convert.ToInt32(e.CommandArgument);
            HttpContext.Current.Session["selectedideaid"] = rowIndexId;
            HttpContext.Current.Session["postbackurl"] = path;
            Response.Redirect("~/Modules/Ideas/PostIdea.aspx");
        }
            
    }
    protected void grViewIdea_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                Label lblstr = (Label)e.Row.FindControl("lblStatus");
                string statustext = ((Label)(e.Row.Cells[4].FindControl("lblStatus"))).Text;

                if (statustext == "Approved")
                {
                    e.Row.Cells[6].BackColor = Color.Green;
                    e.Row.Cells[6].ForeColor = Color.White;
                }
                else if (statustext == "Pending")
                {
                    e.Row.Cells[6].BackColor = Color.Orange;
                    e.Row.Cells[6].ForeColor = Color.White;
                }
                else if (statustext == "Rejected")
                {
                    e.Row.Cells[6].BackColor = Color.Red;
                    e.Row.Cells[6].ForeColor = Color.White;
                }
                else
                {
                    e.Row.Cells[6].BackColor = Color.Orange;
                    e.Row.Cells[6].ForeColor = Color.White;
                }

                
            }
        }
        catch (Exception ex)
        {
            Session["Error"] = ex.ToString();
            Response.Redirect("~/ErrorPage.aspx");
        }
    }



    //protected void grViewIdea_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    HttpContext.Current.Session["selectedideaid"] = "";
    //    string IdeaId = grViewIdea.SelectedRow.Cells[0].Text;
    //    HttpContext.Current.Session["selectedideaid"] = IdeaId;
    //    Response.Redirect("~/Modules/Ideas/PostIdea.aspx");
    //    //LinkButton lnkbtn = (LinkButton)e.Row.FindControl("lblIdeaId");
    //    //IdeaId = ((LinkButton)(e.Row.Cells[0].FindControl("lblIdeaId"))).Text;
    //    //string url = "~/Modules/Ideas/PostIdea.aspx?IdeaId=" + IdeaId;
    //    //lnkbtn.PostBackUrl = url;
    //    //HttpContext.Current.Session["selectedideaid"] = IdeaId;
    //    //Response.Redirect("~/Modules/Ideas/PostIdea.aspx");
    //}

    
}