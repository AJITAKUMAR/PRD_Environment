﻿using AjaxControlToolkit.HTMLEditor.ToolbarButton;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Modules_Events_PostEvents : System.Web.UI.Page
{
    string Flag = "";
    int EventId;
    string Eventtype = string.Empty;
    BusinessLayer.IRIS_BusinessLayer objClass1_BL = new BusinessLayer.IRIS_BusinessLayer();
    string path = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        path = HttpContext.Current.Request.Url.AbsolutePath;
        btnspacerequest.Visible = false;
        btnapprove.Visible = false;
        btnreject.Visible = false;
        divrequestid.Visible = false;
        lstBoxTest.Visible = true;
        txtaccessoryitem.Visible = false;
        if (Session["UserId"] == null || Convert.ToString(Session["UserId"]) == "")
        {
            Response.Redirect("~/Login.aspx?r=" + CommonFunctions.GetRandomNumber(), false);
        }
        if (Request.QueryString["ChlId"] != null)
        {
            EventId = int.Parse(Request.QueryString["ChlId"].ToString());            
        }
        if (!IsPostBack)
        {
            Session["EventRequestPath"] = "";
            Session["EventRequestPath"] = null;
            if (Session["selectedideaid"] != null || Convert.ToString(Session["selectedideaid"]) != "")
            {                
                HiddenField1.Value = Session["selectedideaid"].ToString();
            }

            PopulateData();
        }
        getRoles();
        




    }

    public void getRoles()
    {
        try
        {
            //string UserId=string.Empty;
            if (Session["UserId"] == null || Convert.ToString(Session["UserId"]) == "")
            {
                Response.Redirect("~/Login.aspx?r=" + CommonFunctions.GetRandomNumber(), false);
            }
            else
            {
                string UserId = Session["UserId"].ToString();
                string Admin = "";
                if (CommonFunctions.isSuperAdmin1(Session["UserId"].ToString()))
                {
                    Admin = Session["UserId"].ToString();
                    HttpContext.Current.Session["normaluser"] = "";
                    HttpContext.Current.Session["normaluser"] = null;
                }
                else
                {
                    HttpContext.Current.Session["normaluser"] = "NU";
                }
                if (UserId == Admin)
                {
                    if (Request.QueryString["ChlId"] != null)
                    {
                        EventId = int.Parse(Request.QueryString["ChlId"].ToString());
                        HttpContext.Current.Session["selectedideaid"] = EventId;
                    }

                    if (HttpContext.Current.Session["selectedideaid"] != null || Convert.ToString(Session["selectedideaid"]) != "")
                    {
                        if (lbl_status.Text == "Approved")
                        {
                            btnapprove.Visible = false;
                            btnreject.Visible = false;
                        }
                        else
                        {
                            btnapprove.Visible = true;
                            btnreject.Visible = true;
                        }
                        
                    }
                    else
                    {
                        
                        btnapprove.Visible = false;
                        btnreject.Visible = false;
                    }
                }
                else
                {
                    
                    btnapprove.Visible = false;
                    btnreject.Visible = false;
                }
            }



        }
        catch (Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }
        }
        finally
        {

        }

    }
    
    private void PopulateData()
    {
        try
        {
            if (HiddenField1.Value != "")
            {
                EventId = Convert.ToInt32(HiddenField1.Value);
            }
            DataSet ds = null;
            DataSet ds1 = null;

            

            ds = objClass1_BL.IRIS_GET_EVENT_DETAILS(EventId, Eventtype);
            if (ds.Tables[0].Rows.Count > 0)
            {
                divrequestid.Visible = true;
                HiddenField1.Value = ds.Tables[0].Rows[0]["EVENT_ID"].ToString();
                lbl_status.Text = ds.Tables[0].Rows[0]["EVENT_STATUS"].ToString();
                idea_id.Text = ds.Tables[0].Rows[0]["EVENT_ID"].ToString();

                ddleventtype.SelectedItem.Text = ds.Tables[0].Rows[0]["EVENT_TYPE"].ToString();
                txtContent.Text = ds.Tables[0].Rows[0]["EVENT_DESCRIPTION"].ToString();
                ddlspace.SelectedItem.Text= ds.Tables[0].Rows[0]["EVENT_SPACE"].ToString();
                txtStartDate.Text= ds.Tables[0].Rows[0]["EVENT_START_DATE"].ToString();
                txtEndDate.Text= ds.Tables[0].Rows[0]["EVENT_END_DATE"].ToString();
                txtparticipants.Text= ds.Tables[0].Rows[0]["PARTICIPANTS"].ToString();
                //lstBoxTest.SelectedItem.Text = ds.Tables[0].Rows[0]["EVENT_ACCESSORY"].ToString();
                lstBoxTest.Items.Add(ds.Tables[0].Rows[0]["EVENT_ACCESSORY"].ToString());
                lstBoxTest.Visible = false;
                txtaccessoryitem.Text = ds.Tables[0].Rows[0]["EVENT_ACCESSORY"].ToString();
                txtaccessoryitem.Visible = true;
                txtaccessoryitem.Enabled = false;
                Session["EmpId"] = ds.Tables[0].Rows[0]["EMP_ID"].ToString();
                string EmployeeEmail = ds.Tables[0].Rows[0]["EMP_ID"].ToString();
                controldisable();
                string EventStatus = ds.Tables[0].Rows[0]["EVENT_STATUS"].ToString();
                string signinEmail = Session["UserId"].ToString();                

                if (EventStatus == "602")
                {
                    lbl_status.Text = "Pending";
                    lbl_status.ForeColor = Color.Orange;
                }
                if (EventStatus == "601")
                {
                    lbl_status.Text = "Rejected";
                    lbl_status.ForeColor = Color.Red;
                }
                if (EventStatus == "600") //600 is approved status
                {
                    lbl_status.Text = "Approved";
                    lbl_status.ForeColor = Color.Green;
                    if (signinEmail == EmployeeEmail.Trim())
                    {
                        btnspacerequest.Visible = true;
                    }
                    else
                    {
                        btnspacerequest.Visible = false;
                    }
                    
                                       
                }
                else
                {
                    btnspacerequest.Visible = false;
                }
                ds1 = objClass1_BL.GetBookingSpaceDetails(ds.Tables[0].Rows[0]["EVENT_ID"].ToString());
                if (ds1.Tables[0].Rows.Count > 0)
                {
                    btnspacerequest.Visible = false;
                }




            }
        }
        catch (Exception ex)
        {
            Session["Error"] = ex.ToString();
            Response.Redirect("~/ErrorPage.aspx");
        }
        finally
        {
        }
    }
    public void controldisable()
    {
        ddleventtype.Enabled= false;
        txtContent.Enabled = false;
        ddlspace.Enabled = false;
        txtStartDate.Enabled = false;
        txtEndDate.Enabled = false;
        txtparticipants.Enabled = false;
        lstBoxTest.Enabled = false;
        btnSubmit.Enabled = false;        
        btnSubmit.Visible = false;
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
       
        string strExtension = string.Empty;
        try
        {
            string EventAlreadyExist = "";
            //EventAlreadyExist = objClass1_BL.get_IDEA_NAME1(txtIdeaName.Text, ddlChallenge.SelectedValue);

            if (EventAlreadyExist == "")
            {
                if (ddleventtype.SelectedValue.Trim() == "0")
                {
                    objClass1_BL.AlertBox("Enter Types Of Events.", this);
                    return;
                }
                if (txtContent.Text.Trim() == "")
                {
                    objClass1_BL.AlertBox("Enter Description.", this);
                    return;
                }
                if (ddlspace.SelectedValue.Trim() == "0")
                {
                    objClass1_BL.AlertBox("Please Select Space.", this);
                    return;
                }
                if (txtStartDate.Text.Trim() == "")
                {
                    objClass1_BL.AlertBox("Please Enter Start Date.", this);
                    return;
                }
                if (txtEndDate.Text.Trim() == "")
                {
                    objClass1_BL.AlertBox("Please Enter End Date.", this);
                    return;
                }
                if (txtparticipants.Text.Trim() == "")
                {
                    objClass1_BL.AlertBox("Please Enter No. Of Participants.", this);
                    return;
                }
                //if (ddlaccessory.SelectedItem.Text.Trim() == "0")
                //{
                //    objClass1_BL.AlertBox("Please Enter Accessory Items For Events.", this);
                //    return;
                //}
                string strImagepath = string.Empty;
                if (ddleventtype.SelectedValue == "1")
                {
                    strImagepath = "IRIS_Finance_1.jpg";
                }
                if (ddleventtype.SelectedValue == "2")
                {
                    strImagepath = "IRIS_mobility.jpg";
                }
                if (ddleventtype.SelectedValue == "3")
                {
                    strImagepath = "IRIS_Innovation_1.jpg";
                }
                if (ddleventtype.SelectedValue == "4")
                {
                    strImagepath = "IRIS_AI.jpg";
                }
                if (ddleventtype.SelectedValue == "5")
                {
                    strImagepath = "IRIS_Analytics.jpg";
                }
                if (ddleventtype.SelectedValue == "6")
                {
                    strImagepath = "IRIS_Healthcare_1.jpg";
                }
                string AccessoryItemsList = "";
                foreach (ListItem li in lstBoxTest.Items)
                {
                    if (li.Selected == true)
                    {
                        AccessoryItemsList += li.Text + ",";
                    }
                }

                if (AccessoryItemsList == "")
                {
                    objClass1_BL.AlertBox("Please Select AccessoryItems.", this);
                    return;
                }

                string[] paramArray = new string[10];
                paramArray[0] = ddleventtype.SelectedItem.Text;
                paramArray[1] = txtContent.Text;
                paramArray[2] = ddlspace.SelectedItem.Text;
                paramArray[3] = txtStartDate.Text;
                paramArray[4] = txtEndDate.Text;
                paramArray[5] = txtparticipants.Text;
                paramArray[6] = AccessoryItemsList;//ddlaccessory.SelectedItem.Text;
                paramArray[7] = Session["UserId"].ToString();
                paramArray[8] = strImagepath;
                paramArray[9] = "602"; //status 602 for post Events pending



                if (Flag == "Update")
                {
                    //objClass1_BL.updateChallenge(paramArray);
                }
                else
                {
                    int id = objClass1_BL.insertpost_event(paramArray);
                    if (id > 0)
                    {
                        string msg = "An email has been sent to admin regarding your submission. Please track your request in My Events!!";
                        //ScriptManager.RegisterStartupScript(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('Thank you for submitting! Your Event has been sent to the admin for approval. You shall be updated about the status via mail.'); location.href='PostEvents.aspx';", true);
                        //HttpContext.Current.Session["SuccessMessage"] = "Your Event has been sent to the admin for approval. You shall be updated about the status via mail.";
                        HttpContext.Current.Session["SuccessMessage"] = msg;
                        HttpContext.Current.Response.Redirect("~/Modules/Message/SuccessMessage.aspx", false);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('Contract System Admin';", true);
                    }
                        
                }


            }
        }
        catch (Exception ex)
        {
            strExtension = ex.Message;
            Session["Error"] = ex.ToString();
            Response.Redirect("~/ErrorPage.aspx");
        }
        finally
        {


        }

    }


    
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        if (Session["RequestPath"] != null || Convert.ToString(Session["RequestPath"]) != "")
        {
            HttpContext.Current.Session["selectedideaid"] = "";
            HttpContext.Current.Session["selectedideaid"] = null;
            HttpContext.Current.Response.Redirect(Session["RequestPath"].ToString());
        }
        if (Session["postbackurl"] != null || Convert.ToString(Session["postbackurl"]) != "")
        {
            HttpContext.Current.Session["selectedideaid"] = "";
            HttpContext.Current.Session["selectedideaid"] = null;
            HttpContext.Current.Response.Redirect(Session["postbackurl"].ToString());
        }

        if (Session["selectedideaid"] != null || Convert.ToString(Session["selectedideaid"]) != "")
        {
            if (Session["normaluser"] != null || Convert.ToString(Session["normaluser"]) != "")
            {
                HttpContext.Current.Session["selectedideaid"] = "";
                HttpContext.Current.Session["selectedideaid"] = null;
                HttpContext.Current.Response.Redirect("~/Modules/Events/EventHome.aspx");
            }
            else
            {
                HttpContext.Current.Session["selectedideaid"] = "";
                HttpContext.Current.Session["selectedideaid"] = null;
                HttpContext.Current.Response.Redirect("~/Modules/AdminSR/EventDashboard.aspx");
            }

        }
        else
        {
            HttpContext.Current.Session["selectedideaid"] = "";
            HttpContext.Current.Session["selectedideaid"] = null;
            HttpContext.Current.Response.Redirect("~/Modules/Events/EventHome.aspx");
        }
    }

    protected void btnspacerequest_Click(object sender, EventArgs e)
    {
        Session["RequestSpaceId"] = EventId;        
        HttpContext.Current.Response.Redirect("~/Modules/Space/BookingSpace.aspx");
    }

    protected void btnapprove_Click(object sender, EventArgs e)
    {
        if (HiddenField1.Value != "")
        {
            updateapproveEvent("600", HiddenField1.Value);
            HttpContext.Current.Session["SuccessMessage"] = "The Event has been Approved and the Owner will be Informed via Email";//"Event Approved!! The Idea owner shall receive a e-mail informing them that their event has been approved.";
            HttpContext.Current.Response.Redirect("~/Modules/Message/SuccessMessage.aspx", false);
        }
    }
    public void updateapproveEvent(string status, string ideaid)
    {
        try
        {
            objClass1_BL.Update_Event_Status(status, ideaid);
            //ScriptManager.RegisterStartupScript(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('Idea Approved!! The idea owner shall receive a e-mail informing them that their idea has been approved and a form for them to fill their space allocation requirements'); location.href='PostEvents.aspx';", true);
        }
        catch (Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }
        }


    }

    protected void btnreject_Click(object sender, EventArgs e)
    {
        if (HiddenField1.Value != "")
        {
            RejectEvent("601", HiddenField1.Value);
            HttpContext.Current.Session["SuccessMessage"] = "The Event has been Rejected and the Owner will be Informed via Email";
            //"Event Rejected. The idea owner shall receive a e-mail informing them that their event has been rejected.";
            HttpContext.Current.Response.Redirect("~/Modules/Message/SuccessMessage.aspx", false);
            //ScriptManager.RegisterStartupScript(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('Idea Rejected. The idea owner shall receive a e-mail informing them that their idea has been rejected.'); location.href='PostEvents.aspx';", true);
        }
    }
    public void RejectEvent(string status, string ideaid)
    {
        try
        {
            objClass1_BL.Update_Event_Status(status, ideaid);
        }
        catch (Exception ex)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Session["Error"])))
            {
                Session["Error"] = Session["Error"] + ex.ToString();
            }
            else
            {
                Session["Error"] = ex.ToString();
                Response.Redirect("~/ErrorPage.aspx");
            }
        }

    }
}