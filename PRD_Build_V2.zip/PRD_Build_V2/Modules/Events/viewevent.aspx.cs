﻿using AjaxControlToolkit.HTMLEditor.ToolbarButton;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

public partial class Modules_Events_viewevent : System.Web.UI.Page
{
    BusinessLayer.IRIS_BusinessLayer objClass1_BL = new BusinessLayer.IRIS_BusinessLayer();
    string path = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        path = HttpContext.Current.Request.Url.AbsolutePath;
        if (Session["UserId"] == null || Convert.ToString(Session["UserId"]) == "")
        {
            Response.Redirect("~/Login.aspx?r=" + CommonFunctions.GetRandomNumber(), false);
        }
        HttpContext.Current.Session["RequestPath"] = "";
        HttpContext.Current.Session["RequestPath"] = null;
    }


    public void AddDynamicDivs()
    {
       
        try
        {

            //DataSet ds = objClass1_BL.getPastChallenges(paramArray);//mccain
            //DataSet ds = objClass1_BL.getPastChallenges1(paramArray);
            string EmpId = Session["UserId"].ToString();
            string AllEvent = "";
            DataSet ds = objClass1_BL.GET_EVENT_DETAILS(EmpId,AllEvent);
            if (ds.Tables.Count > 0)
            {
                if (ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        string challengeName = string.Empty;
                        string challengeImage = string.Empty;
                        HttpContext.Current.Session["RequestPath"] = "";
                        HttpContext.Current.Session["RequestPath"] = path;

                        challengeName = Regex.Replace(row["EVENT_TYPE"].ToString(), "<.*?>", string.Empty);
                        if (challengeName.Length < 200)
                        {
                            //challengeName = challengeName.PadRight(200 - challengeName.Length);
                            // challengeName=challengeName+new string(' ', 200 - challengeName.Length);
                            challengeName = challengeName + new string(' ', 1);
                            int i = 200 - challengeName.Length;
                            while (i > 0)
                            {
                                challengeName = challengeName + "&nbsp;";
                                i--;
                            }
                        }
                        if (!string.IsNullOrEmpty(row["EVENT_IMAGE"].ToString()))
                        {
                            challengeImage = row["EVENT_IMAGE"].ToString();
                        }
                        else
                        {
                            challengeImage = "IRIS_Innovation_1.jpg";
                        }
                        Response.Write("<div style='margin:10px 0px 0px 10px; text-align:center; width:24%; display:inline-block; vertical-align: top; overflow-wrap: break-word; word-wrap:break-word;' class='challenge-card'>");
                        Response.Write("<a href='../../modules/Events/PostEvents.aspx?ChlId=" + row["EVENT_ID"].ToString() + "'>");
                        //Response.Write("<div style='height:264px;'>");
                        Response.Write("<img style='width:230px; height:210px'  src='../../images/icons/" + challengeImage + "'/><br />");
                        Response.Write("<span>" + challengeName + "</span>");
                        //Response.Write("</div>");                       
                        Response.Write("</a>");
                        Response.Write("</div>");
                    }
                    
                }
            }
        }
        catch (Exception ex)
        {
            Session["Error"] = ex.ToString();
            Response.Redirect("~/ErrorPage.aspx");
        }
    }

    //public void LoadTable()
    //{
    //    Image imagebtn1 = new Image();
    //    Image imagebtn2 = new Image();
    //    Image imagebtn3 = new Image();
    //    Image imagebtn4 = new Image();
    //    string ImagePath1 = imagebtn1.ImageUrl;
    //    string ImagePath2 = imagebtn2.ImageUrl;
    //    string ImagePath3 = imagebtn3.ImageUrl;
    //    string ImagePath4 = imagebtn3.ImageUrl;
    //    imagebtn1.ImageUrl = "~/images/icons/IRIS_Innovation_1.jpg";
    //    imagebtn2.ImageUrl = "~/images/icons/IRIS_Innovation_1.jpg";
    //    imagebtn3.ImageUrl = "~/images/icons/IRIS_Innovation_1.jpg";
    //    imagebtn4.ImageUrl = "~/images/icons/IRIS_Innovation_1.jpg";

    //    TableRow tr = new TableRow();
    //    TableCell tc1 = new TableCell();
    //    TableCell tc2 = new TableCell();
    //    TableCell tc3 = new TableCell();
    //    TableCell tc4 = new TableCell();


    //    tc1.Controls.Add(imagebtn1);
    //    tc2.Controls.Add(imagebtn2);
    //    tc3.Controls.Add(imagebtn3);
    //    tc4.Controls.Add(imagebtn4);
    //    tr.Controls.Add(tc1);
    //    tr.Controls.Add(tc2);
    //    tr.Controls.Add(tc3);
    //    tr.Controls.Add(tc4);
    //    //myTable.Rows.Add(tr);
    //}
    //public void LoadEvent()
    //{
    //    int trowcount = 4;
    //    string EmpId = "ajit.rath075@gmail.com";
    //    DataSet ds = objClass1_BL.GET_EVENT_DETAILS(EmpId);
    //    if (ds != null )
    //    {
    //        //string[] arrstr = new string[3];
    //        //for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
    //        //{
    //        //    for (int j = 0; j<)
    //        //    if (i == 3)
    //        //    {
    //        //        arrstr[0] = ds.Tables[0].Rows[i]["EVENT_ID"].ToString();
    //        //    }
    //        //    if (i == 1)
    //        //    {
    //        //        arrstr[1] = ds.Tables[0].Rows[i]["EVENT_ID"].ToString();
    //        //    }
    //        //    if (i == 2)
    //        //    {
    //        //        arrstr[2] = ds.Tables[0].Rows[i]["EVENT_ID"].ToString();
    //        //    }
    //        //    if (i == 3)
    //        //    {
    //        //        arrstr[3] = ds.Tables[0].Rows[i]["EVENT_ID"].ToString();
    //        //    }
    //        //    //arrstr[0] = ds.Tables[0].Rows[i]["EVENT_ID"].ToString();
    //        //    //string str = ds.Tables[0].Rows[i]["EVENT_ID"].ToString();

    //        //    //if (str == ds.Tables[0].Rows[i]["EVENT_ID"].ToString())
    //        //    //{

    //        //    //}

    //        //}

    //    }
    //}
}