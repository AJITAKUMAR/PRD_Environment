﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Reflection;
using System.Data;
using System.Data.OracleClient;
using OraAppBlock;

namespace Logger
{
    public class LogWriter
    {
        public LogWriter(int P_STATUS_ID, DateTime P_LOG_DATE, string p_USER_ID, string P_ENTITY_TYPE, int p_ENTITY_ID, string P_SUB_ENTITY_TYPE, int p_SUB_ENTITY_ID)
        {
            LogWrite(P_STATUS_ID, P_LOG_DATE, p_USER_ID, P_ENTITY_TYPE, p_ENTITY_ID, P_SUB_ENTITY_TYPE, p_SUB_ENTITY_ID);
        }
        public void LogWrite(int P_STATUS_ID, DateTime P_LOG_DATE, string p_USER_ID, string P_ENTITY_TYPE, int p_ENTITY_ID, string P_SUB_ENTITY_TYPE, int p_SUB_ENTITY_ID)
        {
            string strConnectionString = CommonFunctions.getConnectionString();
            OracleConnection pConn = new OracleConnection();
            pConn = CommonFunctions.OpenConnetion();
            OracleParameter[] oraParamArray = null;
            pConn.Open();

            try
            {
                oraParamArray = OracleHelperParameterCache.GetSpParameterSet(strConnectionString, "IRIS_INSERT_LOG");
                oraParamArray[0].Value = P_STATUS_ID;
                oraParamArray[1].Value = P_LOG_DATE;
                oraParamArray[2].Value = p_USER_ID;
                oraParamArray[3].Value = P_ENTITY_TYPE;
                oraParamArray[4].Value = p_ENTITY_ID;
                oraParamArray[5].Value = P_SUB_ENTITY_TYPE;
                oraParamArray[6].Value = p_SUB_ENTITY_ID;

                OracleHelper.ExecuteNonQuery(pConn, CommandType.StoredProcedure, "IRIS_INSERT_LOG", oraParamArray);
            }
            catch (Exception ex)
            {
                HttpContext.Current.Session["Error"] = ex.ToString();
                HttpContext.Current.Response.Redirect("~/ErrorPage.aspx");
            }
            finally
            {
                pConn.Close();
                pConn.Dispose();
            }
        }
    }
}
